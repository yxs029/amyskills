const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const outputDir = path.join(projectRoot, 'output', 'font-demos');
const outputPath = path.join(outputDir, '内部分享-字体系统-demo.html');

fs.mkdirSync(outputDir, { recursive: true });

const fontCombos = [
  {
    id: 'A',
    name: 'A. 现代发布会',
    title: '"PingFang SC", "Hiragino Sans GB", "Noto Sans SC", sans-serif',
    body: '"PingFang SC", "Hiragino Sans GB", "Noto Sans SC", sans-serif',
    titleWeight: 800,
    bodyWeight: 400,
    tracking: '-0.035em',
    mood: '克制、干净、像 Apple/发布会',
  },
  {
    id: 'B',
    name: 'B. 杂志感黑体',
    title: '"Source Han Sans SC", "Noto Sans SC", "PingFang SC", sans-serif',
    body: '"Source Han Sans SC", "Noto Sans SC", "PingFang SC", sans-serif',
    titleWeight: 900,
    bodyWeight: 400,
    tracking: '-0.045em',
    mood: '理性、厚重、像商业杂志封面',
  },
  {
    id: 'C',
    name: 'C. 人文宋黑',
    title: '"Songti SC", "STSong", serif',
    body: '"PingFang SC", "Hiragino Sans GB", sans-serif',
    titleWeight: 700,
    bodyWeight: 400,
    tracking: '-0.02em',
    mood: '人文、克制、有一点书卷气',
  },
  {
    id: 'D',
    name: 'D. 思源宋标题',
    title: '"Source Han Serif SC", "Noto Serif CJK SC", serif',
    body: '"Source Han Sans SC", "Noto Sans SC", sans-serif',
    titleWeight: 700,
    bodyWeight: 400,
    tracking: '-0.025em',
    mood: '正式、沉稳、适合思想型内容',
  },
  {
    id: 'E',
    name: 'E. 几何感无衬线',
    title: '"Avenir Next", "Helvetica Neue", "PingFang SC", sans-serif',
    body: '"Avenir Next", "Helvetica Neue", "PingFang SC", sans-serif',
    titleWeight: 800,
    bodyWeight: 450,
    tracking: '-0.04em',
    mood: '现代、科技、偏产品设计感',
  },
  {
    id: 'F',
    name: 'F. 高对比宋体',
    title: '"Baskerville", "Times New Roman", "Songti SC", serif',
    body: '"PingFang SC", "Hiragino Sans GB", sans-serif',
    titleWeight: 700,
    bodyWeight: 400,
    tracking: '-0.02em',
    mood: '经典、知识感、偏论文演讲',
  },
  {
    id: 'G',
    name: 'G. 海报级粗黑',
    title: '"Arial Black", "Source Han Sans SC", "PingFang SC", sans-serif',
    body: '"PingFang SC", "Hiragino Sans GB", sans-serif',
    titleWeight: 900,
    bodyWeight: 400,
    tracking: '-0.05em',
    mood: '强势、海报感、适合大标题冲击',
  },
  {
    id: 'H',
    name: 'H. 轻奢宋体',
    title: '"STSong", "Songti SC", serif',
    body: '"Helvetica Neue", "PingFang SC", sans-serif',
    titleWeight: 700,
    bodyWeight: 400,
    tracking: '-0.015em',
    mood: '优雅、品牌感、偏高端叙事',
  },
  {
    id: 'I',
    name: 'I. 企业培训风',
    title: '"Microsoft YaHei", "PingFang SC", sans-serif',
    body: '"Microsoft YaHei", "PingFang SC", sans-serif',
    titleWeight: 700,
    bodyWeight: 400,
    tracking: '-0.02em',
    mood: '稳妥、耐看、适合大多数投屏环境',
  },
  {
    id: 'J',
    name: 'J. 国际化简报',
    title: '"Inter", "Avenir Next", "PingFang SC", sans-serif',
    body: '"Inter", "Avenir Next", "PingFang SC", sans-serif',
    titleWeight: 800,
    bodyWeight: 400,
    tracking: '-0.04em',
    mood: '咨询感、国际化、简洁利落',
  },
];

const cards = fontCombos.map((combo) => `
  <section class="font-card" style="--title-font:${combo.title}; --body-font:${combo.body}; --title-weight:${combo.titleWeight}; --body-weight:${combo.bodyWeight}; --title-tracking:${combo.tracking};">
    <div class="font-card__meta">
      <div class="font-card__id">${combo.id}</div>
      <div class="font-card__name">${combo.name}</div>
      <div class="font-card__mood">${combo.mood}</div>
    </div>
    <div class="font-cover">
      <div class="font-cover__eyebrow">内部分享</div>
      <div class="font-cover__title">从教育创新到 AI 创新</div>
      <div class="font-cover__sub">课程分享 / 章节封面 / 代表性正文</div>
    </div>
    <div class="font-part">Part II. 新五年：比一堂五步法更重要的模型出现了</div>
    <div class="font-body">
      <p>今天都是“<span class="hl">一堂自己人</span>”：业务负责人、城市主理人、NPC专家。</p>
      <p>过去五年，我们用“<strong>一堂五步法</strong>”构建了一套科学创业体系，今天，我试着给大家一套新的工作框架。</p>
      <p>总之一句话：<span class="hl">这次不长的分享，希望凝聚一堂最重要的一批同学，最大的全员共识。</span></p>
    </div>
  </section>
`).join('');

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>内部分享 - 字体系统 Demo</title>
  <style>
    :root {
      --bg-1: #f6f1e7;
      --bg-2: #e7ddcf;
      --text: #1f2937;
      --muted: #6b7280;
      --card: rgba(255,255,255,0.82);
      --border: rgba(31,41,55,0.08);
      --accent: #c2410c;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      min-height: 100vh;
      padding: 40px;
      color: var(--text);
      background:
        radial-gradient(circle at top left, rgba(255,255,255,0.72), transparent 30%),
        radial-gradient(circle at bottom right, rgba(194,65,12,0.1), transparent 28%),
        linear-gradient(135deg, var(--bg-1), var(--bg-2));
      font-family: "PingFang SC", "Hiragino Sans GB", "Noto Sans SC", sans-serif;
    }

    .wrap {
      max-width: 1420px;
      margin: 0 auto;
    }

    .hero {
      margin-bottom: 28px;
    }

    .hero h1 {
      margin: 0 0 10px;
      font-size: 42px;
      line-height: 1.1;
      letter-spacing: -0.04em;
    }

    .hero p {
      margin: 0;
      font-size: 17px;
      line-height: 1.8;
      color: var(--muted);
      max-width: 920px;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 20px;
    }

    .font-card {
      padding: 26px;
      border-radius: 28px;
      background: var(--card);
      border: 1px solid var(--border);
      backdrop-filter: blur(16px);
      box-shadow: 0 18px 48px rgba(15,23,42,0.08);
      overflow: hidden;
    }

    .font-card__meta {
      margin-bottom: 20px;
    }

    .font-card__id {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 38px;
      height: 30px;
      padding: 0 10px;
      border-radius: 999px;
      background: rgba(194,65,12,0.12);
      color: var(--accent);
      font-size: 13px;
      font-weight: 700;
      margin-bottom: 10px;
    }

    .font-card__name {
      font-size: 24px;
      line-height: 1.35;
      font-weight: 700;
      margin-bottom: 8px;
    }

    .font-card__mood {
      font-size: 14px;
      color: var(--muted);
      line-height: 1.7;
    }

    .font-cover,
    .font-part,
    .font-body {
      font-family: var(--body-font);
    }

    .font-cover {
      padding: 26px 0 24px;
      border-top: 1px solid rgba(31,41,55,0.08);
      border-bottom: 1px solid rgba(31,41,55,0.08);
      margin-bottom: 22px;
    }

    .font-cover__eyebrow {
      font-size: 14px;
      letter-spacing: 0.22em;
      text-transform: uppercase;
      color: var(--muted);
      margin-bottom: 14px;
      font-family: var(--body-font);
    }

    .font-cover__title {
      font-family: var(--title-font);
      font-size: clamp(34px, 3vw, 52px);
      line-height: 1.12;
      letter-spacing: var(--title-tracking);
      font-weight: var(--title-weight);
      margin-bottom: 12px;
    }

    .font-cover__sub {
      font-size: 15px;
      line-height: 1.7;
      color: var(--muted);
      font-family: var(--body-font);
    }

    .font-part {
      font-family: var(--title-font);
      font-size: 28px;
      line-height: 1.28;
      letter-spacing: var(--title-tracking);
      font-weight: var(--title-weight);
      margin-bottom: 16px;
      color: #111827;
    }

    .font-body {
      font-family: var(--body-font);
      font-size: 19px;
      line-height: 1.85;
      font-weight: var(--body-weight);
      color: #243041;
    }

    .font-body p {
      margin: 0 0 14px;
    }

    .font-body strong {
      font-weight: 800;
    }

    .hl {
      background: linear-gradient(to top, rgba(255,241,153,0.96) 0%, rgba(255,241,153,0.96) 48%, rgba(255,241,153,0) 48%, rgba(255,241,153,0) 100%);
      box-decoration-break: clone;
      -webkit-box-decoration-break: clone;
      padding: 0 0.06em;
    }

    @media (max-width: 980px) {
      body { padding: 20px; }
      .grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="hero">
      <h1>内部分享字体系统 Demo</h1>
      <p>同一份内容，单独替换标题字体、正文字体和字重结构。你可以直接选编号，我再把你喜欢的那一套并进正式课件。</p>
    </div>
    <div class="grid">${cards}</div>
  </div>
</body>
</html>`;

fs.writeFileSync(outputPath, html, 'utf8');
console.log(`Built font demo: ${outputPath}`);
