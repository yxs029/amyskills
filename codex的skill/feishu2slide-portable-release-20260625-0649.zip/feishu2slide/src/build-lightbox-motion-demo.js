const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const outputDir = path.join(projectRoot, 'output', 'interaction-demo');
const outputPath = path.join(outputDir, '图片转场动效-demo.html');
const backgroundsDir = path.join(projectRoot, 'assets', 'backgrounds');

fs.mkdirSync(outputDir, { recursive: true });

const heroImages = ['bg-01.png', 'bg-02.png', 'bg-03.png']
  .map((file) => path.relative(outputDir, path.join(backgroundsDir, file)).split(path.sep).join('/'));

const motions = [
  {
    id: 'A',
    name: 'A 直线放大',
    desc: '最干净，像系统级图片预览，缩略图直接放大到中心。',
    open: 'translate(-50%, -50%) scale(1)',
    close: 'translate(var(--from-x), var(--from-y)) scale(var(--from-scale))',
    enterClass: 'motion-a',
    switchClass: 'switch-slide',
  },
  {
    id: 'B',
    name: 'B 弹性质感',
    desc: '打开时有轻微超调，像卡片被吸到舞台中央。',
    open: 'translate(-50%, -50%) scale(1)',
    close: 'translate(var(--from-x), var(--from-y)) scale(var(--from-scale))',
    enterClass: 'motion-b',
    switchClass: 'switch-slide-soft',
  },
  {
    id: 'C',
    name: 'C 漂浮停泊',
    desc: '缩略图先抬升再放大，收回时有一点回落，偏演示感。',
    open: 'translate(-50%, -50%) scale(1)',
    close: 'translate(var(--from-x), calc(var(--from-y) + 16px)) scale(var(--from-scale))',
    enterClass: 'motion-c',
    switchClass: 'switch-fade-up',
  },
  {
    id: 'D',
    name: 'D 舞台幕布',
    desc: '背景和图片一起进入，氛围最强，像开灯入场。',
    open: 'translate(-50%, -50%) scale(1)',
    close: 'translate(var(--from-x), var(--from-y)) scale(var(--from-scale))',
    enterClass: 'motion-d',
    switchClass: 'switch-curtain',
  },
  {
    id: 'E',
    name: 'E 推镜头',
    desc: '更像摄像机推近，左右切图时有推轨感。',
    open: 'translate(-50%, -50%) scale(1)',
    close: 'translate(var(--from-x), var(--from-y)) scale(var(--from-scale))',
    enterClass: 'motion-e',
    switchClass: 'switch-push',
  },
  {
    id: 'F',
    name: 'F 胶片滑页',
    desc: '左右切图带一点胶片抽换感，适合多图浏览。',
    open: 'translate(-50%, -50%) scale(1)',
    close: 'translate(var(--from-x), var(--from-y)) scale(var(--from-scale))',
    enterClass: 'motion-f',
    switchClass: 'switch-film',
  },
  {
    id: 'G',
    name: 'G 轻微 3D',
    desc: '打开时有一点空间转正的感觉，不夸张但有层次。',
    open: 'translate(-50%, -50%) rotateX(0deg) rotateY(0deg) scale(1)',
    close: 'translate(var(--from-x), var(--from-y)) rotateX(8deg) rotateY(-10deg) scale(var(--from-scale))',
    enterClass: 'motion-g',
    switchClass: 'switch-parallax',
  },
  {
    id: 'H',
    name: 'H 水平卷轴',
    desc: '切图像横向卷轴，适合课件里的图组浏览。',
    open: 'translate(-50%, -50%) scale(1)',
    close: 'translate(var(--from-x), var(--from-y)) scale(var(--from-scale))',
    enterClass: 'motion-h',
    switchClass: 'switch-roll',
  },
];

const imageMarkup = heroImages.map((img, idx) => {
  return `<button class="thumb" data-index="${idx}" style="--thumb-delay:${idx}">
    <img src="${img}" alt="demo-image-${idx + 1}" />
  </button>`;
}).join('\n');

const motionMarkup = motions.map((motion) => {
  return `<button class="motion-chip${motion.id === 'A' ? ' is-active' : ''}" data-motion="${motion.id}">
    <span class="motion-chip__name">${motion.name}</span>
    <span class="motion-chip__desc">${motion.desc}</span>
  </button>`;
}).join('\n');

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>图片转场动效 Demo</title>
  <style>
    :root {
      --bg: #f5efe6;
      --panel: rgba(255,255,255,0.76);
      --text: #171717;
      --muted: rgba(23,23,23,0.6);
      --line: rgba(23,23,23,0.08);
      --accent: #d97757;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      min-height: 100vh;
      font-family: "PingFang SC", "Hiragino Sans GB", "Noto Sans SC", sans-serif;
      color: var(--text);
      background:
        radial-gradient(circle at top left, rgba(255,255,255,0.8), transparent 30%),
        linear-gradient(135deg, #f8f4ec, #e8ded0);
      overflow: hidden;
    }

    .page {
      display: grid;
      grid-template-columns: 360px 1fr;
      min-height: 100vh;
    }

    .sidebar {
      padding: 24px 22px;
      border-right: 1px solid var(--line);
      background: rgba(255,255,255,0.52);
      backdrop-filter: blur(20px);
      overflow: auto;
    }

    .title {
      font-size: 24px;
      font-weight: 700;
      letter-spacing: 0.02em;
      margin-bottom: 10px;
    }

    .desc {
      font-size: 13px;
      line-height: 1.7;
      color: var(--muted);
      margin-bottom: 20px;
    }

    .motion-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .motion-chip {
      appearance: none;
      border: 1px solid var(--line);
      background: rgba(255,255,255,0.84);
      border-radius: 18px;
      padding: 14px 14px 13px;
      text-align: left;
      cursor: pointer;
      transition: transform 180ms ease, border-color 180ms ease, background 180ms ease, box-shadow 180ms ease;
    }

    .motion-chip:hover {
      transform: translateY(-1px);
      border-color: rgba(217,119,87,0.3);
      box-shadow: 0 10px 24px rgba(23,23,23,0.06);
    }

    .motion-chip.is-active {
      background: linear-gradient(135deg, rgba(217,119,87,0.92), rgba(230,146,111,0.92));
      color: white;
      border-color: transparent;
      box-shadow: 0 14px 28px rgba(217,119,87,0.22);
    }

    .motion-chip__name {
      display: block;
      font-size: 14px;
      font-weight: 700;
      margin-bottom: 5px;
    }

    .motion-chip__desc {
      display: block;
      font-size: 12px;
      line-height: 1.6;
      opacity: 0.84;
    }

    .stage {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 40px;
      gap: 20px;
      overflow: hidden;
    }

    .headline {
      font-size: 30px;
      font-weight: 700;
      text-align: center;
      letter-spacing: 0.02em;
    }

    .subline {
      font-size: 14px;
      color: var(--muted);
      text-align: center;
      margin-top: -10px;
    }

    .thumb-grid {
      width: min(1080px, 92%);
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 20px;
    }

    .thumb {
      appearance: none;
      border: 0;
      padding: 0;
      border-radius: 26px;
      overflow: hidden;
      background: white;
      box-shadow: 0 20px 44px rgba(23,23,23,0.12);
      cursor: pointer;
      transform: translateY(0);
      transition: transform 220ms ease, box-shadow 220ms ease;
    }

    .thumb:hover {
      transform: translateY(-4px);
      box-shadow: 0 28px 56px rgba(23,23,23,0.18);
    }

    .thumb img {
      display: block;
      width: 100%;
      aspect-ratio: 16 / 10;
      object-fit: cover;
    }

    .lightbox {
      position: fixed;
      inset: 0;
      display: none;
      background: rgba(11, 14, 19, 0.84);
      backdrop-filter: blur(8px);
      z-index: 60;
      overflow: hidden;
    }

    .lightbox.is-open {
      display: block;
    }

    .lightbox__backdrop {
      position: absolute;
      inset: 0;
    }

    .lightbox__viewer {
      position: absolute;
      left: 50%;
      top: 50%;
      width: min(76vw, 1200px);
      aspect-ratio: 16 / 10;
      transform: translate(-50%, -50%);
      perspective: 1600px;
    }

    .lightbox__frame {
      position: absolute;
      inset: 0;
      border-radius: 30px;
      overflow: hidden;
      box-shadow: 0 32px 90px rgba(0,0,0,0.34);
      background: #111;
      transform: translate(var(--from-x), var(--from-y)) scale(var(--from-scale));
      opacity: 0;
    }

    .lightbox.is-open .lightbox__frame {
      opacity: 1;
      transform: translate(-50%, -50%) scale(1);
    }

    .lightbox__img-stage {
      position: absolute;
      inset: 0;
      overflow: hidden;
      border-radius: 30px;
    }

    .lightbox__img {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      transform: translateX(0);
    }

    .lightbox__close,
    .lightbox__nav {
      position: absolute;
      appearance: none;
      border: 0;
      background: rgba(255,255,255,0.12);
      color: white;
      cursor: pointer;
      backdrop-filter: blur(10px);
    }

    .lightbox__close {
      top: 18px;
      right: 18px;
      width: 44px;
      height: 44px;
      border-radius: 999px;
      font-size: 24px;
      z-index: 4;
    }

    .lightbox__nav {
      top: 50%;
      width: 48px;
      height: 64px;
      border-radius: 18px;
      transform: translateY(-50%);
      font-size: 22px;
      z-index: 4;
    }

    .lightbox__nav--prev { left: 24px; }
    .lightbox__nav--next { right: 24px; }

    .lightbox__meta {
      position: absolute;
      left: 24px;
      bottom: 20px;
      display: flex;
      gap: 12px;
      align-items: center;
      z-index: 4;
      color: rgba(255,255,255,0.9);
      font-size: 13px;
    }

    .lightbox__badge {
      padding: 6px 10px;
      border-radius: 999px;
      background: rgba(255,255,255,0.12);
      backdrop-filter: blur(10px);
    }

    .lightbox.motion-a .lightbox__frame {
      transition: transform 380ms cubic-bezier(0.22, 1, 0.36, 1), opacity 260ms ease;
    }

    .lightbox.motion-b .lightbox__frame {
      transition: transform 520ms cubic-bezier(0.2, 1.28, 0.22, 1), opacity 260ms ease;
    }

    .lightbox.motion-c .lightbox__frame {
      transition: transform 520ms cubic-bezier(0.16, 1, 0.3, 1), opacity 260ms ease;
    }

    .lightbox.motion-d .lightbox__frame {
      transition: transform 620ms cubic-bezier(0.19, 1, 0.22, 1), opacity 320ms ease;
    }

    .lightbox.motion-e .lightbox__frame {
      transition: transform 460ms cubic-bezier(0.15, 0.9, 0.2, 1), opacity 260ms ease;
    }

    .lightbox.motion-f .lightbox__frame {
      transition: transform 400ms cubic-bezier(0.25, 1, 0.35, 1), opacity 220ms ease;
    }

    .lightbox.motion-g .lightbox__frame {
      transition: transform 620ms cubic-bezier(0.16, 1, 0.3, 1), opacity 260ms ease;
    }

    .lightbox.motion-h .lightbox__frame {
      transition: transform 460ms cubic-bezier(0.2, 0.98, 0.25, 1), opacity 280ms ease;
    }

    .lightbox.motion-d::before,
    .lightbox.motion-d::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      height: 50%;
      background: rgba(255,255,255,0.03);
      transform: scaleY(0);
      transform-origin: top;
      transition: transform 520ms cubic-bezier(0.2, 1, 0.3, 1);
    }

    .lightbox.motion-d::after {
      top: auto;
      bottom: 0;
      transform-origin: bottom;
    }

    .lightbox.motion-d.is-open::before,
    .lightbox.motion-d.is-open::after {
      transform: scaleY(1);
    }

    .lightbox__img.is-animating {
      transition: transform 360ms cubic-bezier(0.22, 1, 0.36, 1), opacity 260ms ease, filter 260ms ease;
    }

    .switch-slide .lightbox__img.enter-from-right { transform: translateX(22%); opacity: 0; }
    .switch-slide .lightbox__img.enter-from-left { transform: translateX(-22%); opacity: 0; }
    .switch-slide .lightbox__img.exit-to-left { transform: translateX(-18%); opacity: 0; }
    .switch-slide .lightbox__img.exit-to-right { transform: translateX(18%); opacity: 0; }

    .switch-slide-soft .lightbox__img.enter-from-right { transform: translateX(14%) scale(0.98); opacity: 0; }
    .switch-slide-soft .lightbox__img.enter-from-left { transform: translateX(-14%) scale(0.98); opacity: 0; }
    .switch-slide-soft .lightbox__img.exit-to-left { transform: translateX(-10%) scale(1.02); opacity: 0; }
    .switch-slide-soft .lightbox__img.exit-to-right { transform: translateX(10%) scale(1.02); opacity: 0; }

    .switch-fade-up .lightbox__img.enter-from-right,
    .switch-fade-up .lightbox__img.enter-from-left { transform: translateY(7%) scale(0.985); opacity: 0; }
    .switch-fade-up .lightbox__img.exit-to-left,
    .switch-fade-up .lightbox__img.exit-to-right { transform: translateY(-7%) scale(1.02); opacity: 0; }

    .switch-curtain .lightbox__img.enter-from-right { transform: translateX(26%) scale(1.03); filter: blur(8px); opacity: 0; }
    .switch-curtain .lightbox__img.enter-from-left { transform: translateX(-26%) scale(1.03); filter: blur(8px); opacity: 0; }
    .switch-curtain .lightbox__img.exit-to-left { transform: translateX(-20%) scale(0.98); filter: blur(8px); opacity: 0; }
    .switch-curtain .lightbox__img.exit-to-right { transform: translateX(20%) scale(0.98); filter: blur(8px); opacity: 0; }

    .switch-push .lightbox__img.enter-from-right { transform: translateX(22%) scale(0.92); opacity: 0; }
    .switch-push .lightbox__img.enter-from-left { transform: translateX(-22%) scale(0.92); opacity: 0; }
    .switch-push .lightbox__img.exit-to-left { transform: translateX(-14%) scale(1.08); opacity: 0; }
    .switch-push .lightbox__img.exit-to-right { transform: translateX(14%) scale(1.08); opacity: 0; }

    .switch-film .lightbox__img.enter-from-right { transform: translateX(30%) skewX(-3deg); opacity: 0; }
    .switch-film .lightbox__img.enter-from-left { transform: translateX(-30%) skewX(3deg); opacity: 0; }
    .switch-film .lightbox__img.exit-to-left { transform: translateX(-24%) skewX(3deg); opacity: 0; }
    .switch-film .lightbox__img.exit-to-right { transform: translateX(24%) skewX(-3deg); opacity: 0; }

    .switch-parallax .lightbox__img.enter-from-right { transform: translateX(16%) scale(0.96); filter: saturate(0.82); opacity: 0; }
    .switch-parallax .lightbox__img.enter-from-left { transform: translateX(-16%) scale(0.96); filter: saturate(0.82); opacity: 0; }
    .switch-parallax .lightbox__img.exit-to-left { transform: translateX(-12%) scale(1.04); filter: saturate(1.18); opacity: 0; }
    .switch-parallax .lightbox__img.exit-to-right { transform: translateX(12%) scale(1.04); filter: saturate(1.18); opacity: 0; }

    .switch-roll .lightbox__img.enter-from-right { transform: translateX(24%) rotate(4deg); opacity: 0; }
    .switch-roll .lightbox__img.enter-from-left { transform: translateX(-24%) rotate(-4deg); opacity: 0; }
    .switch-roll .lightbox__img.exit-to-left { transform: translateX(-20%) rotate(-4deg); opacity: 0; }
    .switch-roll .lightbox__img.exit-to-right { transform: translateX(20%) rotate(4deg); opacity: 0; }

    @media (max-width: 1100px) {
      .page {
        grid-template-columns: 1fr;
      }
      .sidebar {
        border-right: 0;
        border-bottom: 1px solid var(--line);
      }
      .thumb-grid {
        grid-template-columns: 1fr;
      }
      .lightbox__viewer {
        width: min(90vw, 900px);
      }
    }
  </style>
</head>
<body>
  <div class="page">
    <aside class="sidebar">
      <div class="title">图片转场动效 Demo</div>
      <div class="desc">
        这一页专门测试三件事：缩略图放大成大图，大图收回成缩略图，以及多图左右切换时的动画语言。
        你可以直接点开任意图片，然后在左侧切换动效方案比较气质。
      </div>
      <div class="motion-list">
        ${motionMarkup}
      </div>
    </aside>
    <main class="stage">
      <div class="headline">缩略图到大图，要不要“神奇一点”？</div>
      <div class="subline">测试 8 组：系统感、弹性、舞台感、推镜头、胶片感、轻 3D、卷轴感</div>
      <div class="thumb-grid" id="thumbGrid">
        ${imageMarkup}
      </div>
    </main>
  </div>

  <div class="lightbox motion-a switch-slide" id="lightbox">
    <div class="lightbox__backdrop" id="lightboxBackdrop"></div>
    <button class="lightbox__close" id="lightboxClose">×</button>
    <button class="lightbox__nav lightbox__nav--prev" id="prevBtn">‹</button>
    <button class="lightbox__nav lightbox__nav--next" id="nextBtn">›</button>
    <div class="lightbox__viewer">
      <div class="lightbox__frame" id="lightboxFrame">
        <div class="lightbox__img-stage" id="imgStage">
          <img class="lightbox__img" id="lightboxImg" alt="" />
        </div>
      </div>
    </div>
    <div class="lightbox__meta">
      <div class="lightbox__badge" id="motionBadge">A 直线放大</div>
      <div class="lightbox__badge" id="countBadge">1 / 3</div>
    </div>
  </div>

  <script>
    const motions = ${JSON.stringify(motions)};
    const images = ${JSON.stringify(heroImages)};
    const chips = Array.from(document.querySelectorAll('.motion-chip'));
    const thumbs = Array.from(document.querySelectorAll('.thumb'));
    const lightbox = document.getElementById('lightbox');
    const lightboxFrame = document.getElementById('lightboxFrame');
    const lightboxImg = document.getElementById('lightboxImg');
    const lightboxBackdrop = document.getElementById('lightboxBackdrop');
    const lightboxClose = document.getElementById('lightboxClose');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const motionBadge = document.getElementById('motionBadge');
    const countBadge = document.getElementById('countBadge');

    let currentMotion = motions[0];
    let currentIndex = 0;
    let currentThumb = null;

    function setMotion(nextId) {
      currentMotion = motions.find((item) => item.id === nextId) || motions[0];
      chips.forEach((chip) => chip.classList.toggle('is-active', chip.dataset.motion === currentMotion.id));
      lightbox.className = 'lightbox ' + currentMotion.enterClass + ' ' + currentMotion.switchClass;
      motionBadge.textContent = currentMotion.name;
    }

    function updateCount() {
      countBadge.textContent = (currentIndex + 1) + ' / ' + images.length;
    }

    function getThumbTransform(thumb) {
      const rect = thumb.getBoundingClientRect();
      const viewerWidth = Math.min(window.innerWidth * 0.76, 1200);
      const viewerHeight = viewerWidth / 1.6;
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      const thumbCenterX = rect.left + rect.width / 2;
      const thumbCenterY = rect.top + rect.height / 2;
      const fromX = thumbCenterX - centerX;
      const fromY = thumbCenterY - centerY;
      const fromScale = rect.width / viewerWidth;
      return {
        fromX: fromX.toFixed(2) + 'px',
        fromY: fromY.toFixed(2) + 'px',
        fromScale: fromScale.toFixed(5),
      };
    }

    function setFrameFromThumb(thumb) {
      const transform = getThumbTransform(thumb);
      lightboxFrame.style.setProperty('--from-x', transform.fromX);
      lightboxFrame.style.setProperty('--from-y', transform.fromY);
      lightboxFrame.style.setProperty('--from-scale', transform.fromScale);
      lightboxFrame.style.transform = currentMotion.close;
      lightboxFrame.style.opacity = '0';
    }

    function animateOpen(thumb) {
      setFrameFromThumb(thumb);
      requestAnimationFrame(() => {
        lightbox.classList.add('is-open');
        requestAnimationFrame(() => {
          lightboxFrame.style.transform = currentMotion.open;
          lightboxFrame.style.opacity = '1';
        });
      });
    }

    function animateClose() {
      if (!currentThumb) {
        lightbox.classList.remove('is-open');
        return;
      }
      setFrameFromThumb(currentThumb);
      requestAnimationFrame(() => {
        lightboxFrame.style.transform = currentMotion.close;
        lightboxFrame.style.opacity = '0';
        setTimeout(() => {
          lightbox.classList.remove('is-open');
        }, 360);
      });
    }

    function showImage(index) {
      currentIndex = (index + images.length) % images.length;
      lightboxImg.src = images[currentIndex];
      updateCount();
    }

    function animateSwitch(nextIndex, dir) {
      const next = new Image();
      next.className = 'lightbox__img is-animating ' + (dir > 0 ? 'enter-from-right' : 'enter-from-left');
      next.src = images[(nextIndex + images.length) % images.length];
      next.alt = '';
      next.style.zIndex = '2';
      lightboxImg.classList.add('is-animating', dir > 0 ? 'exit-to-left' : 'exit-to-right');
      const stage = document.getElementById('imgStage');
      stage.appendChild(next);
      requestAnimationFrame(() => {
        next.classList.remove('enter-from-right', 'enter-from-left');
        lightboxImg.classList.add(dir > 0 ? 'exit-to-left' : 'exit-to-right');
      });
      setTimeout(() => {
        lightboxImg.src = next.src;
        lightboxImg.className = 'lightbox__img';
        next.remove();
        currentIndex = (nextIndex + images.length) % images.length;
        updateCount();
      }, 360);
    }

    function openFromThumb(index, thumb) {
      currentThumb = thumb;
      showImage(index);
      animateOpen(thumb);
    }

    chips.forEach((chip) => {
      chip.addEventListener('click', () => setMotion(chip.dataset.motion));
    });

    thumbs.forEach((thumb) => {
      thumb.addEventListener('click', () => openFromThumb(Number(thumb.dataset.index), thumb));
    });

    lightboxBackdrop.addEventListener('click', animateClose);
    lightboxClose.addEventListener('click', animateClose);
    prevBtn.addEventListener('click', () => animateSwitch(currentIndex - 1, -1));
    nextBtn.addEventListener('click', () => animateSwitch(currentIndex + 1, 1));

    document.addEventListener('keydown', (event) => {
      if (!lightbox.classList.contains('is-open')) return;
      if (event.key === 'Escape') {
        animateClose();
      } else if (event.key === 'ArrowLeft') {
        animateSwitch(currentIndex - 1, -1);
      } else if (event.key === 'ArrowRight') {
        animateSwitch(currentIndex + 1, 1);
      }
    });

    setMotion('A');
  </script>
</body>
</html>`;

fs.writeFileSync(outputPath, html, 'utf8');
console.log(`Built demo: ${outputPath}`);
