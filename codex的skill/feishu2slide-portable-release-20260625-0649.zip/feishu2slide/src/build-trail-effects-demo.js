const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const sourcePath = path.join(projectRoot, 'output', '内部分享：从教育创新到AI创新-v3-presentation.html');
const outputDir = path.join(projectRoot, 'output', 'interaction-demo');
const outputPath = path.join(outputDir, '内部分享：笔触拖影-demo.html');

fs.mkdirSync(outputDir, { recursive: true });

const baseHtml = fs.readFileSync(sourcePath, 'utf8');

const extraCss = `
    .trail-lab {
      position: fixed;
      top: 14px;
      left: 14px;
      right: 70px;
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
      padding: 12px 14px;
      border-radius: 20px;
      background: rgba(255, 255, 255, 0.76);
      backdrop-filter: blur(18px);
      box-shadow: 0 12px 36px rgba(15, 23, 42, 0.1);
      z-index: 36;
    }

    .trail-lab__title {
      font-size: 13px;
      font-weight: 700;
      color: rgba(31, 41, 55, 0.9);
      margin-right: 2px;
    }

    .trail-chip {
      appearance: none;
      border: 1px solid rgba(31, 41, 55, 0.1);
      background: rgba(255, 255, 255, 0.92);
      color: rgba(31, 41, 55, 0.82);
      border-radius: 999px;
      padding: 7px 12px;
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      transition: transform 160ms ease, border-color 160ms ease, background 160ms ease;
    }

    .trail-chip:hover {
      transform: translateY(-1px);
      border-color: rgba(194, 65, 12, 0.24);
    }

    .trail-chip.is-active {
      color: #fff;
      background: linear-gradient(90deg, #ea580c, #fb923c);
      border-color: transparent;
    }

    .trail-meta {
      margin-left: auto;
      font-size: 12px;
      color: rgba(107, 114, 128, 0.92);
    }

    .trail-canvas {
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 34;
    }

    .trail-core {
      position: fixed;
      left: 0;
      top: 0;
      width: 18px;
      height: 18px;
      margin-left: -9px;
      margin-top: -9px;
      border-radius: 999px;
      background: radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(255,236,210,0.95) 38%, rgba(251,146,60,0.9) 60%, rgba(251,146,60,0) 100%);
      box-shadow: 0 0 14px rgba(251,146,60,0.36), 0 0 30px rgba(251,146,60,0.16);
      pointer-events: none;
      z-index: 35;
      mix-blend-mode: screen;
      opacity: 0;
      transition: opacity 160ms ease;
    }

    body.has-trail-pointer .trail-core {
      opacity: 1;
    }

    .slides {
      cursor: none;
    }

    @media (max-width: 900px) {
      .trail-lab {
        right: 12px;
        top: 12px;
        padding: 10px;
        gap: 8px;
      }

      .trail-lab__title,
      .trail-meta {
        width: 100%;
        margin-left: 0;
      }
    }
`;

const controlsMarkup = `
  <canvas class="trail-canvas" id="trailCanvas"></canvas>
  <div class="trail-core" id="trailCore"></div>
  <div class="trail-lab" id="trailLab">
    <div class="trail-lab__title">笔触拖影实验</div>
    <button class="trail-chip is-active" data-trail-style="marker-amber">1 琥珀荧光笔</button>
    <button class="trail-chip" data-trail-style="marker-lime">2 青柠荧光笔</button>
    <button class="trail-chip" data-trail-style="marker-cyan">3 冰蓝荧光笔</button>
    <button class="trail-chip" data-trail-style="marker-pink">4 玫粉荧光笔</button>
    <button class="trail-chip" data-trail-style="marker-violet">5 紫雾荧光笔</button>
    <button class="trail-chip" data-trail-style="ink-wash">6 水墨拖影</button>
    <button class="trail-chip" data-trail-style="ink-glow">7 墨色荧光</button>
    <button class="trail-chip" data-trail-style="snake-mint">8 贪吃蛇薄荷</button>
    <button class="trail-chip" data-trail-style="snake-sunset">9 贪吃蛇落日</button>
    <button class="trail-chip" data-trail-style="snake-mono">10 黑白蛇影</button>
    <div class="trail-meta" id="trailMeta">连续笔触轨迹，约 1 秒渐隐，偏荧光笔与水墨拖影。</div>
  </div>
`;

const extraScript = `
    const trailCanvas = document.getElementById('trailCanvas');
    const trailCore = document.getElementById('trailCore');
    const trailLab = document.getElementById('trailLab');
    const trailMeta = document.getElementById('trailMeta');
    const trailCtx = trailCanvas.getContext('2d');
    const prefersFinePointer = window.matchMedia('(pointer: fine)').matches;
    const trailState = {
      pointer: { x: window.innerWidth * 0.5, y: window.innerHeight * 0.5, tx: window.innerWidth * 0.5, ty: window.innerHeight * 0.5 },
      current: 'marker-amber',
      strokes: [],
      lastInput: null
    };

    const trailPresets = {
      'marker-amber': {
        label: '琥珀荧光笔',
        colorA: '255,205,86',
        colorB: '251,146,60',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(255,236,210,0.95) 38%, rgba(251,146,60,0.9) 60%, rgba(251,146,60,0) 100%)',
        width: 20,
        fade: 980,
        tension: 0.32,
        blur: 16,
        glow: 0.26,
        mode: 'marker'
      },
      'marker-lime': {
        label: '青柠荧光笔',
        colorA: '190,242,100',
        colorB: '132,204,22',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(236,252,203,0.95) 38%, rgba(132,204,22,0.88) 60%, rgba(132,204,22,0) 100%)',
        width: 18,
        fade: 1020,
        tension: 0.28,
        blur: 18,
        glow: 0.24,
        mode: 'marker'
      },
      'marker-cyan': {
        label: '冰蓝荧光笔',
        colorA: '165,243,252',
        colorB: '34,211,238',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(224,242,254,0.95) 38%, rgba(34,211,238,0.9) 60%, rgba(34,211,238,0) 100%)',
        width: 16,
        fade: 920,
        tension: 0.26,
        blur: 18,
        glow: 0.22,
        mode: 'marker'
      },
      'marker-pink': {
        label: '玫粉荧光笔',
        colorA: '251,207,232',
        colorB: '244,114,182',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(252,231,243,0.96) 38%, rgba(244,114,182,0.88) 60%, rgba(244,114,182,0) 100%)',
        width: 18,
        fade: 960,
        tension: 0.3,
        blur: 18,
        glow: 0.24,
        mode: 'marker'
      },
      'marker-violet': {
        label: '紫雾荧光笔',
        colorA: '221,214,254',
        colorB: '168,85,247',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(243,232,255,0.96) 38%, rgba(168,85,247,0.88) 60%, rgba(168,85,247,0) 100%)',
        width: 18,
        fade: 980,
        tension: 0.34,
        blur: 22,
        glow: 0.26,
        mode: 'marker'
      },
      'ink-wash': {
        label: '水墨拖影',
        colorA: '82,82,91',
        colorB: '24,24,27',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.78), rgba(212,212,216,0.72) 38%, rgba(63,63,70,0.82) 60%, rgba(63,63,70,0) 100%)',
        width: 24,
        fade: 1100,
        tension: 0.42,
        blur: 28,
        glow: 0.08,
        mode: 'wash'
      },
      'ink-glow': {
        label: '墨色荧光',
        colorA: '199,210,254',
        colorB: '55,48,163',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.92), rgba(224,231,255,0.9) 38%, rgba(79,70,229,0.84) 60%, rgba(79,70,229,0) 100%)',
        width: 22,
        fade: 1020,
        tension: 0.38,
        blur: 24,
        glow: 0.18,
        mode: 'wash'
      },
      'snake-mint': {
        label: '贪吃蛇薄荷',
        colorA: '187,247,208',
        colorB: '16,185,129',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(220,252,231,0.95) 38%, rgba(16,185,129,0.88) 60%, rgba(16,185,129,0) 100%)',
        width: 14,
        fade: 940,
        tension: 0.18,
        blur: 12,
        glow: 0.18,
        mode: 'snake'
      },
      'snake-sunset': {
        label: '贪吃蛇落日',
        colorA: '254,215,170',
        colorB: '249,115,22',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(255,237,213,0.95) 38%, rgba(249,115,22,0.9) 60%, rgba(249,115,22,0) 100%)',
        width: 14,
        fade: 920,
        tension: 0.18,
        blur: 12,
        glow: 0.2,
        mode: 'snake'
      },
      'snake-mono': {
        label: '黑白蛇影',
        colorA: '244,244,245',
        colorB: '39,39,42',
        core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.94), rgba(228,228,231,0.9) 38%, rgba(63,63,70,0.82) 60%, rgba(63,63,70,0) 100%)',
        width: 12,
        fade: 860,
        tension: 0.14,
        blur: 10,
        glow: 0.06,
        mode: 'snake'
      }
    };

    function resizeTrailCanvas() {
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      trailCanvas.width = Math.floor(window.innerWidth * ratio);
      trailCanvas.height = Math.floor(window.innerHeight * ratio);
      trailCanvas.style.width = window.innerWidth + 'px';
      trailCanvas.style.height = window.innerHeight + 'px';
      trailCtx.setTransform(ratio, 0, 0, ratio, 0, 0);
    }

    function lerp(a, b, t) {
      return a + (b - a) * t;
    }

    function distance(a, b) {
      return Math.hypot(a.x - b.x, a.y - b.y);
    }

    function addPoint(x, y) {
      const now = performance.now();
      const preset = trailPresets[trailState.current];
      const stroke = trailState.strokes;
      const last = stroke[stroke.length - 1];
      if (last && distance(last, { x, y }) < 1.2) return;
      stroke.push({ x, y, t: now });
      if (stroke.length > 320) {
        stroke.splice(0, stroke.length - 320);
      }
      trailCore.style.left = x + 'px';
      trailCore.style.top = y + 'px';
      trailCore.style.background = preset.core;
    }

    function addInterpolatedPoints(fromX, fromY, toX, toY) {
      const dx = toX - fromX;
      const dy = toY - fromY;
      const dist = Math.hypot(dx, dy);
      const steps = Math.max(1, Math.ceil(dist / 1.6));
      for (let i = 1; i <= steps; i += 1) {
        const t = i / steps;
        addPoint(lerp(fromX, toX, t), lerp(fromY, toY, t));
      }
    }

    function drawStroke(now) {
      const preset = trailPresets[trailState.current];
      const alive = trailState.strokes.filter((point) => now - point.t <= preset.fade);
      trailState.strokes = alive;
      if (alive.length < 2) return;

      trailCtx.save();
      trailCtx.lineCap = 'round';
      trailCtx.lineJoin = 'round';
      trailCtx.shadowBlur = preset.blur;
      trailCtx.shadowColor = 'rgba(' + preset.colorB + ',' + (preset.glow + 0.08) + ')';

      const first = alive[0];
      const last = alive[alive.length - 1];
      const headAge = now - last.t;
      const headAlpha = Math.max(0, 1 - headAge / preset.fade);
      const baseThickness = preset.mode === 'snake'
        ? Math.max(2, preset.width * (0.28 + headAlpha * 0.72))
        : Math.max(3, preset.width * (0.38 + headAlpha * 0.62));

      const trailEase = (ratio) => Math.pow(Math.max(0, 1 - ratio), 0.48);

      const drawPath = (lineWidth, alphaScale, blurScale) => {
        trailCtx.shadowBlur = preset.blur * blurScale;
        trailCtx.shadowColor = 'rgba(' + preset.colorB + ',' + (preset.glow * blurScale + 0.04) + ')';
        trailCtx.lineWidth = lineWidth;
        trailCtx.beginPath();
        trailCtx.moveTo(alive[0].x, alive[0].y);
        for (let i = 1; i < alive.length - 1; i += 1) {
          const curr = alive[i];
          const next = alive[i + 1];
          const midX = (curr.x + next.x) / 2;
          const midY = (curr.y + next.y) / 2;
          trailCtx.quadraticCurveTo(curr.x, curr.y, midX, midY);
        }
        trailCtx.lineTo(last.x, last.y);

        const gradient = trailCtx.createLinearGradient(first.x, first.y, last.x, last.y);
        gradient.addColorStop(0, 'rgba(' + preset.colorA + ',' + (0.045 * alphaScale) + ')');
        gradient.addColorStop(0.16, 'rgba(' + preset.colorA + ',' + (0.12 * alphaScale) + ')');
        gradient.addColorStop(0.5, 'rgba(' + preset.colorA + ',' + (0.28 * alphaScale) + ')');
        gradient.addColorStop(0.82, 'rgba(' + preset.colorB + ',' + (0.5 * alphaScale) + ')');
        gradient.addColorStop(1, 'rgba(' + preset.colorB + ',' + ((0.88 * headAlpha + 0.06) * alphaScale) + ')');
        trailCtx.strokeStyle = gradient;
        trailCtx.stroke();
      };

      drawPath(baseThickness * 1.95, preset.mode === 'snake' ? 0.16 : 0.24, 1.35);
      drawPath(baseThickness * 1.4, preset.mode === 'snake' ? 0.22 : 0.34, 1.05);
      drawPath(baseThickness, 1, 1);

      if (preset.mode === 'wash') {
        for (let i = 0; i < alive.length; i += 3) {
          const point = alive[i];
          const ageRatio = (now - point.t) / preset.fade;
          const alpha = trailEase(ageRatio);
          trailCtx.fillStyle = 'rgba(' + preset.colorB + ',' + (alpha * 0.06) + ')';
          trailCtx.beginPath();
          trailCtx.arc(point.x, point.y, baseThickness * 1.05, 0, Math.PI * 2);
          trailCtx.fill();
        }
      }

      if (preset.mode === 'snake') {
        for (let i = 0; i < alive.length; i += 4) {
          const point = alive[i];
          const ageRatio = (now - point.t) / preset.fade;
          const alpha = trailEase(ageRatio);
          trailCtx.fillStyle = 'rgba(255,255,255,' + (alpha * 0.08) + ')';
          trailCtx.beginPath();
          trailCtx.arc(point.x, point.y, baseThickness * 0.16, 0, Math.PI * 2);
          trailCtx.fill();
        }
      }

      trailCtx.restore();
    }

    function renderTrail(now) {
      trailCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      trailState.pointer.x = lerp(trailState.pointer.x, trailState.pointer.tx, 0.42);
      trailState.pointer.y = lerp(trailState.pointer.y, trailState.pointer.ty, 0.42);
      trailCore.style.left = trailState.pointer.x + 'px';
      trailCore.style.top = trailState.pointer.y + 'px';
      drawStroke(now);
      requestAnimationFrame(renderTrail);
    }

    function setTrailStyle(name) {
      trailState.current = name;
      trailState.strokes = [];
      const preset = trailPresets[name];
      trailCore.style.background = preset.core;
      trailMeta.textContent = preset.label + '：连续笔触拖影，约 1 秒渐隐，偏荧光笔/水墨笔/蛇形轨迹。';
      trailLab.querySelectorAll('.trail-chip').forEach((chip) => chip.classList.toggle('is-active', chip.dataset.trailStyle === name));
    }

    if (prefersFinePointer) {
      document.body.classList.add('has-trail-pointer');
      resizeTrailCanvas();
      setTrailStyle(trailState.current);
      requestAnimationFrame(renderTrail);

      document.addEventListener('pointermove', (event) => {
        const samples = typeof event.getCoalescedEvents === 'function' ? event.getCoalescedEvents() : [event];
        for (const sample of samples) {
          if (trailState.lastInput) {
            addInterpolatedPoints(trailState.lastInput.x, trailState.lastInput.y, sample.clientX, sample.clientY);
          } else {
            addPoint(sample.clientX, sample.clientY);
          }
          trailState.lastInput = { x: sample.clientX, y: sample.clientY };
          trailState.pointer.tx = sample.clientX;
          trailState.pointer.ty = sample.clientY;
        }
      });

      window.addEventListener('resize', () => {
        resizeTrailCanvas();
        classifyWideImages();
      });

      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          trailState.strokes = [];
          trailState.lastInput = null;
        }
      });

      trailLab?.addEventListener('click', (event) => {
        const button = event.target.closest('[data-trail-style]');
        if (!button) return;
        setTrailStyle(button.dataset.trailStyle);
      });
    } else {
      trailMeta.textContent = '当前设备不是精细指针设备，笔触拖影实验建议在桌面端预览。';
    }
`;

let html = baseHtml
  .replace('</style>', `${extraCss}\n  </style>`)
  .replace('<div class="progress"><div class="progress__bar" id="progressBar"></div></div>', `${controlsMarkup}\n  <div class="progress"><div class="progress__bar" id="progressBar"></div></div>`)
  .replace('</script>\n</body>', `${extraScript}\n  </script>\n</body>`)
  .replace(/<title>[\s\S]*?<\/title>/, '<title>内部分享：笔触拖影 Demo</title>');

fs.writeFileSync(outputPath, html, 'utf8');
console.log(`Built brush trail demo: ${outputPath}`);
