const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const htmlFile = process.argv[2];
const noBrowser = process.argv.includes('--no-browser');
const failOnWarning = process.argv.includes('--fail-on-warning');

if (!htmlFile) {
  console.error('Usage: node src/qa-deck.js <deck.html> [--no-browser] [--fail-on-warning]');
  process.exit(1);
}

const htmlPath = path.resolve(htmlFile);
if (!fs.existsSync(htmlPath)) {
  console.error(`Deck not found: ${htmlPath}`);
  process.exit(1);
}

const html = fs.readFileSync(htmlPath, 'utf8');
const outputBase = htmlPath.replace(/\.html?$/i, '');
const jsonPath = `${outputBase}.qa-check.json`;
const mdPath = `${outputBase}.qa-check.md`;

function stripTags(value) {
  return String(value).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function stripTransparentWrapperTags(source) {
  return String(source || '').replace(/<\/?(synced-source|source-synced|reference-synced)\b[^>]*>/gi, '');
}

function splitHeadingsWrappingBlockContent(source) {
  return String(source || '').replace(/<h([1-6])\b([^>]*)>([\s\S]*?)<\/h\1>/gi, (full, level, attrs, inner) => {
    const firstBlockMatch = inner.match(/<(?:hr|p|ul|ol|blockquote|img|figure|grid)\b/i);
    if (!firstBlockMatch || firstBlockMatch.index === 0) return full;

    const headingText = inner.slice(0, firstBlockMatch.index).trim();
    const blockContent = inner.slice(firstBlockMatch.index).trim();
    if (!headingText || !blockContent) return full;

    return `<h${level}${attrs}>${headingText}</h${level}>${blockContent}`;
  });
}

function normalizeSourceForStructuralChecks(source) {
  return splitHeadingsWrappingBlockContent(stripTransparentWrapperTags(source));
}

function getSlides(source) {
  return [...source.matchAll(/<section class="([^"]*)"[^>]*(?:data-index|data-slide-index)="(\d+)"[\s\S]*?<\/section>/g)]
    .map((match) => ({
      index: Number(match[2]),
      className: match[1],
      html: match[0],
      imageCount: (match[0].match(/<img\b/gi) || []).length,
      text: stripTags(match[0]).slice(0, 120),
    }));
}

function getImageSources(source) {
  const withoutScripts = source.replace(/<script\b[\s\S]*?<\/script>/gi, '');
  return [...withoutScripts.matchAll(/<img\s+[^>]*src="([^"]+)"/gi)].map((match) => match[1]);
}

function decodeHtmlAttr(value) {
  return String(value || '')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&');
}

function parseHtmlAttributes(text) {
  const attrs = {};
  const regex = /([\w:-]+)="([^"]*)"/g;
  let match;
  while ((match = regex.exec(String(text || '')))) {
    attrs[match[1].toLowerCase()] = decodeHtmlAttr(match[2]);
  }
  return attrs;
}

function getImageEntries(source) {
  const withoutScripts = source.replace(/<script\b[\s\S]*?<\/script>/gi, '');
  return [...withoutScripts.matchAll(/<img\b([^>]*)>/gi)].map((match, index) => {
    const attrs = parseHtmlAttributes(match[1]);
    return {
      index: index + 1,
      src: attrs.src || '',
      width: Number(attrs.width || 0),
      height: Number(attrs.height || 0),
      alt: attrs.alt || '',
    };
  }).filter((entry) => entry.src);
}

function getNavEntries(source) {
  return [...source.matchAll(/<button type="button" class="nav-item nav-item--level-(\d)"[^>]*>\s*<span class="nav-item__label">([\s\S]*?)<\/span>/g)]
    .map((match) => ({
      level: Number(match[1]),
      label: stripTags(match[2]),
    }))
    .filter((entry) => entry.label);
}

function getSourceHeadingEntries(source) {
  const withoutScripts = normalizeSourceForStructuralChecks(source).replace(/<script\b[\s\S]*?<\/script>/gi, '');
  return [...withoutScripts.matchAll(/<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1>/gi)]
    .map((match) => ({
      level: Math.min(Math.max(Number(match[1]), 1), 3),
      label: stripTags(match[2]).slice(0, 72),
    }))
    .filter((entry) => entry.label);
}

function normalizeSrcForCompare(src) {
  if (/^(?:https?:)?\/\//i.test(src) || src.startsWith('data:')) return src;
  return path.basename(decodeURIComponent(src));
}

function getLocalImageDimensions(source) {
  if (/^(?:https?:)?\/\//i.test(source) || source.startsWith('data:')) return null;
  const decoded = decodeURIComponent(decodeHtmlAttr(source));
  const absolute = path.resolve(path.dirname(htmlPath), decoded);
  if (!fs.existsSync(absolute)) return { missing: true, width: 0, height: 0, absolute };
  try {
    const output = cp.execFileSync('sips', ['-g', 'pixelWidth', '-g', 'pixelHeight', absolute], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    });
    return {
      missing: false,
      width: Number(output.match(/pixelWidth:\s*(\d+)/)?.[1] || 0),
      height: Number(output.match(/pixelHeight:\s*(\d+)/)?.[1] || 0),
      absolute,
    };
  } catch {
    return { missing: false, width: 0, height: 0, absolute };
  }
}

function findChrome() {
  const candidates = [
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  ];
  return candidates.find((candidate) => fs.existsSync(candidate)) || null;
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function getJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${url} returned ${response.status}`);
  return response.json();
}

async function send(ws, method, params = {}) {
  const id = ++send.id;
  ws.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    const onMessage = (event) => {
      const message = JSON.parse(event.data.toString());
      if (message.id !== id) return;
      ws.removeEventListener('message', onMessage);
      if (message.error) reject(new Error(JSON.stringify(message.error)));
      else resolve(message.result || {});
    };
    ws.addEventListener('message', onMessage);
  });
}
send.id = 0;

async function runBrowserQa(slides) {
  const chrome = findChrome();
  if (!chrome) {
    return { skipped: true, reason: 'Chrome/Chromium not found' };
  }

  const port = 9320 + Math.floor(Math.random() * 200);
  const qaDir = path.join(path.dirname(htmlPath), 'qa-screenshots');
  const profileDir = path.join(qaDir, `.chrome-qa-${Date.now()}`);
  fs.mkdirSync(qaDir, { recursive: true });

  const browser = cp.spawn(chrome, [
    '--headless=new',
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${profileDir}`,
    '--disable-gpu',
    '--hide-scrollbars',
    '--window-size=1600,1000',
    `file://${htmlPath}`,
  ], { stdio: 'ignore' });

  try {
    let targets = null;
    for (let i = 0; i < 40; i += 1) {
      try {
        targets = await getJson(`http://127.0.0.1:${port}/json`);
        break;
      } catch {
        await wait(250);
      }
    }
    if (!targets) throw new Error('Headless browser did not start');

    const target = targets.find((item) => item.type === 'page') || targets[0];
    const ws = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      ws.addEventListener('open', resolve, { once: true });
      ws.addEventListener('error', reject, { once: true });
    });

    await send(ws, 'Page.enable');
    await send(ws, 'Runtime.enable');
    await wait(1800);
    await send(ws, 'Runtime.evaluate', {
      returnByValue: true,
      expression: `(() => {
        const style = document.createElement('style');
        style.setAttribute('data-qa-disable-transitions', 'true');
        style.textContent = '.slide { transition: none !important; }';
        document.head.appendChild(style);
        return true;
      })()`,
    });

    const imageSlides = slides.filter((slide) => slide.imageCount > 0);
    const inspected = [];
    const sampleIndexes = new Set(imageSlides.map((slide) => slide.index));

    for (const index of sampleIndexes) {
      await send(ws, 'Runtime.evaluate', {
        returnByValue: true,
        expression: `(() => {
          const all = Array.from(document.querySelectorAll('.slide'));
          const target = all.find((slide) => slide.getAttribute('data-index') === '${index}' || slide.getAttribute('data-slide-index') === '${index}');
          if (!target) return false;
          const targetIndex = all.indexOf(target);
          if (typeof goTo === 'function') {
            goTo(targetIndex);
          } else {
            all.forEach((slide, slideIndex) => {
              slide.classList.remove('is-active', 'is-before', 'is-after');
              if (slideIndex < targetIndex) slide.classList.add('is-before');
              else if (slideIndex > targetIndex) slide.classList.add('is-after');
              else slide.classList.add('is-active');
            });
          }
          document.body.offsetHeight;
          return true;
        })()`,
      });
      await wait(120);

      const result = await send(ws, 'Runtime.evaluate', {
        returnByValue: true,
        expression: `(() => {
          const slide = Array.from(document.querySelectorAll('.slide')).find((item) => item.classList.contains('is-active'));
          const body = slide.querySelector('.slide__body');
          const inner = slide.querySelector('.slide__inner');
          const stack = slide.querySelector('.slide__stack') || body;
          const bodyImages = Array.from(body.querySelectorAll('img')).map((image) => {
            const style = getComputedStyle(image);
            const rect = image.getBoundingClientRect();
            return {
              display: style.display,
              objectFit: style.objectFit,
              width: Math.round(rect.width),
              height: Math.round(rect.height),
              x: Math.round(rect.x),
              y: Math.round(rect.y),
              naturalWidth: image.naturalWidth || 0,
              naturalHeight: image.naturalHeight || 0,
              loaded: image.complete && (image.naturalWidth || 0) > 0,
              visible: style.display !== 'none' && rect.width > 0 && rect.height > 0,
            };
          });
          const uniqueBodyImageSources = new Set(Array.from(body.querySelectorAll('img')).map((image) => image.currentSrc || image.src).filter(Boolean)).size;
          const thumbs = Array.from(slide.querySelectorAll('.thumb')).map((thumb) => {
            const style = getComputedStyle(thumb);
            const rect = thumb.getBoundingClientRect();
            return {
              display: style.display,
              width: Math.round(rect.width),
              height: Math.round(rect.height),
              visible: style.display !== 'none' && rect.width > 0 && rect.height > 0,
            };
          });
          return {
            activeSlideCount: document.querySelectorAll('.slide.is-active').length,
            index: slide.getAttribute('data-index') || slide.getAttribute('data-slide-index'),
            className: slide.className,
            text: (slide.innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 160),
            imageCount: bodyImages.length,
            visibleBodyImages: bodyImages.filter((image) => image.visible).length,
            thumbCount: thumbs.length,
            visibleThumbs: thumbs.filter((thumb) => thumb.visible).length,
            uniqueBodyImageSources,
            firstImage: bodyImages[0] || null,
            bodyImages,
            firstThumb: thumbs[0] || null,
            viewport: { width: innerWidth, height: innerHeight },
            overflow: stack.scrollHeight > inner.clientHeight + 8,
            leakedRuntimeText: /<\\/?(?:text|mention-user|source-synced|reference-synced|grid|image|quote-container)\\b/i.test(slide.innerText || ''),
          };
        })()`,
      });
      inspected.push(result.result.value);
    }

    ws.close();
    return { skipped: false, inspected };
  } finally {
    browser.kill('SIGTERM');
    for (let attempt = 0; attempt < 6; attempt += 1) {
      try {
        fs.rmSync(profileDir, { recursive: true, force: true });
        break;
      } catch (error) {
        if (attempt === 5) {
          console.warn(`Warning: could not remove temporary browser profile: ${profileDir}`);
          break;
        }
        await wait(250);
      }
    }
  }
}

function addIssue(issues, severity, code, message, slide = null) {
  issues.push({
    severity,
    code,
    message,
    slide: slide ? {
      index: slide.index,
      className: slide.className,
      imageCount: slide.imageCount,
      text: slide.text,
    } : null,
  });
}

async function main() {
  const slides = getSlides(html);
  const issues = [];
  const finalImageSources = getImageSources(html);
  const finalNavEntries = getNavEntries(html);
  const sourceHtmlPath = htmlPath.replace(/\.html?$/i, '.source.html');
  let sourceImageSources = [];
  let sourceImageDimensionChecks = 0;
  let sourceHeadingNavEntries = [];
  if (fs.existsSync(sourceHtmlPath)) {
    const sourceHtml = fs.readFileSync(sourceHtmlPath, 'utf8');
    sourceHeadingNavEntries = getSourceHeadingEntries(sourceHtml);
    sourceImageSources = getImageSources(sourceHtml);
    const finalByName = new Set(finalImageSources.map(normalizeSrcForCompare));
    const missingFromFinal = sourceImageSources
      .map(normalizeSrcForCompare)
      .filter((src) => !finalByName.has(src));
    if (missingFromFinal.length) {
      addIssue(
        issues,
        'error',
        'source-images-missing-from-output',
        `Final deck is missing ${missingFromFinal.length} image(s) from source HTML. Examples: ${missingFromFinal.slice(0, 8).join(', ')}`,
      );
    }

    for (const image of getImageEntries(sourceHtml)) {
      if (!image.width || !image.height) continue;
      sourceImageDimensionChecks += 1;
      const actual = getLocalImageDimensions(image.src);
      if (!actual) continue;
      if (actual.missing) {
        addIssue(issues, 'error', 'source-image-file-missing', `Source image file does not exist: ${image.src}`);
        continue;
      }
      if (actual.width !== image.width || actual.height !== image.height) {
        addIssue(
          issues,
          'error',
          'source-image-dimension-mismatch',
          `Source image ${image.index} points to ${path.basename(decodeURIComponent(image.src))}, but dimensions do not match Feishu source: expected ${image.width}x${image.height}, got ${actual.width}x${actual.height}.`,
        );
      }
    }

    const finalNavLabels = new Set(finalNavEntries.map((entry) => entry.label));
    const missingHeadingNavEntries = sourceHeadingNavEntries
      .map((entry) => entry.label)
      .filter((label) => !finalNavLabels.has(label));
    if (missingHeadingNavEntries.length) {
      addIssue(
        issues,
        'error',
        'source-headings-missing-from-nav',
        `Navigation is missing ${missingHeadingNavEntries.length} source heading(s). Examples: ${missingHeadingNavEntries.slice(0, 8).join(', ')}`,
      );
    }
  }
  const activeSlideCount = (html.match(/<section class="[^"]*\bis-active\b[^"]*"/g) || []).length;
  if (activeSlideCount !== 1) {
    addIssue(issues, 'error', 'active-slide-count', `Initial HTML should have exactly one active slide, found ${activeSlideCount}.`);
  }

  for (const source of getImageSources(html)) {
    if (/^(?:https?:)?\/\//i.test(source) || source.startsWith('data:')) continue;
    const decoded = decodeURIComponent(source);
    const absolute = path.resolve(path.dirname(htmlPath), decoded);
    if (!fs.existsSync(absolute)) {
      addIssue(issues, 'error', 'missing-image-file', `Image file does not exist: ${source}`);
    }
  }

  const leakedTags = [...html.matchAll(/&lt;\/?(?:text|mention-user|source-synced|reference-synced|grid|image|quote-container)\b/gi)];
  if (leakedTags.length) {
    addIssue(issues, 'error', 'leaked-tags', `Found ${leakedTags.length} escaped Feishu/HTML-like tags in output.`);
  }
  const leakedCodeFences = [...html.matchAll(/```(?:\w+)?(?:\s+\{[^}]+\})?|plaintext\s+\{wrap\}/gi)];
  if (leakedCodeFences.length) {
    addIssue(issues, 'error', 'leaked-code-fences', `Found ${leakedCodeFences.length} raw Markdown code fence marker(s) in output.`);
  }

  for (const slide of slides) {
    if (/slide--visual/.test(slide.className) && slide.imageCount > 1) {
      addIssue(issues, 'error', 'multi-image-visual', 'Multi-image slide must not be classified as visual.', slide);
    }
    if (slide.imageCount > 1 && !/slide--mixed|slide--gallery|has-image-gallery/.test(slide.className)) {
      addIssue(issues, 'warning', 'multi-image-unclear-kind', 'Multi-image slide should use mixed/gallery behavior.', slide);
    }
  }

  let browserQa = { skipped: true, reason: '--no-browser' };
  if (!noBrowser) {
    browserQa = await runBrowserQa(slides);
    if (!browserQa.skipped) {
      for (const slide of browserQa.inspected) {
        if (slide.activeSlideCount !== 1) {
          addIssue(issues, 'error', 'runtime-active-slide-count', `Browser should have exactly one active slide, found ${slide.activeSlideCount}.`, slide);
        }
        if (slide.leakedRuntimeText) {
          addIssue(issues, 'error', 'visible-leaked-tags', 'Rendered slide text still contains Feishu/HTML-like tags.', slide);
        }
        const unloadedImages = (slide.bodyImages || []).filter((image) => !image.loaded);
        if (unloadedImages.length) {
          addIssue(issues, 'error', 'image-not-loaded', `Slide has ${unloadedImages.length} image(s) that did not load.`, slide);
        }
        if (slide.imageCount > 1) {
          if (slide.visibleBodyImages !== 0) {
            addIssue(issues, 'error', 'multi-image-body-visible', 'Multi-image slide should hide original body images.', slide);
          }
          if (slide.visibleThumbs !== slide.uniqueBodyImageSources) {
            addIssue(issues, 'error', 'multi-image-thumbs-missing', 'Multi-image slide should show one visible thumbnail per unique image.', slide);
          }
        }
        if (/is-single-image|slide--visual/.test(slide.className) && slide.imageCount === 1) {
          const image = slide.firstImage || {};
          const fillsWidth = image.width >= slide.viewport.width * 0.9;
          const fillsHeight = image.height >= slide.viewport.height * 0.9;
          if (!fillsWidth && !fillsHeight) {
            addIssue(issues, 'error', 'single-image-not-fullscreen', 'Single-image visual slide should fill either viewport width or height.', slide);
          }
          if (fillsWidth && fillsHeight && (Math.abs(image.x || 0) > 2 || Math.abs(image.y || 0) > 2)) {
            addIssue(issues, 'error', 'single-image-shifted', 'Single-image visual slide fills the viewport but is shifted away from the top-left origin.', slide);
          }
          if (/is-wide-image/.test(slide.className) && image.objectFit !== 'fill') {
            addIssue(issues, 'error', 'wide-image-not-fill', 'Wide single-image visual slide should use fill so 21:9/24:9 background pages occupy the full ultrawide viewport.', slide);
          }
        }
        if (slide.overflow && slide.imageCount > 0) {
          addIssue(issues, 'warning', 'image-slide-overflow', 'Image slide overflows its viewport.', slide);
        }
      }
    }
  }

  const errorCount = issues.filter((issue) => issue.severity === 'error').length;
  const warningCount = issues.filter((issue) => issue.severity === 'warning').length;
  const report = {
    ok: errorCount === 0 && (!failOnWarning || warningCount === 0),
    htmlPath,
    generatedAt: new Date().toISOString(),
    summary: {
      slides: slides.length,
      imageSlides: slides.filter((slide) => slide.imageCount > 0).length,
      multiImageSlides: slides.filter((slide) => slide.imageCount > 1).length,
      sourceImageTags: sourceImageSources.length,
      sourceImageDimensionChecks,
      finalImageTags: finalImageSources.length,
      sourceHeadingNavEntries: sourceHeadingNavEntries.length,
      finalNavEntries: finalNavEntries.length,
      leakedTagCount: leakedTags.length,
      errors: errorCount,
      warnings: warningCount,
      browserQa: browserQa.skipped ? `skipped: ${browserQa.reason}` : `inspected ${browserQa.inspected.length} slides`,
    },
    issues,
    browserQa,
  };

  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), 'utf8');
  fs.writeFileSync(mdPath, [
    `# Deck QA: ${path.basename(htmlPath)}`,
    '',
    `- 状态：${report.ok ? (warningCount ? '通过（有警告）' : '通过') : '未通过'}`,
    `- 总页数：${report.summary.slides}`,
    `- 图片页：${report.summary.imageSlides}`,
    `- 多图页：${report.summary.multiImageSlides}`,
    `- 源图片标签：${report.summary.sourceImageTags || '无 source.html'}`,
    `- 源图片尺寸校验：${report.summary.sourceImageDimensionChecks}`,
    `- 输出图片标签：${report.summary.finalImageTags}`,
    `- 源标题目录项：${report.summary.sourceHeadingNavEntries}`,
    `- 输出目录项：${report.summary.finalNavEntries}`,
    `- 裸标签泄露：${report.summary.leakedTagCount}`,
    `- 错误：${report.summary.errors}`,
    `- 警告：${report.summary.warnings}`,
    `- 浏览器检查：${report.summary.browserQa}`,
    '',
    '## 问题',
    '',
    issues.length
      ? issues.map((issue) => `- [${issue.severity}] ${issue.code}${issue.slide ? ` / slide ${issue.slide.index}` : ''}: ${issue.message}${issue.slide?.text ? ` (${issue.slide.text})` : ''}`).join('\n')
      : '- 无',
    '',
  ].join('\n'), 'utf8');

  console.log(`Deck QA ${report.ok ? (warningCount ? 'passed with warnings' : 'passed') : 'failed'}: ${mdPath}`);
  if (!report.ok) {
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(error?.stack || error?.message || String(error));
  process.exit(1);
});
