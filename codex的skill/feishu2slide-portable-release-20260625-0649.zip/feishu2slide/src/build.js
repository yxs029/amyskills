const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const { parse } = require('node-html-parser');

const sourceFile = process.argv[2];
const outputFile = process.argv[3];

if (!sourceFile || !outputFile) {
  console.error('Usage: node src/build.js <input.html> <output.html>');
  process.exit(1);
}

const sourcePath = path.resolve(sourceFile);
const outputPath = path.resolve(outputFile);
const sourceDir = path.dirname(sourcePath);
const outputDir = path.dirname(outputPath);
const outputBase = path.basename(outputPath, path.extname(outputPath));
const deckResourcesDir = path.join(outputDir, `${outputBase}.resources`);
const projectRoot = path.resolve(__dirname, '..');
const backgroundAssetsDir = path.join(projectRoot, 'assets', 'backgrounds');

function stripTransparentWrapperTags(html) {
  return String(html || '').replace(/<\/?(synced-source|source-synced|reference-synced)\b[^>]*>/gi, '');
}

function splitHeadingsWrappingBlockContent(html) {
  return String(html || '').replace(/<h([1-6])\b([^>]*)>([\s\S]*?)<\/h\1>/gi, (full, level, attrs, inner) => {
    const firstBlockMatch = inner.match(/<(?:hr|p|ul|ol|blockquote|img|figure|grid)\b/i);
    if (!firstBlockMatch || firstBlockMatch.index === 0) return full;

    const headingText = inner.slice(0, firstBlockMatch.index).trim();
    const blockContent = inner.slice(firstBlockMatch.index).trim();
    if (!headingText || !blockContent) return full;

    return `<h${level}${attrs}>${headingText}</h${level}>${blockContent}`;
  });
}

const raw = splitHeadingsWrappingBlockContent(stripTransparentWrapperTags(fs.readFileSync(sourcePath, 'utf8')));
const root = parse(raw, {
  comment: true,
});

const title = root.querySelector('title')?.text.trim() || 'Evernote Presentation';
const presentationTitle = title.replace(/^【[^】]+】\s*/, '').trim() || title;
const body = root.querySelector('body');

if (!body) {
  console.error('Could not find <body> in source HTML.');
  process.exit(1);
}

function isSectionBreak(node) {
  if (!node || node.nodeType !== 1) {
    return false;
  }
  if (node.tagName !== 'HR') {
    return false;
  }
  const style = (node.getAttribute('style') || '').toLowerCase();
  return style.includes('-evernote-encp-section-break:true');
}

function normalizeNodeHtml(html) {
  return html
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+\n/g, '\n')
    .trim();
}

function normalizeLooseBody(body) {
  const parts = [];
  let newlineRun = 0;
  let paragraphBuffer = [];

  function flushParagraphBuffer() {
    if (!paragraphBuffer.length) return;
    parts.push(paragraphBuffer.join('\n'));
    paragraphBuffer = [];
  }

  for (const node of body.childNodes) {
    const html = normalizeNodeHtml(node.toString());
    if (!html) {
      continue;
    }

    if (/^<hr\b[^>]*\/?>$/i.test(html)) {
      flushParagraphBuffer();
      parts.push('__PAGE_BREAK__');
      newlineRun = 0;
      continue;
    }

    const isLooseBreak = /^<(div|p)>\s*(<br\s*\/?>\s*)<\/\1>$/i.test(html) || /^<br\s*\/?>$/i.test(html);
    if (isLooseBreak) {
      newlineRun += 1;
      if (newlineRun >= 2) {
        flushParagraphBuffer();
        parts.push('__PAGE_BREAK__');
        newlineRun = 0;
      }
      continue;
    }

    newlineRun = 0;

    if (
      /Part\s*[IVX0-9]/i.test(html) ||
      /Level[1-5]\./i.test(html) ||
      /background-color:\s*#fff199/i.test(html)
    ) {
      flushParagraphBuffer();
      parts.push('__PAGE_BREAK__');
      parts.push(html);
      continue;
    }

    const text = extractPlainText(html);
    const hasImage = /<img\b/i.test(html);
    const hasList = /<(ol|ul)\b/i.test(html);
    const isStandalone = hasImage || hasList;

    if (isStandalone) {
      flushParagraphBuffer();
      parts.push(html);
      continue;
    }

    paragraphBuffer.push(html);

    if (paragraphBuffer.length >= 5) {
      flushParagraphBuffer();
    }
  }

  flushParagraphBuffer();
  return parts;
}

function estimateBlockLines(node) {
  const text = (node.text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const textLines = text ? Math.max(1, Math.ceil(text.length / 22)) : 0;
  const imgCount = node.querySelectorAll ? node.querySelectorAll('img').length : 0;
  const listItems = node.querySelectorAll ? node.querySelectorAll('li').length : 0;
  const isTitleLike = /<(b|strong|u)\b/i.test(node.toString()) || /Part\s*[IVX0-9]|Level[1-5]\./i.test(text);

  let score = textLines;
  if (imgCount > 0) score += 4;
  if (listItems > 0) score += Math.ceil(listItems * 0.8);
  if (isTitleLike && text.length < 40) score += 1;
  return Math.max(1, score);
}

function splitLooseChunk(html) {
  html = html.replace(/<\/?(synced-source|source-synced|reference-synced)\b[^>]*>/gi, '');
  const wrapper = parse(`<div class="split-root">${html}</div>`);
  const rootNode = wrapper.querySelector('.split-root');
  if (!rootNode) return [html];

  const nodes = rootNode.childNodes.filter((node) => {
    const htmlValue = normalizeNodeHtml(node.toString());
    return htmlValue && !/^<div>\s*<\/div>$/i.test(htmlValue);
  });
  const semanticBlocks = groupNodesIntoSemanticBlocks(nodes);
  return paginateSemanticBlocks(semanticBlocks);
}

function getNodeText(node) {
  return (node.text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
}

function isContinuationText(text) {
  if (!text) return false;
  if (/^[：:，,、）)\]】]/.test(text)) return true;
  if (/^(而且|而是|但是|并且|以及|或者|所以|于是|因此|同时|然后|并|且|也|再|去|把|让|用|做|看|讲|展示|案例|互动|核心|本质|未来|过去)/.test(text)) return true;
  return false;
}

function endsWithOpenSyntax(text) {
  if (!text) return false;
  return /[：:,，、（(]$/.test(text);
}

function shouldStartNewSlide(currentNodes, nextNode, currentLines, blockLines, currentBlocks) {
  if (!currentNodes.length) return false;

  const nextText = getNodeText(nextNode);
  const currentText = currentNodes
    .map((html) => extractPlainText(html))
    .filter(Boolean)
    .join(' ');

  if (currentBlocks < 2 && currentLines < 5) return false;
  if (currentLines < 2) return false;
  if (currentLines >= 5 && currentBlocks >= 2) return true;

  if (endsWithOpenSyntax(currentText)) return false;
  if (isContinuationText(nextText)) return false;

  return currentLines + blockLines > 5;
}

function shouldForceFlush(currentNodes, node, currentLines, blockLines, currentBlocks) {
  const text = getNodeText(node);
  const hasImage = /<img\b/i.test(node.toString());
  if (hasImage) return true;
  if (blockLines >= 5 && currentLines >= 2 && currentBlocks >= 2) return true;
  if (currentLines >= 5 && !endsWithOpenSyntax(text) && currentBlocks >= 2) return true;
  return false;
}

function groupNodesIntoSemanticBlocks(nodes) {
  const groups = [];
  let current = [];

  function flush() {
    if (!current.length) return;
    groups.push(current);
    current = [];
  }

  for (const node of nodes) {
    const nodeHtml = normalizeNodeHtml(node.toString());
    if (!nodeHtml) continue;

    const text = getNodeText(node);
    const hasImage = /<img\b/i.test(nodeHtml);
    const hasList = /<(ol|ul)\b/i.test(nodeHtml);
    const isStrongBoundary = /Part\s*[IVX0-9]|Level[1-5]\.|background-color:\s*#fff199/i.test(nodeHtml);
    const isLead = /[:：]$/.test(text) || /^(提问|亮点预告|注意|第一次|第二次|第三次|总之一句话|今天我想分享四个话题|我给这节课灵感闪现了一大堆名字|核心Action|一个有趣的观察|通用范式)/.test(text);
    const isContinuation = isContinuationText(text) || /^[∴]/.test(text);

    if (isStrongBoundary || hasImage || hasList) {
      flush();
      groups.push([node]);
      continue;
    }

    if (!current.length) {
      current.push(node);
      continue;
    }

    const currentTexts = current.map(getNodeText).filter(Boolean);
    const lastText = currentTexts[currentTexts.length - 1] || '';
    const currentLineEstimate = current.reduce((sum, item) => sum + estimateBlockLines(item), 0);

    const shouldJoin =
      current.length < 3 &&
      (
        endsWithOpenSyntax(lastText) ||
        isLead ||
        isContinuation ||
        text.length <= 18 ||
        lastText.length <= 20 ||
        currentLineEstimate < 4
      );

    if (shouldJoin) {
      current.push(node);
      const newEstimate = current.reduce((sum, item) => sum + estimateBlockLines(item), 0);
      if (newEstimate >= 5 && !endsWithOpenSyntax(text) && !isContinuationText(text)) {
        flush();
      }
      continue;
    }

    flush();
    current.push(node);
  }

  flush();
  return groups;
}

function paginateSemanticBlocks(groups) {
  const pages = [];
  let current = [];
  let lineBudget = 0;

  function flush() {
    const output = normalizeNodeHtml(current.map((group) => group.map((node) => normalizeNodeHtml(node.toString())).join('\n')).join('\n'));
    if (output) pages.push(output);
    current = [];
    lineBudget = 0;
  }

  for (const group of groups) {
    const groupHtml = group.map((node) => normalizeNodeHtml(node.toString())).join('\n');
    const groupText = extractPlainText(groupHtml);
    const groupLines = Math.max(1, Math.min(5, group.reduce((sum, node) => sum + estimateBlockLines(node), 0)));
    const hasImage = /<img\b/i.test(groupHtml);
    const hasList = /<(ol|ul)\b/i.test(groupHtml);
    const isChapter = /Part\s*[IVX0-9]|Level[1-5]\.|background-color:\s*#fff199/i.test(groupHtml);
    const isLeadOnly = /[:：]$/.test(groupText);

    if (isChapter || hasImage) {
      flush();
      current = [group];
      flush();
      continue;
    }

    if (!current.length) {
      current.push(group);
      lineBudget += groupLines;
      continue;
    }

    const currentText = current
      .map((g) => extractPlainText(g.map((node) => normalizeNodeHtml(node.toString())).join('\n')))
      .join(' ');
    const currentEndsOpen = endsWithOpenSyntax(currentText);
    const continuation = isContinuationText(groupText);
    const currentGroupCount = current.length;

    const shouldKeepTogether =
      currentEndsOpen ||
      continuation ||
      isLeadOnly ||
      (currentGroupCount < 2 && lineBudget < 4) ||
      (hasList && currentGroupCount === 1) ||
      (groupText.length <= 18 && currentGroupCount < 3);

    if (!shouldKeepTogether && lineBudget + groupLines > 5 && currentGroupCount >= 1) {
      flush();
    }

    current.push(group);
    lineBudget += groupLines;

    if ((lineBudget >= 5 && current.length >= 2 && !endsWithOpenSyntax(groupText) && !isContinuationText(groupText)) || (hasList && lineBudget >= 4)) {
      flush();
    }
  }

  flush();
  return pages;
}

function getCodeFenceInfo(text) {
  const match = String(text || '').trim().match(/^```([a-z0-9_-]+)?(?:\s+\{([^}]+)\})?\s*$/i);
  if (!match) return null;
  return {
    lang: (match[1] || 'plaintext').trim() || 'plaintext',
    wrap: /\bwrap\b/i.test(match[2] || ''),
  };
}

function nodeToCodeLines(node) {
  if (!node) return [];
  const tagName = node.tagName || '';

  if (tagName === 'OL' || tagName === 'UL') {
    return node.querySelectorAll('li').map((item, index) => {
      const prefix = tagName === 'OL' ? `${index + 1}. ` : '- ';
      return `${prefix}${getNodeText(item)}`;
    }).filter((line) => line.trim());
  }

  const text = getNodeText(node);
  return text ? [text] : [];
}

function codeVisualLength(line) {
  return Array.from(String(line || '')).reduce((total, char) => {
    if (/\s/.test(char)) return total + 0.35;
    if (/[\u0000-\u00ff]/.test(char)) return total + 0.62;
    return total + 1;
  }, 0);
}

function codeWidthCh(lines) {
  const longest = Math.max(0, ...lines.map(codeVisualLength));
  return Math.round(Math.max(20, Math.min(longest + 2, 44)));
}

function buildCodeBlock(lang, lines) {
  const code = lines.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  if (!code) return '';
  const safeLang = escapeHtml(lang || 'plaintext');
  const widthCh = codeWidthCh(code.split('\n'));
  return [
    '<div class="code-window" data-code-lang="', safeLang, '" style="--code-ch:', String(widthCh), ';">',
    '<div class="code-window__top">',
    '<span class="code-window__traffic"><span></span><span></span><span></span></span>',
    '<span class="code-window__lang">', safeLang, '</span>',
    '</div>',
    '<pre class="code-window__pre"><code>', escapeHtml(code), '</code></pre>',
    '</div>',
  ].join('');
}

function getSmartLinkLabel(textBeforeUrl) {
  const raw = String(textBeforeUrl || '').replace(/\s+/g, ' ').trim();
  if (!raw) return '';
  const bracketTitle = raw.match(/(?:^|[\s，。；、])(?:快速)?访问链接[（(]([^）)]+)[）)][：:][^：:]*$/);
  if (bracketTitle?.[1]?.trim()) {
    return bracketTitle[1].trim();
  }
  const matches = [
    ...raw.matchAll(/(?:^|[\s，。；、（(])([\u4e00-\u9fa5A-Za-z0-9·・：:（）()《》「」“”"' -]{2,28}(?:链接|访问|回放|案例|入口|跳转|查看)[\u4e00-\u9fa5A-Za-z0-9·・：:（）()《》「」“”"' -]{0,18})[：:]\s*$/g),
  ];
  if (!matches.length) return '';
  return matches[matches.length - 1][1]
    .replace(/[：:]\s*$/g, '')
    .replace(/^(?:快速)?访问链接(?:（[^）]+）)?$/i, '点击此处跳转')
    .trim();
}

function normalizeSmartUrl(url) {
  let cleaned = String(url || '').trim();
  let suffix = '';
  while (/[，。；、,.;]$/.test(cleaned)) {
    suffix = cleaned.slice(-1) + suffix;
    cleaned = cleaned.slice(0, -1);
  }
  const parenMatch = cleaned.match(/(（[^）]*）|\([^)]*\))$/);
  if (parenMatch && !parenMatch[0].includes('/')) {
    suffix = parenMatch[0] + suffix;
    cleaned = cleaned.slice(0, -parenMatch[0].length);
  }
  return { url: cleaned, suffix };
}

function linkifyTextNode(text) {
  const value = String(text || '');
  const urlRe = /https?:\/\/[^\s<>'")，。；、]+(?:[^\s<>'"，。；、)]|\/)?(?:（[^）]*）|\([^)]*\))?/g;
  let lastIndex = 0;
  let output = '';
  let changed = false;

  for (const match of value.matchAll(urlRe)) {
    const rawUrl = match[0];
    const start = match.index || 0;
    const before = value.slice(lastIndex, start);
    const { url, suffix } = normalizeSmartUrl(rawUrl);
    if (!url) continue;

    output += escapeHtml(before);
    const label = getSmartLinkLabel(value.slice(0, start)) || '点击此处跳转';
    output += [
      '<a class="smart-link" href="', escapeHtml(url), '" target="_blank" rel="noopener noreferrer">',
      escapeHtml(label),
      '</a>',
      escapeHtml(suffix),
    ].join('');
    lastIndex = start + rawUrl.length;
    changed = true;
  }

  if (!changed) return null;
  output += escapeHtml(value.slice(lastIndex));
  return output;
}

function linkifyPlainUrls(html) {
  const root = parse(`<div class="linkify-root">${html}</div>`);
  const container = root.querySelector('.linkify-root');
  if (!container) return html;

  const skipTags = new Set(['A', 'CODE', 'PRE', 'SCRIPT', 'STYLE']);
  const voidTags = new Set(['AREA', 'BASE', 'BR', 'COL', 'EMBED', 'HR', 'IMG', 'INPUT', 'LINK', 'META', 'PARAM', 'SOURCE', 'TRACK', 'WBR']);
  const serialize = (node, skip = false) => {
    const tagName = node.tagName || '';
    const shouldSkip = skip || skipTags.has(tagName) || node.classList?.contains('code-window');
    if (node.nodeType === 3 && !shouldSkip) {
      const linked = linkifyTextNode(node.rawText || node.text || '');
      return linked || node.toString();
    }
    if (node.nodeType !== 1 || shouldSkip) {
      return node.toString();
    }

    const rawTag = node.rawTagName || tagName.toLowerCase();
    const attrs = node.rawAttrs ? ` ${node.rawAttrs}` : '';
    if (voidTags.has(tagName)) {
      return `<${rawTag}${attrs}>`;
    }
    const children = [...(node.childNodes || [])].map((child) => serialize(child, shouldSkip)).join('');
    return `<${rawTag}${attrs}>${children}</${rawTag}>`;
  };

  return [...container.childNodes].map((child) => serialize(child)).join('');
}

function transformFencedCodeBlocks(html) {
  const root = parse(`<div class="code-fence-root">${html}</div>`);
  const container = root.querySelector('.code-fence-root');
  if (!container) return html;

  const output = [];
  const nodes = [...container.childNodes];
  let index = 0;

  while (index < nodes.length) {
    const node = nodes[index];
    const fence = getCodeFenceInfo(getNodeText(node));

    if (!fence) {
      output.push(node.toString());
      index += 1;
      continue;
    }

    const lines = [];
    index += 1;
    while (index < nodes.length) {
      const current = nodes[index];
      if (String(getNodeText(current)).trim() === '```') {
        index += 1;
        break;
      }
      lines.push(...nodeToCodeLines(current));
      index += 1;
    }

    const codeBlock = buildCodeBlock(fence.lang, lines);
    if (codeBlock) output.push(codeBlock);
  }

  return output.join('\n');
}

function cleanSlideHtml(html) {
  html = transformFencedCodeBlocks(html);
  html = linkifyPlainUrls(html);
  const root = parse(`<div class="cleanup-root">${html}</div>`);
  const cleanupRoot = root.querySelector('.cleanup-root');
  if (!cleanupRoot) {
    return html;
  }

  let changed = true;
  while (changed) {
    changed = false;
    const allNodes = cleanupRoot.querySelectorAll('*');

    for (const node of allNodes) {
      if (node.tagName === 'BR') {
        const parent = node.parentNode;
        if (
          parent &&
          parent.childNodes.length === 1
        ) {
          node.remove();
          changed = true;
          continue;
        }
      }

      if (node.tagName === 'DIV') {
        const childElementCount = node.childNodes.filter((child) => child.nodeType === 1).length;
        const text = node.text.replace(/\u00a0/g, ' ').replace(/\s+/g, '').trim();
        const hasImg = node.querySelector('img');
        const hasTable = node.querySelector('table');
        const hasList = node.querySelector('ol, ul');

        if (!text && !hasImg && !hasTable && !hasList && childElementCount === 0) {
          node.remove();
          changed = true;
          continue;
        }

        if (
          !text &&
          childElementCount === 1 &&
          node.firstChild &&
          node.firstChild.nodeType === 1 &&
          node.firstChild.tagName === 'DIV'
        ) {
          const child = node.firstChild;
          node.replaceWith(child);
          changed = true;
          continue;
        }
      }
    }
  }

  let cleaned = cleanupRoot.innerHTML;
  cleaned = cleaned.replace(/(?:<div>\s*<\/div>\s*){2,}/gi, '<div></div>');
  cleaned = cleaned.replace(/(?:<br\s*\/?>\s*){3,}/gi, '<br><br>');
  return cleaned.trim();
}

function isMeaningfulHtml(html) {
  const textOnly = html
    .replace(/<br\s*\/?>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  const hasMedia = /<(img|table|ul|ol|blockquote|pre|code)\b/i.test(html);
  return Boolean(textOnly || hasMedia);
}

function absolutizeResources(html) {
  return html.replace(
    /(src|href)=("([^"]+)"|'([^']+)')/gi,
    (full, attr, quoted, doubleUrl, singleUrl) => {
      const url = doubleUrl || singleUrl || '';
      if (
        !url ||
        url.startsWith('http://') ||
        url.startsWith('https://') ||
        url.startsWith('mailto:') ||
        url.startsWith('evernote:') ||
        url.startsWith('#') ||
        url.startsWith('data:')
      ) {
        return `${attr}=${quoted}`;
      }

      const decoded = decodeURIComponent(url);
      const absolute = path.resolve(sourceDir, decoded);
      const relative = path.relative(outputDir, absolute).split(path.sep).join('/');
      const quote = quoted[0];
      return `${attr}=${quote}${relative}${quote}`;
    }
  );
}

function slideKind(html) {
  const imgCount = (html.match(/<img\b/gi) || []).length;
  const textOnly = html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  const textBlocks = [...html.matchAll(/<(?:p|div|h[1-6]|li)\b[^>]*>([\s\S]*?)<\/(?:p|div|h[1-6]|li)>/gi)]
    .map((match) => match[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim())
    .filter(Boolean);
  if (imgCount > 1) {
    return 'mixed';
  }
  if (/<ol\b|<ul\b/i.test(html)) {
    return 'list';
  }
  if (imgCount === 1 && textOnly.length < 80 && textBlocks.length <= 1) {
    return 'visual';
  }
  if (imgCount === 1 && textOnly.length > 0) {
    return 'mixed';
  }
  return 'content';
}

function stripSlideDirectiveShells(html) {
  let cleaned = html;
  cleaned = cleaned.replace(/<(div|p)>\s*<\/\1>/gi, '');
  cleaned = cleaned.replace(/<(div|p)>\s*(?:<br\s*\/?>\s*)<\/\1>/gi, '');
  return cleanSlideHtml(cleaned);
}

function extractSlideDirectives(html) {
  let bg = null;
  let centered = false;
  let cleaned = html;

  const bgPattern = /(?:&lt;|<)\s*bg\s*(?:[:：]|\s)?\s*(20|1\d|[1-9])\s*(?:&gt;|>)/gi;
  cleaned = cleaned.replace(bgPattern, (_, number) => {
    bg = Number(number);
    return '';
  });

  const centerPattern = /(?:&lt;|<)\s*居中\s*(?:&gt;|>)/gi;
  cleaned = cleaned.replace(centerPattern, () => {
    centered = true;
    return '';
  });

  cleaned = stripSlideDirectiveShells(cleaned);

  return {
    html: cleaned,
    bg,
    centered,
  };
}

function findBackgroundAsset(number) {
  const padded = String(number).padStart(2, '0');
  const candidates = ['png', 'jpg', 'jpeg', 'webp'].map((ext) => path.join(backgroundAssetsDir, `bg-${padded}.${ext}`));
  return candidates.find((candidate) => fs.existsSync(candidate)) || null;
}

function bundleBackgroundAsset(number) {
  const assetPath = findBackgroundAsset(number);
  if (!assetPath) return null;

  fs.mkdirSync(deckResourcesDir, { recursive: true });
  const outputName = `bg-${String(number).padStart(2, '0')}${path.extname(assetPath).toLowerCase()}`;
  const bundledPath = path.join(deckResourcesDir, outputName);
  if (!fs.existsSync(bundledPath)) {
    fs.copyFileSync(assetPath, bundledPath);
  }
  return path.relative(outputDir, bundledPath).split(path.sep).join('/');
}

function extractPlainText(html) {
  return html.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
}

function extractNavLabel(html) {
  const root = parse(`<div class="nav-label-root">${html}</div>`);
  const container = root.querySelector('.nav-label-root');
  if (!container) return '';

  const topLevelCandidates = container.childNodes.filter((node) => node.nodeType === 1);
  for (const node of topLevelCandidates) {
    const text = extractPlainText(node.toString());
    if (!text) continue;

    if (/^Part\s*[IVX0-9]/i.test(text)) {
      return text;
    }
    if (/^Level\s*[1-9]/i.test(text)) {
      return text;
    }
  }

  const candidates = container.querySelectorAll('*');
  for (const node of candidates) {
    const text = extractPlainText(node.toString());
    if (!text) continue;

    const isPart = /^Part\s*[IVX0-9]/i.test(text);
    const isLevel = /^Level\s*[1-9]/i.test(text);
    if (!isPart && !isLevel) continue;

    if (isPart) return text;
    return text;
  }

  return extractPlainText(html);
}

function extractSlideTitleLabel(html, role) {
  const root = parse(`<div class="nav-title-root">${html}</div>`);
  const container = root.querySelector('.nav-title-root');
  if (!container) return '';

  const cleanLabel = (text) => text
    .replace(/\s+/g, ' ')
    .replace(/^[\-\u2022•·\d.\s]+/, '')
    .trim();

  const topLevelElements = container.childNodes.filter((node) => node.nodeType === 1);
  const headingNodes = container.querySelectorAll('h1, h2, h3, h4, h5, h6');
  for (const node of headingNodes) {
    const text = cleanLabel(extractPlainText(node.toString()));
    if (text) return text.slice(0, 72);
  }

  const preferredTopLevel = topLevelElements.find((node) => {
    const htmlText = node.toString();
    const text = cleanLabel(extractPlainText(htmlText));
    if (!text || text.length > 80) return false;
    return (
      /<(b|strong)\b/i.test(htmlText) ||
      /font-size:\s*(2[4-9]|[3-9]\d)px/i.test(htmlText) ||
      /^Part\s*[IVX0-9]/i.test(text) ||
      /^P[1-9]\b/i.test(text) ||
      /^Level\s*[1-9]/i.test(text)
    );
  });

  if (preferredTopLevel) {
    return cleanLabel(extractPlainText(preferredTopLevel.toString())).slice(0, 72);
  }

  const firstTopLevel = topLevelElements.find((node) => {
    const text = cleanLabel(extractPlainText(node.toString()));
    if (!text) return false;
    if (/<img\b|<table\b|<ul\b|<ol\b/i.test(node.toString())) return false;
    return true;
  });

  if (firstTopLevel) {
    const text = cleanLabel(extractPlainText(firstTopLevel.toString()));
    if (role === 'chapter' || text.length <= 48 || /[：:]/.test(text)) {
      return text.slice(0, 72);
    }
  }

  if (role === 'chapter') {
    return extractNavLabel(html).slice(0, 72);
  }

  return '';
}

function toStructuredNavEntry(rawLevel, rawLabel, role) {
  const level = Number(rawLevel || '0');
  const label = (rawLabel || '').replace(/\s+/g, ' ').trim();
  if (!level || !label) return null;

  return {
    level: Math.min(Math.max(level, 1), 3),
    label: label.slice(0, 72),
    role: role === 'chapter' || level === 1 ? 'part' : level === 2 ? 'section' : 'subsection',
  };
}

function extractStructuredNavEntries(html, role) {
  const root = parse(`<div class="nav-structured-root">${html}</div>`);
  const container = root.querySelector('.nav-structured-root');
  if (!container) return [];

  const taggedEntries = container
    .querySelectorAll('[data-nav-level][data-nav-label]')
    .map((tagged) => toStructuredNavEntry(
      tagged.getAttribute('data-nav-level'),
      tagged.getAttribute('data-nav-label'),
      role,
    ))
    .filter(Boolean);
  if (taggedEntries.length) return taggedEntries;

  return container
    .querySelectorAll('h1, h2, h3, h4, h5, h6')
    .map((heading) => {
    const headingMatch = heading.rawTagName.match(/^h([1-6])$/i);
    const rawLevel = Number(headingMatch?.[1] || '0');
    const rawLabel = extractPlainText(heading.toString()).replace(/\s+/g, ' ').trim();
    return toStructuredNavEntry(rawLevel, rawLabel, role);
    })
    .filter(Boolean);
}

function detectSlideRole(html, kind) {
  const plainText = extractPlainText(html);
  const imgCount = (html.match(/<img\b/gi) || []).length;
  const listCount = (html.match(/<(ol|ul)\b/gi) || []).length;
  const tableCount = (html.match(/<table\b/gi) || []).length;
  const looksLikePart = /\bPart\s*[IVX0-9]/i.test(plainText);
  const hasExplicitLargeTitle = /font-size:\s*(2[4-9]|[3-9]\d)px/i.test(html);

  if (kind === 'visual' && imgCount > 0) {
    return 'visual';
  }
  if (looksLikePart && hasExplicitLargeTitle && imgCount === 0 && listCount === 0) {
    return 'chapter';
  }
  if (/^Level[1-5]\./i.test(plainText) && plainText.length <= 28) {
    return 'chapter';
  }
  if (kind === 'list') {
    return 'list';
  }
  if (imgCount > 0 && plainText.length > 0) {
    return 'mixed';
  }
  if (tableCount > 0) {
    return 'data';
  }
  return 'body';
}

function shouldDropSlide(html) {
  const plainText = extractPlainText(html);
  const imgCount = (html.match(/<img\b/gi) || []).length;
  const listCount = (html.match(/<(ol|ul)\b/gi) || []).length;
  const tableCount = (html.match(/<table\b/gi) || []).length;
  const breakOnlyDivCount = (html.match(/<div>\s*(<br\s*\/?>\s*)+<\/div>/gi) || []).length;

  if (!plainText && !imgCount && !listCount && !tableCount) {
    return true;
  }
  if (!plainText && imgCount === 0 && breakOnlyDivCount > 0) {
    return true;
  }
  return false;
}

const chunks = [];
let current = [];

function pushCurrent() {
  const html = normalizeNodeHtml(current.join('\n'));
  if (html && isMeaningfulHtml(html)) {
    chunks.push(html);
  }
  current = [];
}

const hasEvernoteSectionBreaks = body.innerHTML.includes('-evernote-encp-section-break:true');
const hasManualHrBreaks = /<hr\b/i.test(body.innerHTML) && !hasEvernoteSectionBreaks;

if (hasEvernoteSectionBreaks) {
  for (const node of body.childNodes) {
    if (isSectionBreak(node)) {
      pushCurrent();
      continue;
    }

    const html = node.toString();
    if (/<hr\b[^>]*-evernote-encp-section-break:true/i.test(html)) {
      const parts = html.split(/<hr\b[^>]*-evernote-encp-section-break:true[^>]*\/?>/i);
      for (let i = 0; i < parts.length; i += 1) {
        const part = normalizeNodeHtml(parts[i]);
        if (part) {
          current.push(part);
        }
        if (i < parts.length - 1) {
          pushCurrent();
        }
      }
      continue;
    }

    current.push(html);
  }
} else if (hasManualHrBreaks) {
  for (const node of body.childNodes) {
    const html = normalizeNodeHtml(node.toString());
    if (!html) continue;

    if (/^<hr\b[^>]*\/?>$/i.test(html)) {
      pushCurrent();
      continue;
    }

    current.push(html);
  }
} else {
  const looseParts = normalizeLooseBody(body);
  for (const part of looseParts) {
    if (part === '__PAGE_BREAK__') {
      pushCurrent();
      continue;
    }
    const subParts = splitLooseChunk(part);
    for (const subPart of subParts) {
      if (subPart === '__PAGE_BREAK__') {
        pushCurrent();
        continue;
      }
      current.push(subPart);
    }
    pushCurrent();
  }
}

pushCurrent();

const slides = chunks.map((html, index) => {
  const cleanedHtml = cleanSlideHtml(html);
  const directed = extractSlideDirectives(cleanedHtml);
  const safeHtml = absolutizeResources(directed.html);
  return {
    sourceIndex: index + 1,
    kind: slideKind(safeHtml),
    html: safeHtml,
    bg: directed.bg,
    centered: directed.centered,
  };
}).filter((slide) => !shouldDropSlide(slide.html))
  .map((slide, index) => ({
    ...slide,
    index: index + 1,
    role: detectSlideRole(slide.html, slide.kind),
    backgroundUrl: slide.bg ? bundleBackgroundAsset(slide.bg) : null,
  }));

const slidesMarkup = slides
  .map(
    (slide, index) => {
      const classes = [
        'slide',
        `slide--${slide.kind}`,
        `slide--${slide.role}`,
        slide.backgroundUrl ? 'slide--bg' : '',
        slide.centered ? 'slide--center-quote' : '',
      ].filter(Boolean).join(' ');
      const style = slide.backgroundUrl ? ` style="--slide-bg-image: url('${slide.backgroundUrl.replace(/'/g, '%27')}')"` : '';

      return `
      <section class="${classes}" data-index="${index}"${style}>
        <div class="slide__inner">
          <div class="slide__stack">
            <div class="slide__body">
              ${slide.html}
            </div>
            <div class="slide__thumbs" hidden></div>
          </div>
        </div>
      </section>
    `;
    }
  )
  .join('\n');

const coverBackgroundPath = path.join(projectRoot, 'assets', 'cover-default.png');
const coverBackgroundFile = path.basename(coverBackgroundPath);
const bundledCoverBackgroundPath = path.join(deckResourcesDir, coverBackgroundFile);
const faviconPath = path.join(projectRoot, 'assets', 'favicon.ico');
const faviconFile = path.basename(faviconPath);
const bundledFaviconPath = path.join(deckResourcesDir, faviconFile);
if (fs.existsSync(coverBackgroundPath)) {
  fs.mkdirSync(deckResourcesDir, { recursive: true });
  fs.copyFileSync(coverBackgroundPath, bundledCoverBackgroundPath);
}
if (fs.existsSync(faviconPath)) {
  fs.mkdirSync(deckResourcesDir, { recursive: true });
  fs.copyFileSync(faviconPath, bundledFaviconPath);
}
const coverBackgroundRelative = fs.existsSync(bundledCoverBackgroundPath)
  ? path.relative(outputDir, bundledCoverBackgroundPath).split(path.sep).join('/')
  : path.relative(outputDir, coverBackgroundPath).split(path.sep).join('/');
const faviconRelative = fs.existsSync(bundledFaviconPath)
  ? path.relative(outputDir, bundledFaviconPath).split(path.sep).join('/')
  : path.relative(outputDir, faviconPath).split(path.sep).join('/');
const coverMarkup = `
      <section class="slide slide--content slide--cover is-active">
        <div class="slide__inner">
          <div class="slide__stack">
            <div class="slide__body">
              <div>${escapeHtml(presentationTitle)}</div>
            </div>
            <div class="slide__thumbs" hidden></div>
          </div>
        </div>
      </section>
`;

const navEntries = [
  { slideIndex: 0, level: 1, label: '封面', role: 'cover' },
  { slideIndex: 1, level: 1, label: '开始第一页', role: 'intro' },
  ...slides
    .flatMap((slide, index) => {
      const structuredEntries = extractStructuredNavEntries(slide.html, slide.role);
      return structuredEntries.map((structuredEntry) => ({
        slideIndex: index + 1,
        level: structuredEntry.level,
        label: structuredEntry.label,
        role: structuredEntry.role,
      }));
    })
];

const navMarkup = navEntries
  .map((entry) => {
    const safeLabel = escapeHtml(entry.label);
    return `<button type="button" class="nav-item nav-item--level-${entry.level}" data-target-slide="${entry.slideIndex}" data-nav-role="${entry.role}">
      <span class="nav-item__label">${safeLabel}</span>
    </button>`;
  })
  .join('\n');

const diagnostics = slides.map((slide) => {
  const plainText = slide.html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  const imageCount = (slide.html.match(/<img\b/gi) || []).length;
  const tableCount = (slide.html.match(/<table\b/gi) || []).length;
  const listCount = (slide.html.match(/<(ol|ul)\b/gi) || []).length;
  const emptyDivCount = (slide.html.match(/<div>\s*<\/div>/gi) || []).length;
  const breakOnlyDivCount = (slide.html.match(/<div>\s*(<br\s*\/?>\s*)+<\/div>/gi) || []).length;
  const longLineRisk = plainText.length > 180;
  const visualRisk = imageCount > 0 && plainText.length > 380;

  const issues = [];
  if (emptyDivCount > 0) issues.push('contains-empty-div');
  if (breakOnlyDivCount > 0) issues.push('contains-break-only-div');
  if (tableCount > 0) issues.push('contains-table');
  if (longLineRisk) issues.push('long-copy');
  if (visualRisk) issues.push('image-and-heavy-copy');

  return {
    slide: slide.index,
    kind: slide.kind,
    role: slide.role,
    chars: plainText.length,
    images: imageCount,
    tables: tableCount,
    lists: listCount,
    issues,
    preview: plainText.slice(0, 80),
  };
});

const outputHtml = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escapeHtml(presentationTitle)} - HTML PPT</title>
  <link rel="icon" href="${faviconRelative}" type="image/x-icon" />
  <style>
    :root {
      --bg-1: #f0e7db;
      --bg-2: #cdb9a3;
      --paper: rgba(255, 255, 255, 0.97);
      --text: #1f2937;
      --muted: #6b7280;
      --accent: #c2410c;
      --accent-soft: #ffedd5;
      --border: rgba(31, 41, 55, 0.08);
      --chapter-border: rgba(194, 65, 12, 0.16);
      --slide-w: min(92vw, 1280px);
      --slide-h: min(78vh, 720px);
      --font-sans: "PingFang SC", "Hiragino Sans GB", "Noto Sans SC", "Microsoft YaHei", sans-serif;
    }

    * {
      box-sizing: border-box;
    }

    html, body {
      margin: 0;
      min-height: 100%;
      font-family: var(--font-sans);
      color: var(--text);
      background:
        radial-gradient(circle at 12% 14%, rgba(255,255,255,0.92), transparent 19%),
        radial-gradient(circle at 86% 82%, rgba(142,100,63,0.12), transparent 24%),
        linear-gradient(138deg, var(--bg-1) 0%, #e1d3c1 50%, var(--bg-2) 100%);
    }

    body {
      overflow: hidden;
    }

    body::before {
      content: "";
      position: fixed;
      inset: 0;
      pointer-events: none;
      background-image:
        radial-gradient(rgba(108, 82, 58, 0.08) 0.7px, transparent 0.9px),
        linear-gradient(115deg, transparent 0 46%, rgba(126, 98, 74, 0.045) 46% 47%, transparent 47% 100%);
      background-size: 22px 22px, 34px 34px;
      opacity: 0.12;
      z-index: 0;
    }

    .app {
      position: relative;
      z-index: 1;
      min-height: 100vh;
      display: block;
      padding: 0;
    }

    .viewport {
      position: relative;
      width: 100%;
      display: grid;
      place-items: center;
    }

    .slides {
      position: relative;
      width: 100vw;
      height: 100vh;
      overflow: hidden;
      isolation: isolate;
      perspective: 1200px;
    }

    .slide {
      position: absolute;
      inset: 0;
      opacity: 1;
      pointer-events: none;
      transform: translate3d(0, 100%, 0);
      transition: transform 320ms cubic-bezier(0.4, 0, 0.2, 1), opacity 180ms ease;
      will-change: transform, opacity;
    }

    .slide.is-active {
      opacity: 1;
      pointer-events: auto;
      transform: translate3d(0, 0, 0);
      z-index: 3;
    }

    .slide.is-before {
      opacity: 0.85;
      transform: translate3d(0, -100%, 0);
      z-index: 2;
    }

    .slide.is-after {
      opacity: 0.85;
      transform: translate3d(0, 100%, 0);
      z-index: 1;
    }

    .slide.is-hidden {
      transition: none;
    }

    .slide__inner {
      height: 100%;
      overflow: auto;
      padding: 72px 84px 56px 148px;
      border: 0;
      border-radius: 0;
      background: transparent;
      box-shadow: none;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: stretch;
    }

    .slide__inner::-webkit-scrollbar {
      width: 10px;
    }

    .slide__inner::-webkit-scrollbar-thumb {
      background: rgba(107, 114, 128, 0.28);
      border-radius: 999px;
    }

    .slide__stack {
      width: 100%;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: stretch;
      gap: 0;
      flex: 0 0 auto;
    }

    .slide__body {
      width: 100%;
      text-align: left;
    }

    .slide--chapter .slide__inner {
      background:
        linear-gradient(180deg, rgba(255,255,255,0.36), rgba(255,249,244,0.2)),
        linear-gradient(135deg, rgba(194,65,12,0.05), transparent 36%);
    }

    .slide--bg .slide__inner {
      position: relative;
      overflow: hidden;
      background:
        linear-gradient(rgba(0, 0, 0, 0.64), rgba(0, 0, 0, 0.64)),
        var(--slide-bg-image) center center / cover no-repeat;
    }

    .slide--bg .slide__stack {
      position: relative;
      z-index: 1;
    }

    .slide--bg .slide__body,
    .slide--bg .slide__body div,
    .slide--bg .slide__body p,
    .slide--bg .slide__body li,
    .slide--bg .slide__body span,
    .slide--bg .slide__body b,
    .slide--bg .slide__body strong {
      color: rgba(255, 255, 255, 0.96) !important;
      text-shadow: 0 10px 30px rgba(0, 0, 0, 0.32);
    }

    .slide--bg .slide__body span[style*="background-color: #FFF199"],
    .slide--bg .slide__body span[style*="background-color: #fff199"] {
      color: #111827 !important;
      text-shadow: none;
    }

    .slide--center-quote .slide__inner {
      padding: 64px 96px;
      justify-content: center;
      align-items: center;
    }

    .slide--center-quote .slide__stack {
      min-height: 100%;
      justify-content: center;
      align-items: center;
    }

    .slide--center-quote .slide__body {
      max-width: min(78vw, 1180px);
      text-align: center;
    }

    .slide--center-quote .slide__body > * {
      text-align: center !important;
      margin-left: auto;
      margin-right: auto;
    }

    .slide--center-quote .slide__inner div,
    .slide--center-quote .slide__inner p,
    .slide--center-quote .slide__inner li,
    .slide--center-quote .slide__inner span,
    .slide--center-quote .slide__inner b,
    .slide--center-quote .slide__inner strong {
      font-size: clamp(44px, 5.2vw, 78px) !important;
      line-height: 1.18 !important;
      font-weight: 820 !important;
      letter-spacing: 0;
    }

    .slide--cover .slide__inner {
      padding: 0;
      background: #050505;
    }

    .slide--cover .slide__stack,
    .slide--cover .slide__body {
      width: 100%;
      min-height: 100%;
      height: 100%;
    }

    .slide--cover .slide__body {
      position: relative;
      display: grid;
      place-items: center;
      overflow: hidden;
      text-align: center;
      background:
        linear-gradient(rgba(0, 0, 0, 0.58), rgba(0, 0, 0, 0.58)),
        url("${coverBackgroundRelative}") center center / cover no-repeat;
    }

    .slide--cover .slide__body > * {
      position: relative;
      z-index: 1;
    }

    .slide--cover .slide__body > div:first-child,
    .slide--cover .slide__body > div:first-child span {
      max-width: min(88vw, 1320px);
      padding: 0 36px;
      color: rgba(255, 255, 255, 0.98);
      font-size: clamp(29px, 3.2vw, 48px);
      line-height: 1.18;
      letter-spacing: -0.04em;
      font-weight: 800 !important;
      text-align: center !important;
      text-shadow: 0 10px 32px rgba(0, 0, 0, 0.32);
    }

    .slide--chapter .slide__stack {
      min-height: 100%;
      justify-content: center;
    }

    .slide--chapter .slide__body {
      max-width: 1320px;
    }

    .slide--chapter .slide__body > * {
      text-align: left;
    }

    .slide--chapter .slide__body span[style*="font-weight: bold"],
    .slide--chapter .slide__body > div:first-child,
    .slide--chapter .slide__body > div:first-child span {
      font-size: clamp(23px, 2.4vw, 36px);
      line-height: 1.18;
      letter-spacing: -0.02em;
      font-weight: 800 !important;
      color: #111827;
      max-width: min(96vw, 1320px);
    }

    .slide--chapter .slide__body::before {
      content: "";
      display: block;
      width: 84px;
      height: 6px;
      margin: 0 0 28px;
      border-radius: 999px;
      background: linear-gradient(90deg, #ea580c, #fb923c);
    }

    .slide--body .slide__body,
    .slide--list .slide__body,
    .slide--mixed .slide__body,
    .slide--data .slide__body {
      max-width: none;
    }

    .slide--visual .slide__inner {
      justify-content: center;
    }

    .slide--list .slide__inner {
      padding-top: 60px;
      padding-bottom: 44px;
    }

    .slide.is-single-image .slide__inner,
    .slide--visual.is-single-image .slide__inner {
      justify-content: center;
      padding: 0;
      overflow: hidden;
    }

    .slide.is-single-image .slide__stack,
    .slide--visual.is-single-image .slide__stack {
      width: 100%;
      height: 100%;
      min-height: 100%;
      justify-content: center;
      align-items: center;
    }

    .slide.is-single-image .slide__body,
    .slide--visual.is-single-image .slide__body {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-end;
      position: relative;
      overflow: hidden;
      width: 100%;
      height: 100%;
      max-width: none;
      min-height: 100%;
      padding: 0;
    }

    .slide.is-fit .slide__inner {
      justify-content: center;
    }

    .slide.is-fit .slide__stack {
      min-height: 100%;
    }

    .slide.is-overflow .slide__inner {
      justify-content: flex-start;
    }

    .slide__body > :first-child {
      margin-top: 0;
    }

    .slide__body > :last-child {
      margin-bottom: 0;
    }

    .slide__inner div,
    .slide__inner p,
    .slide__inner li {
      font-size: 25.74px;
      line-height: 1.7;
    }

    .slide__inner p,
    .slide__inner ol,
    .slide__inner ul,
    .slide__inner table,
    .slide__inner blockquote,
    .slide__inner pre,
    .slide__inner > div {
      margin-top: 14px;
      margin-bottom: 14px;
    }

    .slide__body > div {
      margin-top: 12px;
      margin-bottom: 12px;
    }

    .slide__body > div:has(> div) {
      display: block;
    }

    .slide__body > div > div {
      margin-top: 8px;
      margin-bottom: 8px;
    }

    .slide__body br:only-child {
      display: none;
    }

    .slide__inner span[style*="font-weight: bold"] {
      font-weight: 800 !important;
    }

    .slide__inner span[style*="font-size: 18px"],
    .slide__inner span[style*="font-size:18px"],
    .slide__inner span[style*="font-size: 20px"],
    .slide__inner span[style*="font-size:20px"],
    .slide__inner span[style*="font-size: 21px"],
    .slide__inner span[style*="font-size:21px"],
    .slide__inner span[style*="font-size: 22px"],
    .slide__inner span[style*="font-size:22px"] {
      font-size: inherit !important;
      line-height: inherit !important;
    }

    .slide__inner span[style*="background-color: #FFF199"],
    .slide__inner span[style*="background-color: #fff199"] {
      background: linear-gradient(
        to top,
        rgba(255, 214, 92, 0.98) 0%,
        rgba(255, 214, 92, 0.98) 14%,
        rgba(255, 214, 92, 0.76) 14%,
        rgba(255, 214, 92, 0.76) 32%,
        rgba(255, 214, 92, 0.34) 32%,
        rgba(255, 214, 92, 0.34) 40%,
        rgba(255, 214, 92, 0) 40%,
        rgba(255, 241, 153, 0) 100%
      ) !important;
      box-decoration-break: clone;
      -webkit-box-decoration-break: clone;
      padding: 0 0.08em;
      filter: saturate(1.04);
    }

    .slide__body span[style*="font-size: 24px"][style*="background-color: #fff199"],
    .slide__body span[style*="font-size:24px"][style*="background-color: #fff199"],
    .slide__body span[style*="font-size: 24px"][style*="background-color: #FFF199"],
    .slide__body span[style*="font-size:24px"][style*="background-color: #FFF199"] {
      font-size: clamp(36px, 4.1vw, 56px) !important;
      line-height: 1.24 !important;
      letter-spacing: -0.02em;
      font-weight: 800 !important;
      color: #111827;
    }

    .slide__body > div:has(span[style*="font-size: 24px"][style*="background-color: #fff199"]),
    .slide__body > div:has(span[style*="font-size:24px"][style*="background-color: #fff199"]),
    .slide__body > div:has(span[style*="font-size: 24px"][style*="background-color: #FFF199"]),
    .slide__body > div:has(span[style*="font-size:24px"][style*="background-color: #FFF199"]),
    .slide__body > p:has(span[style*="font-size: 24px"][style*="background-color: #fff199"]),
    .slide__body > p:has(span[style*="font-size:24px"][style*="background-color: #fff199"]),
    .slide__body > p:has(span[style*="font-size: 24px"][style*="background-color: #FFF199"]),
    .slide__body > p:has(span[style*="font-size:24px"][style*="background-color: #FFF199"]) {
      margin-top: 10px;
      margin-bottom: 18px;
      line-height: 1.28;
    }

    .slide--chapter .slide__body:has([data-nav-level])::before {
      display: none;
    }

    .slide__body [data-nav-level] {
      max-width: min(92vw, 1180px);
      letter-spacing: 0;
    }

    .slide__body [data-nav-level] b,
    .slide__body [data-nav-level] strong,
    .slide__body [data-nav-level] span {
      font-size: inherit !important;
      line-height: inherit !important;
      font-weight: inherit !important;
      color: inherit !important;
      background: transparent !important;
      filter: none !important;
      text-shadow: inherit;
    }

    .slide__body [data-nav-level="1"],
    .slide__body [data-nav-level="2"] {
      display: inline-block;
      width: fit-content;
      padding: 8px 15px;
      border-radius: 6px;
      background: #111827;
      color: #fff !important;
      font-weight: 900 !important;
      box-shadow: 0 16px 34px rgba(17, 24, 39, 0.14);
    }

    .slide__body [data-nav-level="1"] {
      font-size: clamp(42px, 4.3vw, 64px);
      line-height: 1.12;
    }

    .slide--chapter .slide__body > div[data-nav-level="1"]:first-child {
      font-size: clamp(38px, 3.6vw, 54px) !important;
      line-height: 1.12 !important;
      font-weight: 900 !important;
    }

    .slide__body [data-nav-level="2"] {
      font-size: clamp(34px, 3.4vw, 50px);
      line-height: 1.18;
      background: rgba(17, 24, 39, 0.92);
    }

    .slide__body [data-nav-level="3"],
    .slide__body [data-nav-level="4"] {
      padding-left: 18px;
      border-left: 5px solid #d97706;
      color: #111827 !important;
      font-weight: 850 !important;
    }

    .slide__body [data-nav-level="3"] {
      font-size: clamp(32px, 3vw, 46px);
      line-height: 1.25;
    }

    .slide__body [data-nav-level="4"] {
      border-left-width: 3px;
      border-left-color: rgba(217, 119, 6, 0.46);
      font-size: clamp(26px, 2.4vw, 36px);
      line-height: 1.32;
      color: rgba(17, 24, 39, 0.72) !important;
      font-weight: 760 !important;
    }

    .code-window {
      width: calc(var(--code-ch, 42) * 16.5px + 42px);
      min-width: min(100%, 360px);
      max-width: min(100%, 72vw);
      overflow: hidden;
      border-radius: 9px;
      background: #fbfbfb;
      border: 1px solid rgba(31, 35, 40, 0.12);
      box-shadow: 0 10px 24px rgba(31, 35, 40, 0.06);
      margin: 14px 0;
    }

    .slide__inner .code-window,
    .slide__inner .code-window div,
    .slide__inner .code-window span,
    .slide__inner .code-window pre,
    .slide__inner .code-window code {
      letter-spacing: 0 !important;
      text-align: left !important;
      text-shadow: none !important;
      font-weight: 400 !important;
    }

    .code-window__top {
      display: flex;
      align-items: center;
      height: 32px;
      padding: 0 12px;
      background: #fff;
      color: rgba(16, 24, 40, 0.48);
      font-family: "SFMono-Regular", "Cascadia Code", "JetBrains Mono", "Fira Code", "Menlo", "Monaco", "Consolas", monospace;
      font-size: 12px !important;
      line-height: 32px !important;
      font-weight: 500 !important;
      border-bottom: 1px solid rgba(31, 35, 40, 0.08);
    }

    .code-window__traffic {
      display: flex;
      gap: 6px;
      margin-right: 10px;
      align-items: center;
    }

    .code-window__traffic span {
      width: 9px;
      height: 9px;
      display: block;
      border-radius: 50%;
      background: #ef4444;
      flex: 0 0 9px;
    }

    .code-window__traffic span:nth-child(2) {
      background: #f59e0b;
    }

    .code-window__traffic span:nth-child(3) {
      background: #22c55e;
    }

    .code-window__pre {
      margin: 0 !important;
      padding: 15px 20px;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      background: transparent;
      line-height: 1.54 !important;
    }

    .slide__inner .code-window .code-window__pre code {
      display: block;
      color: #393a34;
      font-family: "SFMono-Regular", "Cascadia Code", "JetBrains Mono", "Fira Code", "Menlo", "Monaco", "Consolas", "PingFang SC", monospace;
      font-size: 16.5px !important;
      line-height: 1.54 !important;
      font-weight: 500 !important;
      letter-spacing: 0;
    }

    .slide__inner a {
      color: var(--accent);
      text-decoration-thickness: 2px;
      text-underline-offset: 3px;
    }

    .slide__inner a.smart-link {
      display: inline;
      color: #ef1d1d;
      font-weight: 880;
      text-decoration: none;
      background: linear-gradient(180deg, transparent 50%, rgba(255, 210, 74, 0.78) 50%);
      padding: 0 4px;
      border-radius: 2px;
      box-decoration-break: clone;
      -webkit-box-decoration-break: clone;
    }

    .slide__inner a.smart-link::after {
      content: " ↗";
      color: #ef1d1d;
      font-size: 0.82em;
      font-weight: 900;
    }

    .slide__inner ol,
    .slide__inner ul {
      padding-left: 1.4em;
      margin: 18px 0;
    }

    .slide__inner ol,
    .slide__inner ul,
    .slide__inner table,
    .slide__inner blockquote,
    .slide__inner pre {
      width: 100%;
    }

    .slide__inner li + li {
      margin-top: 10px;
    }

    .slide--list .slide__body {
      max-width: none;
    }

    .slide--list .slide__inner li {
      line-height: 1.62;
    }

    .slide--list .slide__inner ol,
    .slide--list .slide__inner ul {
      padding-left: 1.2em;
    }

    .slide--list.is-compact-list .slide__inner {
      justify-content: center;
    }

    .slide--list.is-compact-list .slide__stack {
      min-height: 100%;
      justify-content: center;
    }

    .slide--list.is-compact-list .slide__body {
      max-width: none;
    }

    .slide--list.is-compact-list .slide__inner div,
    .slide--list.is-compact-list .slide__inner p,
    .slide--list.is-compact-list .slide__inner li {
      font-size: 23.8px;
      line-height: 1.54;
    }

    .slide--list.is-compact-list .slide__inner ol,
    .slide--list.is-compact-list .slide__inner ul,
    .slide--list.is-compact-list .slide__body > div {
      margin-top: 8px;
      margin-bottom: 8px;
    }

    .slide__inner img {
      display: none;
      max-width: 100%;
      max-height: 54vh;
      object-fit: contain;
      border-radius: 16px;
      box-shadow: 0 10px 24px rgba(15, 23, 42, 0.12);
      margin: 14px 10px;
      background: white;
    }

    .slide.is-single-image .slide__body img,
    .slide--visual.is-single-image .slide__body img {
      display: block;
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      max-width: none;
      max-height: none;
      object-fit: contain;
      margin: 0;
      border-radius: 0;
      box-shadow: none;
      background: transparent;
    }

    .slide.is-single-image .slide__body > :not(img),
    .slide--visual.is-single-image .slide__body > :not(img) {
      position: relative;
      z-index: 2;
      align-self: flex-start;
      max-width: min(72vw, 960px);
      margin: 4px 0 4px clamp(28px, 6vw, 96px);
      padding: 10px 16px;
      border-radius: 10px;
      color: rgba(255, 255, 255, 0.96);
      background: rgba(15, 23, 42, 0.48);
      text-align: left;
      text-shadow: 0 6px 18px rgba(0, 0, 0, 0.34);
      backdrop-filter: blur(8px);
    }

    .slide.is-single-image .slide__body > :not(img):empty,
    .slide--visual.is-single-image .slide__body > :not(img):empty {
      display: none;
    }

    .slide.is-single-image .slide__body > :not(img):last-child,
    .slide--visual.is-single-image .slide__body > :not(img):last-child {
      margin-bottom: clamp(28px, 6vh, 72px);
    }

    .slide.is-single-image.is-portrait-image .slide__body img,
    .slide--visual.is-single-image.is-portrait-image .slide__body img {
      height: 100vh;
    }

    .slide.is-single-image.is-wide-image .slide__inner,
    .slide--visual.is-single-image.is-wide-image .slide__inner,
    .is-fullscreen .slide.is-single-image.is-wide-image .slide__inner,
    .is-fullscreen .slide--visual.is-single-image.is-wide-image .slide__inner {
      padding: 0;
    }

    .slide.is-single-image.is-wide-image .slide__stack,
    .slide--visual.is-single-image.is-wide-image .slide__stack,
    .slide.is-single-image.is-wide-image .slide__body,
    .slide--visual.is-single-image.is-wide-image .slide__body,
    .is-fullscreen .slide.is-single-image.is-wide-image .slide__stack,
    .is-fullscreen .slide--visual.is-single-image.is-wide-image .slide__stack,
    .is-fullscreen .slide.is-single-image.is-wide-image .slide__body,
    .is-fullscreen .slide--visual.is-single-image.is-wide-image .slide__body {
      width: 100%;
      height: 100%;
      min-height: 100%;
    }

    .slide.is-single-image.is-wide-image .slide__body img,
    .slide--visual.is-single-image.is-wide-image .slide__body img,
    .is-fullscreen .slide.is-single-image.is-wide-image .slide__body img,
    .is-fullscreen .slide--visual.is-single-image.is-wide-image .slide__body img {
      width: 100%;
      height: 100%;
      max-width: none;
      max-height: none;
      object-fit: fill;
      border-radius: 0;
      box-shadow: none;
      margin: 0;
    }

    .slide--mixed .slide__body {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 10px 24px;
    }

    .slide--mixed .slide__body > div,
    .slide--mixed .slide__body > p {
      flex: 0 0 100%;
    }

    .slide--mixed .slide__body img {
      display: block;
      width: auto;
      flex: 1 1 360px;
      max-width: min(42vw, 620px);
      max-height: 34vh;
      object-fit: contain;
      margin: 10px 0 0;
      border-radius: 14px;
      box-shadow: 0 14px 32px rgba(15, 23, 42, 0.14);
      background: white;
    }

    .slide.has-image-gallery .slide__body img {
      display: none !important;
    }

    .slide__thumbs {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(132px, 132px));
      gap: 12px;
      width: 100%;
      justify-content: start;
      margin: 22px 0 0;
      padding-top: 16px;
      border-top: 1px solid rgba(31, 41, 55, 0.08);
    }

    .slide--chapter .slide__thumbs {
      display: none !important;
    }

    .slide--visual .slide__thumbs {
      border-top-color: rgba(194, 65, 12, 0.12);
    }

    .slide__thumbs[hidden] {
      display: none;
    }

    .slide.is-single-image .slide__thumbs,
    .slide--visual.is-single-image .slide__thumbs {
      display: none !important;
    }

    .thumb {
      position: relative;
      width: 132px;
      height: 84px;
      border: 1px solid rgba(31, 41, 55, 0.1);
      border-radius: 14px;
      overflow: hidden;
      background: #fff;
      cursor: pointer;
      padding: 0;
      box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
    }

    .thumb img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
      margin: 0;
      max-height: none;
      border-radius: 0;
      box-shadow: none;
    }

    .slide__inner table {
      width: 100%;
      border-collapse: collapse;
      margin: 18px 0;
      font-size: 28.08px;
      table-layout: fixed;
    }

    .slide--data .slide__inner table {
      font-size: 26.52px;
      background: rgba(248, 250, 252, 0.7);
      border-radius: 16px;
      overflow: hidden;
    }

    .slide__inner td,
    .slide__inner th {
      border: 1px solid rgba(31, 41, 55, 0.12);
      padding: 10px 12px;
      vertical-align: top;
    }

    .slide__inner hr {
      display: none;
    }

    .progress {
      position: fixed;
      left: 0;
      right: 0;
      bottom: 0;
      height: 8px;
      background: rgba(15, 23, 42, 0.08);
      overflow: hidden;
      z-index: 30;
    }

    .progress__bar {
      width: 0;
      height: 100%;
      background: linear-gradient(90deg, #ea580c, #fb923c);
      transition: width 220ms ease;
    }

    .fullscreen-fab {
      position: fixed;
      right: 18px;
      bottom: 18px;
      width: 36px;
      height: 36px;
      display: grid;
      place-items: center;
      border: 0;
      border-radius: 999px;
      color: rgba(31, 41, 55, 0.78);
      background: rgba(255, 255, 255, 0.72);
      backdrop-filter: blur(12px);
      box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
      z-index: 31;
      cursor: pointer;
    }

    .nav-fab {
      position: fixed;
      top: 16px;
      right: 18px;
      width: 34px;
      height: 34px;
      display: grid;
      place-items: center;
      border: 0;
      border-radius: 999px;
      color: rgba(31, 41, 55, 0.78);
      background: rgba(255, 255, 255, 0.52);
      backdrop-filter: blur(12px);
      box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
      z-index: 41;
      cursor: pointer;
    }

    .nav-fab:hover {
      background: rgba(255, 255, 255, 0.82);
    }

    .nav-fab svg {
      width: 15px;
      height: 15px;
    }

    .nav-drawer {
      position: fixed;
      top: 0;
      right: 0;
      width: min(360px, 82vw);
      height: 100vh;
      padding: 18px 14px 18px 18px;
      background: rgba(247, 242, 232, 0.84);
      backdrop-filter: blur(16px);
      border-left: 1px solid rgba(31, 41, 55, 0.08);
      box-shadow: -12px 0 36px rgba(15, 23, 42, 0.08);
      transform: translateX(100%);
      transition: transform 240ms ease;
      z-index: 40;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .nav-drawer.is-open {
      transform: translateX(0);
    }

    .nav-drawer__header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 4px 4px 0;
    }

    .nav-drawer__title {
      font-size: 13px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: rgba(31, 41, 55, 0.52);
    }

    .nav-drawer__close {
      width: 28px;
      height: 28px;
      border: 0;
      border-radius: 999px;
      background: rgba(255,255,255,0.6);
      color: rgba(31, 41, 55, 0.72);
      cursor: pointer;
    }

    .nav-drawer__list {
      flex: 1;
      overflow: auto;
      padding: 6px 4px 6px 0;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .nav-item {
      width: 100%;
      text-align: left;
      border: 0;
      border-radius: 12px;
      background: transparent;
      color: rgba(31, 41, 55, 0.86);
      padding: 10px 12px;
      cursor: pointer;
      transition: background 180ms ease, color 180ms ease, transform 180ms ease;
    }

    .nav-item:hover {
      background: rgba(255,255,255,0.72);
      transform: translateX(-1px);
    }

    .nav-item.is-active {
      background: rgba(255, 255, 255, 0.88);
      color: #111827;
      box-shadow: 0 8px 22px rgba(15, 23, 42, 0.06);
    }

    .nav-item--level-1 {
      font-size: 15px;
      font-weight: 700;
      line-height: 1.45;
      padding-left: 12px;
    }

    .nav-item--level-2 {
      font-size: 13px;
      font-weight: 560;
      line-height: 1.5;
      padding-left: 28px;
      color: rgba(55, 65, 81, 0.82);
    }

    .nav-item--level-3 {
      font-size: 13px;
      font-weight: 460;
      line-height: 1.5;
      padding-left: 48px;
      color: rgba(55, 65, 81, 0.78);
    }

    .nav-item__label {
      display: block;
      white-space: normal;
      word-break: break-word;
    }

    .nav-backdrop {
      position: fixed;
      inset: 0;
      background: rgba(15, 23, 42, 0.12);
      opacity: 0;
      pointer-events: none;
      transition: opacity 220ms ease;
      z-index: 39;
    }

    .nav-backdrop.is-open {
      opacity: 1;
      pointer-events: auto;
    }

    .fullscreen-fab:hover {
      background: rgba(255, 255, 255, 0.9);
    }

    .fullscreen-fab svg {
      width: 16px;
      height: 16px;
    }

    .is-fullscreen .fullscreen-fab {
      display: none;
    }

    @media (max-width: 900px) {
      .slide__inner {
        padding: 28px 24px 36px 40px;
      }

      .slide.is-single-image .slide__inner,
      .slide--visual.is-single-image .slide__inner {
        padding: 20px;
      }

      .slide__inner div,
      .slide__inner p,
      .slide__inner li {
        font-size: 28.08px;
      }

      .slide--mixed .slide__body {
        gap: 8px 14px;
      }

      .slide--mixed .slide__body img {
        flex-basis: 132px;
        max-width: min(42vw, 180px);
        max-height: 20vh;
        margin-top: 6px;
      }

      .slides {
        height: 100vh;
      }

      .slide__thumbs {
        grid-template-columns: repeat(auto-fit, minmax(108px, 108px));
      }

      .thumb {
        width: 108px;
        height: 68px;
      }

      .fullscreen-fab {
        right: 12px;
        bottom: 14px;
        width: 34px;
        height: 34px;
      }

      .nav-fab {
        top: 12px;
        right: 12px;
      }

      .nav-drawer {
        width: min(320px, 88vw);
      }
    }

    .lightbox {
      position: fixed;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 32px;
      background: rgba(15, 23, 42, 0.9);
      z-index: 50;
      touch-action: none;
      overscroll-behavior: contain;
      opacity: 0;
      visibility: hidden;
      pointer-events: none;
      transition: opacity 260ms ease, visibility 0ms linear 260ms;
    }

    .lightbox.is-open {
      opacity: 1;
      visibility: visible;
      pointer-events: auto;
      transition: opacity 260ms ease, visibility 0ms linear 0ms;
    }

    .lightbox.is-closing {
      opacity: 0;
    }

    .lightbox__img {
      --pan-x: 0px;
      --pan-y: 0px;
      --zoom: 1;
      --switch-x: 0%;
      --image-opacity: 1;
      max-width: min(92vw, 1800px);
      max-height: 88vh;
      object-fit: contain;
      border-radius: 20px;
      background: white;
      box-shadow: 0 16px 40px rgba(0, 0, 0, 0.28);
      transform-origin: center center;
      will-change: transform;
      user-select: none;
      -webkit-user-drag: none;
      opacity: var(--image-opacity);
      transform: translate(var(--switch-x), 0) translate(var(--pan-x), var(--pan-y)) scale(var(--zoom));
      transition: transform 380ms cubic-bezier(0.22, 1, 0.36, 1), opacity 240ms ease;
    }

    .lightbox.is-reading-long {
      touch-action: pan-y;
    }

    .lightbox.is-reading-long .lightbox__viewer {
      display: block;
      overflow-y: auto;
      overscroll-behavior: contain;
      padding: 24px 0 42px;
      scrollbar-width: thin;
      scrollbar-color: rgba(255,255,255,0.42) transparent;
    }

    .lightbox.is-reading-long .lightbox__img {
      display: block;
      width: min(66vw, 800px);
      max-width: none;
      max-height: none;
      height: auto;
      margin: 0 auto;
      object-fit: initial;
      transform: translate(var(--switch-x), 0);
      transform-origin: top center;
      cursor: ns-resize;
    }

    .lightbox__counter {
      position: absolute;
      left: 20px;
      bottom: 18px;
      padding: 6px 10px;
      border-radius: 999px;
      background: rgba(255,255,255,0.12);
      color: rgba(255,255,255,0.82);
      font-size: 12px;
      letter-spacing: 0.04em;
    }

    .lightbox__viewer {
      position: relative;
      width: min(92vw, 1800px);
      height: min(88vh, 1100px);
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      transform: scale(0.965);
      transition: transform 300ms cubic-bezier(0.22, 1, 0.36, 1), opacity 240ms ease;
    }

    .lightbox.is-open .lightbox__viewer {
      opacity: 1;
      transform: scale(1);
    }

    .lightbox.is-closing .lightbox__viewer {
      opacity: 0;
      transform: scale(0.965);
    }

    .lightbox__close {
      position: absolute;
      top: 18px;
      right: 18px;
      appearance: none;
      border: 0;
      width: 42px;
      height: 42px;
      border-radius: 999px;
      background: rgba(255,255,255,0.14);
      color: white;
      font-size: 24px;
      cursor: pointer;
    }

    .trail-canvas {
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 34;
    }

    .trail-core {
      position: fixed;
      left: 0;
      top: 0;
      width: 18px;
      height: 18px;
      margin-left: -9px;
      margin-top: -9px;
      border-radius: 999px;
      background: radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(255,236,210,0.95) 38%, rgba(251,146,60,0.9) 60%, rgba(251,146,60,0) 100%);
      box-shadow: 0 0 14px rgba(251,146,60,0.36), 0 0 30px rgba(251,146,60,0.16);
      pointer-events: none;
      z-index: 35;
      mix-blend-mode: screen;
      opacity: 0;
      transition: opacity 160ms ease;
    }

    body.has-trail-pointer .trail-core {
      opacity: 1;
    }

    .quote-note {
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-top: 10px;
      padding-left: 12px;
      border-left: 2px solid rgba(107, 114, 128, 0.18);
      color: rgba(107, 114, 128, 0.88);
      font-size: 0.72em;
      line-height: 1.55;
      font-weight: 400;
      letter-spacing: 0.01em;
      opacity: 0.92;
    }

    .quote-note > div,
    .quote-note > p {
      color: inherit !important;
      font-size: inherit !important;
      line-height: inherit !important;
      font-weight: inherit !important;
      margin: 0;
    }

    .quote-note span[style*="color: #FF0000"] {
      color: rgba(107, 114, 128, 0.88) !important;
    }

    .slides {
      cursor: none;
    }
  </style>
</head>
<body>
  <div class="app">
    <div class="viewport">
      <div class="slides">
        ${coverMarkup}
        ${slidesMarkup}
      </div>
    </div>
  </div>
  <canvas class="trail-canvas" id="trailCanvas"></canvas>
  <div class="trail-core" id="trailCore"></div>
  <div class="progress"><div class="progress__bar" id="progressBar"></div></div>
  <button type="button" class="nav-fab" id="navToggleBtn" aria-label="导航展开" aria-expanded="false">
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M5 7h14M5 12h14M5 17h9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    </svg>
  </button>
  <div class="nav-backdrop" id="navBackdrop" hidden></div>
  <aside class="nav-drawer" id="navDrawer" aria-hidden="true">
    <div class="nav-drawer__header">
      <div class="nav-drawer__title">导航目录</div>
      <button type="button" class="nav-drawer__close" id="navCloseBtn" aria-label="关闭目录">×</button>
    </div>
    <div class="nav-drawer__list" id="navList">
      ${navMarkup}
    </div>
  </aside>
  <button type="button" class="fullscreen-fab" id="fullscreenBtn" aria-label="全屏">
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M8 4H4v4M16 4h4v4M20 16v4h-4M4 16v4h4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  </button>
  <div class="lightbox" id="lightbox" aria-hidden="true">
    <div class="lightbox__backdrop" id="lightboxBackdrop"></div>
    <button type="button" class="lightbox__close" id="lightboxClose" aria-label="Close">×</button>
    <div class="lightbox__viewer">
      <img class="lightbox__img" id="lightboxImage" alt="" />
    </div>
    <div class="lightbox__counter" id="lightboxCounter" hidden></div>
  </div>
  <script>
    const slides = Array.from(document.querySelectorAll('.slide'));
    const progressBar = document.getElementById('progressBar');
    const fullscreenBtn = document.getElementById('fullscreenBtn');
    const navToggleBtn = document.getElementById('navToggleBtn');
    const navDrawer = document.getElementById('navDrawer');
    const navList = document.getElementById('navList');
    const navCloseBtn = document.getElementById('navCloseBtn');
    const navBackdrop = document.getElementById('navBackdrop');
    const lightbox = document.getElementById('lightbox');
    const lightboxBackdrop = document.getElementById('lightboxBackdrop');
    const lightboxImage = document.getElementById('lightboxImage');
    const lightboxClose = document.getElementById('lightboxClose');
    const lightboxCounter = document.getElementById('lightboxCounter');
    const lightboxViewer = lightbox.querySelector('.lightbox__viewer');
    const trailCanvas = document.getElementById('trailCanvas');
    const trailCore = document.getElementById('trailCore');
    const trailCtx = trailCanvas.getContext('2d');
    const navItems = Array.from(document.querySelectorAll('.nav-item'));
    let current = 0;
    let direction = 1;
    let navOpen = false;
    let lightboxGallery = [];
    let lightboxIndex = 0;
    let lightboxSwitching = false;
    let lightboxCloseTimer = null;
    const LONG_IMAGE_RATIO = 1.8;
    const LONG_IMAGE_SCROLL_STEP = 0.82;
    const lightboxState = {
      scale: 1,
      minScale: 1,
      maxScale: 4,
      x: 0,
      y: 0,
      startX: 0,
      startY: 0,
      startScale: 1,
      lastTouchDistance: 0,
      mode: null,
      activePointerId: null,
      swipeStartX: 0,
      swipeStartY: 0,
      swipeActive: false,
      wheelNavLockUntil: 0,
      isReadingLong: false
    };

    function update() {
      slides.forEach((slide, index) => {
        slide.classList.remove('is-active', 'is-before', 'is-after', 'is-hidden');
        if (index < current) {
          slide.classList.add('is-before');
        } else if (index > current) {
          slide.classList.add('is-after');
        }
        if (index === current) {
          slide.classList.add('is-active');
        }
      });
      progressBar.style.width = ((current + 1) / slides.length) * 100 + '%';
      let activeNavTarget = 0;
      for (const item of navItems) {
        const target = Number(item.dataset.targetSlide || 0);
        if (target <= current) {
          activeNavTarget = target;
        } else {
          break;
        }
      }
      navItems.forEach((item) => {
        const target = Number(item.dataset.targetSlide || 0);
        item.classList.toggle('is-active', target === activeNavTarget);
      });
    }

    function setNavOpen(nextOpen) {
      navOpen = nextOpen;
      navDrawer.classList.toggle('is-open', navOpen);
      navBackdrop.classList.toggle('is-open', navOpen);
      navDrawer.setAttribute('aria-hidden', String(!navOpen));
      navToggleBtn.setAttribute('aria-expanded', String(navOpen));
      navBackdrop.hidden = !navOpen;
    }

    function goTo(index) {
      const nextIndex = Math.max(0, Math.min(slides.length - 1, index));
      if (nextIndex === current) return;
      direction = nextIndex > current ? 1 : -1;
      current = nextIndex;
      update();
    }

    function next() {
      goTo(current + 1);
    }

    function prev() {
      goTo(current - 1);
    }

    async function toggleFullscreen() {
      if (document.fullscreenElement) {
        await document.exitFullscreen?.();
        return;
      }
      await document.documentElement.requestFullscreen?.();
    }

    document.addEventListener('keydown', async (event) => {
      const key = event.key;
      const lowerKey = key.toLowerCase();

      if (lowerKey === 'f') {
        event.preventDefault();
        await toggleFullscreen();
        return;
      }

      if (lightbox.classList.contains('is-open')) {
        if (key === 'Escape' || lowerKey === 'e') {
          event.preventDefault();
          closeLightbox();
          return;
        }
        if (key === 'ArrowRight' || key === 'ArrowDown' || key === 'PageDown' || key === ' ') {
          event.preventDefault();
          if (lightboxState.isReadingLong) {
            scrollLongImage(1);
          } else {
            showNextLightboxImage();
          }
          return;
        }
        if (key === 'ArrowLeft' || key === 'ArrowUp' || key === 'PageUp') {
          event.preventDefault();
          if (lightboxState.isReadingLong) {
            scrollLongImage(-1);
          } else {
            showPreviousLightboxImage();
          }
          return;
        }
      }
      if (navOpen && key === 'Escape') {
        setNavOpen(false);
        return;
      }
      if (lowerKey === 'e') {
        const opened = openCurrentSlideGallery();
        if (opened) {
          event.preventDefault();
        }
        return;
      }
      if (key === 'ArrowRight' || key === 'ArrowDown' || key === ' ' || key === 'PageDown') {
        event.preventDefault();
        next();
        return;
      }
      if (key === 'ArrowLeft' || key === 'ArrowUp' || key === 'PageUp') {
        event.preventDefault();
        prev();
        return;
      }
    });

    navToggleBtn.addEventListener('click', () => {
      setNavOpen(!navOpen);
    });

    navCloseBtn.addEventListener('click', () => {
      setNavOpen(false);
    });

    navBackdrop.addEventListener('click', () => {
      setNavOpen(false);
    });

    navItems.forEach((item) => {
      item.addEventListener('click', () => {
        const target = Number(item.dataset.targetSlide || 0);
        goTo(target);
        setNavOpen(false);
      });
    });

    fullscreenBtn.addEventListener('click', toggleFullscreen);

    document.addEventListener('fullscreenchange', () => {
      document.documentElement.classList.toggle('is-fullscreen', Boolean(document.fullscreenElement));
    });

    function clamp(value, min, max) {
      return Math.min(max, Math.max(min, value));
    }

    function resetLightboxTransform() {
      lightboxState.scale = 1;
      lightboxState.x = 0;
      lightboxState.y = 0;
      lightboxState.startX = 0;
      lightboxState.startY = 0;
      lightboxState.startScale = 1;
      lightboxState.lastTouchDistance = 0;
      lightboxState.mode = null;
      lightboxState.activePointerId = null;
      lightboxState.swipeStartX = 0;
      lightboxState.swipeStartY = 0;
      lightboxState.swipeActive = false;
      applyLightboxTransform();
    }

    function applyLightboxTransform() {
      lightboxImage.style.setProperty('--pan-x', lightboxState.x + 'px');
      lightboxImage.style.setProperty('--pan-y', lightboxState.y + 'px');
      lightboxImage.style.setProperty('--zoom', String(lightboxState.scale));
    }

    function setLightboxSwitchMotion(x = '0%', opacity = 1) {
      lightboxImage.style.setProperty('--switch-x', x);
      lightboxImage.style.setProperty('--image-opacity', String(opacity));
    }

    function updateLightboxCounter() {
      if (!lightboxGallery.length) {
        lightboxCounter.hidden = true;
        lightboxCounter.textContent = '';
        return;
      }
      lightboxCounter.hidden = false;
      lightboxCounter.textContent = (lightboxIndex + 1) + ' / ' + lightboxGallery.length;
    }

    function setLongImageReading(nextReading, resetScroll = true) {
      lightboxState.isReadingLong = Boolean(nextReading);
      lightbox.classList.toggle('is-reading-long', lightboxState.isReadingLong);
      if (resetScroll && lightboxViewer) {
        lightboxViewer.scrollTop = 0;
      }
      if (lightboxState.isReadingLong) {
        lightboxState.scale = 1;
        lightboxState.x = 0;
        lightboxState.y = 0;
        applyLightboxTransform();
      }
    }

    function updateLongImageReading(resetScroll = true) {
      if (!lightboxImage.naturalWidth || !lightboxImage.naturalHeight) {
        setLongImageReading(false, resetScroll);
        return;
      }
      const ratio = lightboxImage.naturalHeight / Math.max(1, lightboxImage.naturalWidth);
      setLongImageReading(ratio > LONG_IMAGE_RATIO, resetScroll);
    }

    function prepareLightboxImageForReading() {
      setLongImageReading(false, true);
      if (lightboxImage.complete && lightboxImage.naturalWidth) {
        window.setTimeout(() => updateLongImageReading(true), 0);
      }
    }

    function scrollLongImage(dir) {
      if (!lightboxViewer) return;
      const maxScroll = Math.max(0, lightboxViewer.scrollHeight - lightboxViewer.clientHeight);
      const nearTop = lightboxViewer.scrollTop <= 8;
      const nearBottom = lightboxViewer.scrollTop >= maxScroll - 8;
      if (dir > 0 && nearBottom) {
        showNextLightboxImage();
        return;
      }
      if (dir < 0 && nearTop) {
        showPreviousLightboxImage();
        return;
      }
      lightboxViewer.scrollBy({
        top: dir * lightboxViewer.clientHeight * LONG_IMAGE_SCROLL_STEP,
        behavior: 'smooth'
      });
    }

    function showLightboxAt(index) {
      if (!lightboxGallery.length) return;
      lightboxIndex = clamp(index, 0, lightboxGallery.length - 1);
      const item = lightboxGallery[lightboxIndex];
      lightboxImage.src = item.src;
      lightboxImage.alt = item.alt || '';
      prepareLightboxImageForReading();
      setLightboxSwitchMotion('0%', 1);
      resetLightboxTransform();
      updateLightboxCounter();
    }

    function animateLightboxTo(index, dir) {
      if (!lightboxGallery.length || lightboxSwitching) return;
      const nextIndex = clamp(index, 0, lightboxGallery.length - 1);
      if (nextIndex === lightboxIndex) return;
      lightboxSwitching = true;
      const exitX = dir > 0 ? '-18%' : '18%';
      const enterX = dir > 0 ? '18%' : '-18%';
      setLightboxSwitchMotion(exitX, 0);
      window.setTimeout(() => {
        lightboxIndex = nextIndex;
        const item = lightboxGallery[lightboxIndex];
        lightboxImage.src = item.src;
        lightboxImage.alt = item.alt || '';
        prepareLightboxImageForReading();
        resetLightboxTransform();
        updateLightboxCounter();
        setLightboxSwitchMotion(enterX, 0);
        window.requestAnimationFrame(() => {
          window.requestAnimationFrame(() => {
            setLightboxSwitchMotion('0%', 1);
          });
        });
        window.setTimeout(() => {
          lightboxSwitching = false;
        }, 300);
      }, 170);
    }

    function showNextLightboxImage() {
      if (!lightboxGallery.length) return;
      if (lightboxIndex >= lightboxGallery.length - 1) {
        closeLightbox();
        return;
      }
      animateLightboxTo(lightboxIndex + 1, 1);
    }

    function showPreviousLightboxImage() {
      if (!lightboxGallery.length) return;
      if (lightboxIndex <= 0) {
        closeLightbox();
        return;
      }
      animateLightboxTo(lightboxIndex - 1, -1);
    }

    function getSlideGallery(slide) {
      const images = Array.from(slide?.querySelectorAll('.slide__body img') || []);
      return images
        .filter((image) => image.currentSrc || image.src)
        .map((image) => ({ src: image.currentSrc || image.src, alt: image.alt || '' }));
    }

    function openLightbox(gallery, startIndex = 0) {
      if (!gallery.length) return false;
      window.clearTimeout(lightboxCloseTimer);
      lightbox.classList.remove('is-closing');
      lightboxGallery = gallery.slice();
      showLightboxAt(startIndex);
      setLightboxSwitchMotion('-18%', 0);
      lightbox.setAttribute('aria-hidden', 'false');
      window.requestAnimationFrame(() => {
        lightbox.classList.add('is-open');
        window.requestAnimationFrame(() => {
          setLightboxSwitchMotion('0%', 1);
        });
      });
      return true;
    }

    function openCurrentSlideGallery() {
      return openLightbox(getSlideGallery(slides[current]), 0);
    }

    function closeLightbox() {
      if (!lightbox.classList.contains('is-open')) return;
      lightbox.classList.add('is-closing');
      lightbox.classList.remove('is-open');
      lightbox.setAttribute('aria-hidden', 'true');
      lightboxCloseTimer = window.setTimeout(() => {
        lightbox.classList.remove('is-closing');
        lightboxImage.src = '';
        lightboxGallery = [];
        lightboxSwitching = false;
        lightboxCounter.hidden = true;
        setLightboxSwitchMotion('0%', 1);
        setLongImageReading(false, true);
        resetLightboxTransform();
      }, 280);
    }

    lightboxImage.addEventListener('load', () => {
      if (lightbox.classList.contains('is-open')) {
        updateLongImageReading(true);
      }
    });

    lightboxClose.addEventListener('click', closeLightbox);
    lightboxBackdrop?.addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', (event) => {
      if (event.target === lightboxImage || event.target === lightboxClose) {
        return;
      }
      closeLightbox();
    });

    function getTouchDistance(touches) {
      if (touches.length < 2) return 0;
      const dx = touches[0].clientX - touches[1].clientX;
      const dy = touches[0].clientY - touches[1].clientY;
      return Math.hypot(dx, dy);
    }

    lightbox.addEventListener('wheel', (event) => {
      if (!lightbox.classList.contains('is-open')) return;
      event.preventDefault();
      const isPinchZoom = event.ctrlKey;

      if (lightboxState.isReadingLong && !isPinchZoom) {
        lightboxViewer?.scrollBy({ top: event.deltaY, left: 0, behavior: 'auto' });
        return;
      }

      if (isPinchZoom) {
        const nextScale = clamp(lightboxState.scale + (event.deltaY < 0 ? 0.18 : -0.18), lightboxState.minScale, lightboxState.maxScale);
        lightboxState.scale = nextScale;
        if (lightboxState.scale <= 1) {
          lightboxState.x = 0;
          lightboxState.y = 0;
        }
        applyLightboxTransform();
        return;
      }

      if (lightboxState.scale > 1.01) {
        lightboxState.x -= event.deltaX;
        lightboxState.y -= event.deltaY;
        applyLightboxTransform();
        return;
      }

      const now = performance.now();
      const isMostlyHorizontal = Math.abs(event.deltaX) > Math.abs(event.deltaY) && Math.abs(event.deltaX) > 24;
      if (isMostlyHorizontal && now >= lightboxState.wheelNavLockUntil) {
        if (event.deltaX > 0) {
          showNextLightboxImage();
        } else {
          showPreviousLightboxImage();
        }
        lightboxState.wheelNavLockUntil = now + 220;
      }
    }, { passive: false });

    lightbox.addEventListener('pointerdown', (event) => {
      if (!lightbox.classList.contains('is-open')) return;
      if (event.target === lightboxClose) return;
      if (lightboxState.isReadingLong) return;
      if (lightboxState.scale > 1 && event.target === lightboxImage) {
        lightboxState.mode = 'pan';
        lightboxState.activePointerId = event.pointerId;
        lightboxState.startX = event.clientX - lightboxState.x;
        lightboxState.startY = event.clientY - lightboxState.y;
        lightboxImage.setPointerCapture?.(event.pointerId);
      } else {
        lightboxState.mode = 'swipe';
        lightboxState.swipeActive = true;
        lightboxState.swipeStartX = event.clientX;
        lightboxState.swipeStartY = event.clientY;
      }
    });

    lightbox.addEventListener('pointermove', (event) => {
      if (!lightbox.classList.contains('is-open')) return;
      if (lightboxState.mode === 'pan' && lightboxState.activePointerId === event.pointerId) {
        event.preventDefault();
        lightboxState.x = event.clientX - lightboxState.startX;
        lightboxState.y = event.clientY - lightboxState.startY;
        applyLightboxTransform();
      }
    });

    lightbox.addEventListener('pointerup', (event) => {
      if (!lightbox.classList.contains('is-open')) return;
      if (lightboxState.mode === 'pan' && lightboxState.activePointerId === event.pointerId) {
        lightboxImage.releasePointerCapture?.(event.pointerId);
        lightboxState.mode = null;
        lightboxState.activePointerId = null;
        return;
      }
      if (lightboxState.mode === 'swipe' && lightboxState.swipeActive) {
        const dx = event.clientX - lightboxState.swipeStartX;
        const dy = event.clientY - lightboxState.swipeStartY;
        if (Math.abs(dx) > 36 && Math.abs(dx) > Math.abs(dy)) {
          showLightboxAt(lightboxIndex + (dx < 0 ? 1 : -1));
        }
        lightboxState.mode = null;
        lightboxState.swipeActive = false;
      }
    });

    lightbox.addEventListener('pointercancel', () => {
      lightboxState.mode = null;
      lightboxState.activePointerId = null;
      lightboxState.swipeActive = false;
    });

    lightbox.addEventListener('touchstart', (event) => {
      if (!lightbox.classList.contains('is-open')) return;
      if (event.touches.length === 2) {
        lightboxState.mode = 'pinch';
        lightboxState.lastTouchDistance = getTouchDistance(event.touches);
        lightboxState.startScale = lightboxState.scale;
      }
    }, { passive: false });

    lightbox.addEventListener('touchmove', (event) => {
      if (!lightbox.classList.contains('is-open')) return;
      if (event.touches.length === 2) {
        event.preventDefault();
        const nextDistance = getTouchDistance(event.touches);
        if (!lightboxState.lastTouchDistance) {
          lightboxState.lastTouchDistance = nextDistance;
        }
        const ratio = nextDistance / lightboxState.lastTouchDistance;
        lightboxState.scale = clamp(lightboxState.startScale * ratio, lightboxState.minScale, lightboxState.maxScale);
        if (lightboxState.scale <= 1) {
          lightboxState.x = 0;
          lightboxState.y = 0;
        }
        applyLightboxTransform();
      }
    }, { passive: false });

    lightbox.addEventListener('touchend', () => {
      lightboxState.lastTouchDistance = 0;
      lightboxState.startScale = lightboxState.scale;
      if (lightboxState.mode === 'pinch') {
        lightboxState.mode = null;
      }
    });

    function buildThumbnails() {
      for (const slide of slides) {
        const body = slide.querySelector('.slide__body');
        const thumbs = slide.querySelector('.slide__thumbs');
        if (!body || !thumbs) continue;

        const images = Array.from(body.querySelectorAll('img'));
        if (!images.length) {
          thumbs.hidden = true;
          continue;
        }

        thumbs.innerHTML = '';
        const gallery = [];
        const seenSources = new Set();
        for (const image of images) {
          const src = image.currentSrc || image.src;
          if (!src || seenSources.has(src)) continue;
          seenSources.add(src);
          gallery.push({ src, alt: image.alt || '' });
        }
        gallery.forEach((image, imageIndex) => {
          const button = document.createElement('button');
          button.type = 'button';
          button.className = 'thumb';
          button.innerHTML = '<img src="' + image.src + '" alt="' + image.alt + '">';
          button.addEventListener('click', () => openLightbox(gallery, imageIndex));
          thumbs.appendChild(button);
        });
        thumbs.hidden = gallery.length === 0;
      }
    }

    function classifyImageAspects() {
      for (const slide of slides) {
        slide.classList.remove('is-wide-image', 'is-portrait-image');
        if (!slide.classList.contains('is-single-image')) continue;

        const image = slide.querySelector('.slide__body img');
        if (!image) continue;

        const width = image.naturalWidth || image.width || 0;
        const height = image.naturalHeight || image.height || 0;
        if (!width || !height) continue;

        const ratio = width / height;
        const isWideLandscape = ratio >= 2.2 && ratio <= 2.9;
        const isPortrait = ratio < 0.72;

        if (isWideLandscape) {
          slide.classList.add('is-wide-image');
        }
        if (isPortrait) {
          slide.classList.add('is-portrait-image');
        }
      }
    }

    function classifySlides() {
      for (const slide of slides) {
        const inner = slide.querySelector('.slide__inner');
        const stack = slide.querySelector('.slide__stack');
        const body = slide.querySelector('.slide__body');
        const thumbs = slide.querySelector('.slide__thumbs');
        if (!inner || !stack || !body) continue;

        slide.classList.remove('is-fit', 'is-overflow', 'is-compact-list', 'is-single-image', 'has-image-gallery');
        const contentHeight = stack.scrollHeight;
        const availableHeight = inner.clientHeight;
        const textLength = (body.textContent || '').replace(/\\s+/g, ' ').trim().length;
        const images = Array.from(body.querySelectorAll('img'));
        const imageCount = images.length;
        const listCount = body.querySelectorAll('ol, ul').length;
        const tableCount = body.querySelectorAll('table').length;
        const listItemCount = body.querySelectorAll('li').length;
        const lineCount = body.innerText.split('\\n').map((line) => line.trim()).filter(Boolean).length;
        const hasTitleLead = /[:：]$/.test((body.querySelector('div, p')?.innerText || '').trim());
        const mediaOnlyText = (body.textContent || '').replace(/\\s+/g, ' ').trim();
        const singleImage =
          slide.classList.contains('slide--visual') &&
          imageCount === 1 &&
          listCount === 0 &&
          tableCount === 0 &&
          mediaOnlyText.length <= 64;

        const fits = contentHeight <= availableHeight * 0.88;
        const concise = textLength <= 420 && lineCount <= 8;
        const imageHeavy = imageCount > 0 && listCount <= 1 && tableCount === 0 && textLength <= 560;
        const compactList = slide.classList.contains('slide--list') && listItemCount >= 3 && listItemCount <= 10 && lineCount <= 12 && hasTitleLead;

        if ((fits && concise) || imageHeavy) {
          slide.classList.add('is-fit');
        }
        if (contentHeight > availableHeight * 0.98) {
          slide.classList.add('is-overflow');
        }
        if (compactList) {
          slide.classList.add('is-compact-list');
        }
        if (singleImage) {
          slide.classList.add('is-single-image', 'is-fit');
          if (thumbs) thumbs.hidden = true;
        } else if (imageCount > 0) {
          slide.classList.add('has-image-gallery');
        }
      }
      classifyImageAspects();
    }

    const trailPreset = {
      colorA: '255,205,86',
      colorB: '251,146,60',
      core: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.98), rgba(255,236,210,0.95) 38%, rgba(251,146,60,0.9) 60%, rgba(251,146,60,0) 100%)',
      width: 20,
      fade: 980,
      blur: 16,
      glow: 0.26
    };

    const trailState = {
      pointer: { x: window.innerWidth * 0.5, y: window.innerHeight * 0.5, tx: window.innerWidth * 0.5, ty: window.innerHeight * 0.5 },
      strokes: [],
      lastInput: null
    };

    function resizeTrailCanvas() {
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      trailCanvas.width = Math.floor(window.innerWidth * ratio);
      trailCanvas.height = Math.floor(window.innerHeight * ratio);
      trailCanvas.style.width = window.innerWidth + 'px';
      trailCanvas.style.height = window.innerHeight + 'px';
      trailCtx.setTransform(ratio, 0, 0, ratio, 0, 0);
    }

    function lerp(a, b, t) {
      return a + (b - a) * t;
    }

    function distance(a, b) {
      return Math.hypot(a.x - b.x, a.y - b.y);
    }

    function addTrailPoint(x, y) {
      const now = performance.now();
      const stroke = trailState.strokes;
      const last = stroke[stroke.length - 1];
      if (last && distance(last, { x, y }) < 1.2) return;
      stroke.push({ x, y, t: now });
      if (stroke.length > 320) {
        stroke.splice(0, stroke.length - 320);
      }
      trailCore.style.left = x + 'px';
      trailCore.style.top = y + 'px';
      trailCore.style.background = trailPreset.core;
    }

    function addInterpolatedTrailPoints(fromX, fromY, toX, toY) {
      const dx = toX - fromX;
      const dy = toY - fromY;
      const dist = Math.hypot(dx, dy);
      const steps = Math.max(1, Math.ceil(dist / 1.6));
      for (let i = 1; i <= steps; i += 1) {
        const t = i / steps;
        addTrailPoint(lerp(fromX, toX, t), lerp(fromY, toY, t));
      }
    }

    function drawTrail(now) {
      const alive = trailState.strokes.filter((point) => now - point.t <= trailPreset.fade);
      trailState.strokes = alive;
      if (alive.length < 2) return;

      trailCtx.save();
      trailCtx.lineCap = 'round';
      trailCtx.lineJoin = 'round';

      const first = alive[0];
      const last = alive[alive.length - 1];
      const headAge = now - last.t;
      const headAlpha = Math.max(0, 1 - headAge / trailPreset.fade);
      const baseThickness = Math.max(3, trailPreset.width * (0.38 + headAlpha * 0.62));

      const drawPath = (lineWidth, alphaScale, blurScale) => {
        trailCtx.shadowBlur = trailPreset.blur * blurScale;
        trailCtx.shadowColor = 'rgba(' + trailPreset.colorB + ',' + (trailPreset.glow * blurScale + 0.04) + ')';
        trailCtx.lineWidth = lineWidth;
        trailCtx.beginPath();
        trailCtx.moveTo(alive[0].x, alive[0].y);
        for (let i = 1; i < alive.length - 1; i += 1) {
          const curr = alive[i];
          const next = alive[i + 1];
          const midX = (curr.x + next.x) / 2;
          const midY = (curr.y + next.y) / 2;
          trailCtx.quadraticCurveTo(curr.x, curr.y, midX, midY);
        }
        trailCtx.lineTo(last.x, last.y);

        const gradient = trailCtx.createLinearGradient(first.x, first.y, last.x, last.y);
        gradient.addColorStop(0, 'rgba(' + trailPreset.colorA + ',' + (0.045 * alphaScale) + ')');
        gradient.addColorStop(0.16, 'rgba(' + trailPreset.colorA + ',' + (0.12 * alphaScale) + ')');
        gradient.addColorStop(0.5, 'rgba(' + trailPreset.colorA + ',' + (0.28 * alphaScale) + ')');
        gradient.addColorStop(0.82, 'rgba(' + trailPreset.colorB + ',' + (0.5 * alphaScale) + ')');
        gradient.addColorStop(1, 'rgba(' + trailPreset.colorB + ',' + ((0.88 * headAlpha + 0.06) * alphaScale) + ')');
        trailCtx.strokeStyle = gradient;
        trailCtx.stroke();
      };

      drawPath(baseThickness * 1.95, 0.24, 1.35);
      drawPath(baseThickness * 1.4, 0.34, 1.05);
      drawPath(baseThickness, 1, 1);

      trailCtx.restore();
    }

    function renderTrail(now) {
      trailCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      trailState.pointer.x = lerp(trailState.pointer.x, trailState.pointer.tx, 0.42);
      trailState.pointer.y = lerp(trailState.pointer.y, trailState.pointer.ty, 0.42);
      trailCore.style.left = trailState.pointer.x + 'px';
      trailCore.style.top = trailState.pointer.y + 'px';
      drawTrail(now);
      requestAnimationFrame(renderTrail);
    }

    window.addEventListener('load', () => {
      buildThumbnails();
      classifySlides();
      update();
      if (window.matchMedia('(pointer: fine)').matches) {
        document.body.classList.add('has-trail-pointer');
        resizeTrailCanvas();
        trailCore.style.background = trailPreset.core;
        requestAnimationFrame(renderTrail);
      }
    });
    window.addEventListener('resize', () => {
      classifySlides();
      if (document.body.classList.contains('has-trail-pointer')) {
        resizeTrailCanvas();
      }
    });

    document.addEventListener('pointermove', (event) => {
      if (!document.body.classList.contains('has-trail-pointer')) return;
      const samples = typeof event.getCoalescedEvents === 'function' ? event.getCoalescedEvents() : [event];
      for (const sample of samples) {
        if (trailState.lastInput) {
          addInterpolatedTrailPoints(trailState.lastInput.x, trailState.lastInput.y, sample.clientX, sample.clientY);
        } else {
          addTrailPoint(sample.clientX, sample.clientY);
        }
        trailState.lastInput = { x: sample.clientX, y: sample.clientY };
        trailState.pointer.tx = sample.clientX;
        trailState.pointer.ty = sample.clientY;
      }
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        trailState.strokes = [];
        trailState.lastInput = null;
      }
    });
    update();
  </script>
</body>
</html>`;

fs.writeFileSync(outputPath, outputHtml, 'utf8');
const diagnosticsPath = outputPath.replace(/\.html?$/i, '.diagnostics.json');
const checklistPath = outputPath.replace(/\.html?$/i, '.self-check.md');
const logicMapPath = outputPath.replace(/\.html?$/i, '.logic-map.md');
const logicCheckPath = outputPath.replace(/\.html?$/i, '.logic-check.md');
const logicCheckJsonPath = outputPath.replace(/\.html?$/i, '.logic-check.json');
const logicMap = buildLogicMap(presentationTitle, slides);
const logicCheck = buildLogicCheck(presentationTitle, slides);
fs.writeFileSync(diagnosticsPath, JSON.stringify(diagnostics, null, 2), 'utf8');
fs.writeFileSync(checklistPath, buildChecklist(presentationTitle, diagnostics), 'utf8');
fs.writeFileSync(logicMapPath, logicMap, 'utf8');
fs.writeFileSync(logicCheckPath, logicCheck.markdown, 'utf8');
fs.writeFileSync(logicCheckJsonPath, JSON.stringify(logicCheck.json, null, 2), 'utf8');
console.log(`Built ${slides.length + 1} slides: ${outputPath}`);
runDeckQa(outputPath);

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function runDeckQa(deckPath) {
  if (process.env.SKIP_DECK_QA === '1') {
    console.log('Deck QA skipped by SKIP_DECK_QA=1');
    return;
  }
  const qaScript = path.join(__dirname, 'qa-deck.js');
  const args = [qaScript, deckPath];
  if (process.env.DECK_QA_NO_BROWSER === '1') {
    args.push('--no-browser');
  }
  cp.execFileSync(process.execPath, args, {
    cwd: outputDir,
    stdio: 'inherit',
    maxBuffer: 32 * 1024 * 1024,
  });
}

function buildChecklist(title, diagnosticsRows) {
  const riskySlides = diagnosticsRows.filter((row) => row.issues.length > 0);
  const summary = [
    `# ${title} 排版自查清单`,
    '',
    `- 总页数：${diagnosticsRows.length}`,
    `- 需重点复查页数：${riskySlides.length}`,
    `- 高风险页：${riskySlides.slice(0, 12).map((row) => row.slide).join(', ') || '无'}`,
    `- 页型分布：${summarizeRoles(diagnosticsRows)}`,
    '',
    '## 通用检查',
    '',
    '- 左边线是否稳定：正文、列表、引用、表格是否从统一起点开始。',
    '- 垂直重心是否正确：短页居中，长页靠上，不能忽左忽右。',
    '- 正文字号是否一致：不能出现局部突然变大或变小。',
    '- 段间距是否均匀：不能因为空 div 或 br 造成断层留白。',
    '- 缩略图区是否规整：尺寸一致、从左排列、与正文距离固定。',
    '- 粗体和红字是否保留：强调信息不能丢失。',
    '- 图文平衡是否合理：有图页不能正文过满，也不能留白失衡。',
    '- 长文页是否可读：是否存在单行过长、整页信息过密的问题。',
    '',
    '## 风险页复查',
    '',
  ];

  if (!riskySlides.length) {
    summary.push('- 无明显风险页。');
  } else {
    for (const row of riskySlides.slice(0, 24)) {
      summary.push(`- 第 ${row.slide} 页（${row.role}）：${row.issues.join(', ')}；预览：${row.preview}`);
    }
  }

  summary.push('');
  summary.push('## 适合继续增强的点');
  summary.push('');
  summary.push('- 章节页做专门模板，让标题页更克制。');
  summary.push('- 图文混排页继续拆分，减少“图片和长文同时拥挤”。');
  summary.push('- 对超长段落做自动断行优化。');
  summary.push('- 对表格页做专门样式，避免信息密度失控。');
  summary.push('');

  return summary.join('\n');
}

function summarizeRoles(rows) {
  const counts = rows.reduce((acc, row) => {
    acc[row.role] = (acc[row.role] || 0) + 1;
    return acc;
  }, {});
  return Object.entries(counts).map(([role, count]) => `${role} ${count}`).join('，');
}

function chineseNumeralToInt(value) {
  if (!value) return null;
  if (/^\d+$/.test(value)) return Number(value);
  const map = {
    零: 0,
    一: 1,
    二: 2,
    三: 3,
    四: 4,
    五: 5,
    六: 6,
    七: 7,
    八: 8,
    九: 9,
    十: 10,
  };
  if (value === '十') return 10;
  if (value.length === 2 && value.startsWith('十')) {
    return 10 + (map[value[1]] || 0);
  }
  if (value.length === 2 && value.endsWith('十')) {
    return (map[value[0]] || 0) * 10;
  }
  if (value.length === 3 && value[1] === '十') {
    return (map[value[0]] || 0) * 10 + (map[value[2]] || 0);
  }
  return map[value] ?? null;
}

function collectLogicSignals(slides) {
  const parts = [];
  const levels = [];
  const challenges = [];
  const layers = [];
  const anchors = [];

  const anchorPatterns = [
    /今天我想分享四个话题/,
    /亮点预告/,
    /注意：?/,
    /提问：?/,
    /问题本质/,
    /统一的模型/,
    /通用范式/,
    /每周双三角指数/,
    /希望大家建立三种自信/,
    /一个非常大胆的愿景假设/,
  ];

  slides.forEach((slide) => {
    const text = extractPlainText(slide.html);
    if (!text) return;

    const partMatch = text.match(/Part\s*([IVX0-9]+)\.\s*([^。]+)/i);
    if (partMatch) {
      parts.push({
        slide: slide.index,
        order: romanToInt(partMatch[1]),
        label: `Part ${partMatch[1]}`,
        title: partMatch[2].trim(),
        text,
      });
    }

    const levelMatch = text.match(/Level\s*([1-9])\.?\s*([^。]+)/i);
    if (levelMatch) {
      levels.push({
        slide: slide.index,
        order: Number(levelMatch[1]),
        label: `Level${levelMatch[1]}`,
        title: levelMatch[2].trim(),
        text,
      });
    }

    const challengeMatch = text.match(/第([一二三四五六七八九十0-9]+)次[，：:]?\s*([^。]+)/);
    if (challengeMatch) {
      challenges.push({
        slide: slide.index,
        order: chineseNumeralToInt(challengeMatch[1]),
        label: `第${challengeMatch[1]}次`,
        title: challengeMatch[2].trim(),
        text,
      });
    }

    const layerMatches = Array.from(text.matchAll(/第([0-9]+)层[：:]\s*([\s\S]*?)(?=第[0-9]+层[：:]|$)/g));
    for (const match of layerMatches) {
      layers.push({
        slide: slide.index,
        order: Number(match[1]),
        label: `第${match[1]}层`,
        title: match[2].replace(/\s+/g, ' ').trim(),
        text,
      });
    }

    if (slide.role === 'chapter' || anchorPatterns.some((pattern) => pattern.test(text))) {
      anchors.push({
        slide: slide.index,
        role: slide.role,
        text: text.slice(0, 64),
      });
    }
  });

  return { parts, levels, challenges, layers, anchors };
}

function romanToInt(value) {
  if (!value) return null;
  if (/^\d+$/.test(value)) return Number(value);
  const map = { I: 1, V: 5, X: 10 };
  let total = 0;
  let prev = 0;
  for (const ch of value.toUpperCase().split('').reverse()) {
    const curr = map[ch] || 0;
    if (curr < prev) total -= curr;
    else total += curr;
    prev = curr;
  }
  return total || null;
}

function evaluateOrderedGroup(groupName, items) {
  const warnings = [];
  if (!items.length) {
    warnings.push(`${groupName}：未识别到该类结构。`);
    return { ok: false, warnings };
  }

  const invalid = items.filter((item) => item.order == null);
  if (invalid.length) {
    warnings.push(`${groupName}：存在无法识别顺序的节点：${invalid.map((item) => `${item.label}@${item.slide}`).join('，')}`);
  }

  for (let i = 1; i < items.length; i += 1) {
    if (items[i].order < items[i - 1].order) {
      warnings.push(`${groupName}：第 ${items[i - 1].slide} 页 ${items[i - 1].label} 后面出现更小序号 ${items[i].label}（第 ${items[i].slide} 页）。`);
    }
  }

  return { ok: warnings.length === 0, warnings };
}

function detectRepeatedLevelFamilies(levels) {
  const grouped = new Map();
  for (const level of levels) {
    const family = level.label;
    if (!grouped.has(family)) grouped.set(family, []);
    grouped.get(family).push(level);
  }
  const warnings = [];
  for (const [family, nodes] of grouped.entries()) {
    const uniqueTitles = [...new Set(nodes.map((item) => item.title))];
    if (uniqueTitles.length > 1) {
      warnings.push(`${family}：同一层级出现多种命名/子标题：${uniqueTitles.join(' / ')}`);
    }
  }
  return warnings;
}

function buildLogicMap(title, slides) {
  const signals = collectLogicSignals(slides);
  const lines = [
    `# ${title} 标准逻辑图`,
    '',
    '## 课程主线',
    '',
    '- 建立自己人场域',
    '- 统一组织认知与不变内核',
    '- 提出新模型并解释为何必须升级',
    '- 用分层段位把方法落实到人',
    '- 用组织愿景和三种自信完成收束',
    '',
    '## 分层逻辑树',
    '',
    '1. 开场定场',
    '- 新场地、新课题、新分享语境',
    '- 明确这是一场内部共识课，而非普通外部分享',
    '',
    '2. 课程导航',
    '- 四个话题总览',
    '- 亮点预告',
    '- 注意事项',
    '',
  ];

  for (const part of signals.parts) {
    lines.push(`${part.order || '?'} . ${part.label} ${part.title}`);
    const nextPartOrder = signals.parts.find((item) => item.slide > part.slide)?.slide ?? Infinity;
    const partLevels = signals.levels.filter((item) => item.slide > part.slide && item.slide < nextPartOrder);
    const partChallenges = signals.challenges.filter((item) => item.slide > part.slide && item.slide < nextPartOrder);
    const partAnchors = signals.anchors.filter((item) => item.slide >= part.slide && item.slide < nextPartOrder).slice(0, 6);

    if (partChallenges.length) {
      lines.push('- 关键挑战：');
      for (const item of partChallenges) {
        lines.push(`  - ${item.label}：${item.title}`);
      }
    }

    if (partLevels.length) {
      lines.push('- 能力层级：');
      for (const item of partLevels) {
        lines.push(`  - ${item.label}：${item.title}`);
      }
    }

    if (!partLevels.length && !partChallenges.length && partAnchors.length) {
      lines.push('- 关键节点：');
      for (const item of partAnchors) {
        lines.push(`  - ${item.text}`);
      }
    }

    lines.push('');
  }

  if (signals.layers.length) {
    lines.push('## 数值结构');
    lines.push('');
    lines.push('- 技术/能力层：');
    for (const layer of signals.layers) {
      lines.push(`  - ${layer.label}：${layer.title}`);
    }
    lines.push('');
  }

  lines.push('## 教学设计判断');
  lines.push('');
  lines.push('- 本课本质上是一堂：组织内部 AI 共识课 + 能力分层课 + 动员课。');
  lines.push('- 教学顺序是：身份统一 -> 认知升级 -> 模型提出 -> 分层动作 -> 未来愿景。');
  lines.push('');

  return lines.join('\n').replace(/^  -/gm, '  -');
}

function buildLogicCheck(title, slides) {
  const signals = collectLogicSignals(slides);
  const partCheck = evaluateOrderedGroup('Part 顺序', signals.parts);
  const levelCheck = evaluateOrderedGroup('Level 顺序', signals.levels);
  const challengeCheck = evaluateOrderedGroup('挑战顺序', signals.challenges);
  const layerCheck = evaluateOrderedGroup('层级顺序', signals.layers);
  const repeatedLevelWarnings = detectRepeatedLevelFamilies(signals.levels);

  const allWarnings = [
    ...partCheck.warnings,
    ...levelCheck.warnings,
    ...challengeCheck.warnings,
    ...layerCheck.warnings,
    ...repeatedLevelWarnings,
  ];

  const lines = [
    `# ${title} 逻辑对齐检查`,
    '',
    '## 检查范围',
    '',
    '- Part 顺序',
    '- Level 顺序',
    '- 第一次 / 第二次 / 第三次 这类序数结构',
    '- 第0层 / 第1层 / 第2层 这类数值层级结构',
    '- 同一层级是否出现多套命名',
    '',
    '## 检查结果',
    '',
    `- Part：${partCheck.ok ? '通过' : '需复查'}`,
    `- Level：${levelCheck.ok ? '通过' : '需复查'}`,
    `- 挑战序数：${challengeCheck.ok ? '通过' : '需复查'}`,
    `- 层级序数：${layerCheck.ok ? '通过' : '需复查'}`,
    `- 命名一致性：${repeatedLevelWarnings.length ? '需复查' : '通过'}`,
    '',
    '## 提示',
    '',
  ];

  if (!allWarnings.length) {
    lines.push('- 未发现明显的顺序错位，当前结构整体保持连贯。');
  } else {
    for (const warning of allWarnings) {
      lines.push(`- ${warning}`);
    }
  }

  lines.push('');
  lines.push('## 自动化规则');
  lines.push('');
  lines.push('- 同一类逻辑节点出现数字/序数时，默认按递进顺序检查。');
  lines.push('- 如果同一层级出现不同命名，会提示人工确认是否属于“主标题 / 基本功 / 子模块”的关系。');
  lines.push('- 该检查默认只提示，不自动改写原文内容。');
  lines.push('');

  return {
    markdown: lines.join('\n'),
    json: {
      title,
      summary: {
        parts: signals.parts.length,
        levels: signals.levels.length,
        challenges: signals.challenges.length,
        layers: signals.layers.length,
        warnings: allWarnings.length,
      },
      warnings: allWarnings,
      detected: signals,
    },
  };
}
