const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const outputDir = path.join(projectRoot, 'output', 'highlight-demos');
const outputPath = path.join(outputDir, '内部分享-荧光笔样式-demo.html');

fs.mkdirSync(outputDir, { recursive: true });

const sample = '这次分享，希望凝聚一堂最重要的一批同学，形成最大的全员共识。';

const styles = [
  { id: '01', name: '全高平涂', desc: '最接近传统荧光笔，整行完整覆盖。', cls: 'hl-full' },
  { id: '02', name: '半高平涂', desc: '只涂下半段，适合你现在的正文标记。', cls: 'hl-half' },
  { id: '03', name: '细下划线', desc: '克制、轻量，像编辑标注。', cls: 'hl-underline-thin' },
  { id: '04', name: '粗下划线', desc: '存在感更强，适合重点句。', cls: 'hl-underline-bold' },
  { id: '05', name: '双层下划线', desc: '像荧光笔来回补一遍。', cls: 'hl-double-underline' },
  { id: '06', name: '中段横扫', desc: '从字中部切过，偏手写批注感。', cls: 'hl-mid-swipe' },
  { id: '07', name: '椭圆打圈', desc: '像演讲时临场圈重点。', cls: 'hl-circle' },
  { id: '08', name: '手绘框圈', desc: '不规则包边，记号笔味更重。', cls: 'hl-rough-box' },
  { id: '09', name: '圆点颗粒', desc: '点状喷洒，适合实验风格。', cls: 'hl-dots-soft' },
  { id: '10', name: '粗点颗粒', desc: '更明显的颗粒感，有节奏。', cls: 'hl-dots-bold' },
  { id: '11', name: '斜向笔刷', desc: '有笔触方向，像斜着划过去。', cls: 'hl-diagonal' },
  { id: '12', name: '波浪底纹', desc: '更活泼，像连续水波纹。', cls: 'hl-wave' },
  { id: '13', name: '干刷留白', desc: '中间有轻微留白，接近真实笔触。', cls: 'hl-dry-brush' },
  { id: '14', name: '拖尾荧光', desc: '前实后虚，像快速划过。', cls: 'hl-tail' },
  { id: '15', name: '断续点划', desc: '虚实交替，更像标注而非涂抹。', cls: 'hl-dash' },
  { id: '16', name: '荧光胶带', desc: '偏规整，像半透明便利贴胶带。', cls: 'hl-tape' },
];

const cards = styles.map((item) => `
  <section class="card">
    <div class="meta">
      <div class="badge">${item.id}</div>
      <div>
        <h2>${item.name}</h2>
        <p>${item.desc}</p>
      </div>
    </div>
    <div class="demo-line">
      <span class="highlight ${item.cls}">${sample}</span>
    </div>
    <div class="demo-line demo-line--large">
      <span class="highlight ${item.cls}">Part II. 新五年：比一堂五步法更重要的模型出现了</span>
    </div>
  </section>
`).join('');

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>内部分享 - 荧光笔样式 Demo</title>
  <style>
    :root {
      --bg: #f5efe4;
      --panel: rgba(255,255,255,0.82);
      --panel-border: rgba(31,41,55,0.08);
      --text: #111827;
      --muted: #6b7280;
      --amber: #ffd84d;
      --amber-strong: #ffcb2f;
      --amber-deep: #f8b400;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      min-height: 100vh;
      padding: 40px;
      color: var(--text);
      background:
        radial-gradient(circle at top left, rgba(255,255,255,0.78), transparent 28%),
        radial-gradient(circle at right 20%, rgba(255,194,77,0.16), transparent 24%),
        linear-gradient(135deg, #f8f2e8, #eadfce 55%, #e5d7c3);
      font-family: "PingFang SC", "Hiragino Sans GB", "Noto Sans SC", sans-serif;
    }

    .wrap {
      max-width: 1480px;
      margin: 0 auto;
    }

    .hero {
      margin-bottom: 28px;
    }

    .hero h1 {
      margin: 0 0 10px;
      font-size: 42px;
      line-height: 1.08;
      letter-spacing: -0.04em;
    }

    .hero p {
      margin: 0;
      max-width: 960px;
      color: var(--muted);
      font-size: 17px;
      line-height: 1.8;
    }

    .source {
      margin-top: 8px;
      font-size: 13px;
      color: #7c6f57;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 20px;
    }

    .card {
      padding: 24px 24px 26px;
      border-radius: 28px;
      background: var(--panel);
      border: 1px solid var(--panel-border);
      backdrop-filter: blur(14px);
      box-shadow: 0 20px 44px rgba(15,23,42,0.08);
    }

    .meta {
      display: flex;
      gap: 14px;
      align-items: flex-start;
      margin-bottom: 18px;
    }

    .badge {
      min-width: 42px;
      height: 30px;
      padding: 0 10px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 999px;
      background: rgba(248,180,0,0.14);
      color: #9a6700;
      font-size: 13px;
      font-weight: 700;
    }

    .meta h2 {
      margin: 0 0 4px;
      font-size: 22px;
      line-height: 1.2;
      letter-spacing: -0.02em;
    }

    .meta p {
      margin: 0;
      font-size: 14px;
      line-height: 1.65;
      color: var(--muted);
    }

    .demo-line {
      padding: 14px 0;
      font-size: 28px;
      line-height: 1.7;
      letter-spacing: -0.02em;
    }

    .demo-line--large {
      margin-top: 2px;
      font-size: 34px;
      font-weight: 700;
      line-height: 1.42;
    }

    .highlight {
      position: relative;
      display: inline;
      padding: 0 0.08em;
      box-decoration-break: clone;
      -webkit-box-decoration-break: clone;
    }

    .hl-full {
      background: linear-gradient(to top, rgba(255, 216, 77, 0.92), rgba(255, 216, 77, 0.92)) no-repeat;
    }

    .hl-half {
      background: linear-gradient(to top, rgba(255, 216, 77, 0.92) 0 52%, transparent 52% 100%) no-repeat;
    }

    .hl-underline-thin {
      background: linear-gradient(to top, rgba(255, 216, 77, 0.92) 0 18%, transparent 18% 100%) no-repeat;
    }

    .hl-underline-bold {
      background: linear-gradient(to top, rgba(255, 203, 47, 0.95) 0 28%, transparent 28% 100%) no-repeat;
    }

    .hl-double-underline {
      background:
        linear-gradient(to top, rgba(255, 210, 64, 0.95) 0 15%, transparent 15% 100%) no-repeat,
        linear-gradient(to top, rgba(255, 210, 64, 0.72) 0 34%, transparent 34% 100%) no-repeat;
    }

    .hl-mid-swipe {
      background: linear-gradient(to top, transparent 0 30%, rgba(255, 209, 84, 0.95) 30% 63%, transparent 63% 100%) no-repeat;
    }

    .hl-circle::before {
      content: "";
      position: absolute;
      left: -0.24em;
      right: -0.24em;
      top: 50%;
      height: 1.25em;
      transform: translateY(-54%) rotate(-2deg);
      border: 0.12em solid rgba(248, 180, 0, 0.88);
      border-radius: 999px;
      pointer-events: none;
    }

    .hl-rough-box::before {
      content: "";
      position: absolute;
      inset: -0.1em -0.16em;
      border: 0.1em solid rgba(248, 180, 0, 0.9);
      border-radius: 0.46em 0.62em 0.42em 0.58em;
      transform: rotate(-1.4deg);
      opacity: 0.96;
      pointer-events: none;
    }

    .hl-dots-soft {
      background:
        radial-gradient(circle, rgba(255, 214, 71, 0.9) 0 46%, transparent 50%) left bottom / 0.62em 0.54em repeat-x;
      background-position: 0 78%;
    }

    .hl-dots-bold {
      background:
        radial-gradient(circle, rgba(255, 196, 46, 0.96) 0 42%, transparent 47%) left bottom / 0.72em 0.62em repeat-x,
        linear-gradient(to top, rgba(255, 216, 77, 0.2) 0 26%, transparent 26% 100%) no-repeat;
      background-position: 0 76%, 0 0;
    }

    .hl-diagonal {
      background:
        repeating-linear-gradient(-12deg, rgba(255, 212, 80, 0.88) 0 0.36em, rgba(255, 212, 80, 0.6) 0.36em 0.7em, transparent 0.7em 0.95em);
      background-size: 100% 55%;
      background-repeat: no-repeat;
      background-position: 0 82%;
    }

    .hl-wave {
      background:
        radial-gradient(circle at 0.3em 0.42em, rgba(255, 216, 77, 0.9) 0 0.24em, transparent 0.26em) 0 100% / 0.82em 0.62em repeat-x,
        linear-gradient(to top, rgba(255, 216, 77, 0.45) 0 18%, transparent 18% 100%) no-repeat;
      background-position: 0 100%, 0 0;
    }

    .hl-dry-brush {
      background:
        linear-gradient(to top,
          rgba(255, 210, 75, 0.96) 0 14%,
          rgba(255, 210, 75, 0.76) 14% 32%,
          rgba(255, 210, 75, 0.32) 32% 40%,
          transparent 40% 100%) no-repeat;
      filter: saturate(1.04);
    }

    .hl-tail {
      background: linear-gradient(90deg,
        rgba(255, 205, 56, 0.96) 0%,
        rgba(255, 205, 56, 0.92) 46%,
        rgba(255, 205, 56, 0.62) 76%,
        rgba(255, 205, 56, 0.22) 100%);
      background-size: 100% 52%;
      background-repeat: no-repeat;
      background-position: 0 82%;
    }

    .hl-dash {
      background:
        repeating-linear-gradient(90deg,
          rgba(255, 206, 60, 0.95) 0 0.72em,
          transparent 0.72em 0.94em) no-repeat;
      background-size: 100% 28%;
      background-position: 0 84%;
    }

    .hl-tape::before {
      content: "";
      position: absolute;
      inset: 0.04em -0.1em;
      background: rgba(255, 229, 128, 0.7);
      border-radius: 0.12em;
      box-shadow: inset 0 0 0 1px rgba(255,255,255,0.28);
      transform: rotate(-0.6deg);
      z-index: -1;
    }

    @media (max-width: 1120px) {
      body { padding: 24px; }
      .grid { grid-template-columns: 1fr; }
      .hero h1 { font-size: 34px; }
      .demo-line { font-size: 24px; }
      .demo-line--large { font-size: 30px; }
    }
  </style>
</head>
<body>
  <div class="wrap">
    <header class="hero">
      <h1>荧光笔样式 Demo</h1>
      <p>这一页是独立对照页，不影响正式课件。包含 16 种文本高亮风格，覆盖整块涂抹、半高、下划线、圈记、点状、笔刷、拖尾等方向，方便直接挑选。</p>
      <div class="source">参考方向整理自 CSS 文本高亮常见做法：linear-gradient、radial-gradient、text-decoration 系表现和手绘标注思路。</div>
    </header>
    <main class="grid">
      ${cards}
    </main>
  </div>
</body>
</html>`;

fs.writeFileSync(outputPath, html, 'utf8');
console.log(`Wrote ${outputPath}`);
