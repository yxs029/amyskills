const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const inputPath = path.join(projectRoot, 'output', '内部分享：从教育创新到AI创新-raw-presentation.html');
const outputDir = path.join(projectRoot, 'output', 'animation-demos');

const variants = [
  {
    code: 'AA',
    title: 'AA Demo - 极简向上卷动',
    label: 'AA',
    subtitle: '极简向上卷动，变化最克制，重点看节奏是否自然。',
    css: `
    .slides {
      position: relative;
      width: 100vw;
      height: 100vh;
      overflow: hidden;
      isolation: isolate;
    }

    .slide {
      position: absolute;
      inset: 0;
      opacity: 0;
      pointer-events: none;
      transform: translate3d(0, 18vh, 0);
      transition:
        transform 720ms cubic-bezier(0.22, 1, 0.36, 1),
        opacity 420ms ease;
      will-change: transform, opacity;
    }

    .slide.is-active {
      opacity: 1;
      pointer-events: auto;
      transform: translate3d(0, 0, 0);
      z-index: 3;
    }

    .slide.is-before {
      opacity: 0;
      transform: translate3d(0, -24vh, 0);
      z-index: 2;
    }

    .slide.is-after {
      opacity: 0;
      transform: translate3d(0, 24vh, 0);
      z-index: 1;
    }
    `,
    js: `
    function update() {
      slides.forEach((slide, index) => {
        slide.classList.remove('is-active', 'is-before', 'is-after', 'is-hidden');
        if (index < current) {
          slide.classList.add('is-before');
        } else if (index > current) {
          slide.classList.add('is-after');
        }
        if (index === current) {
          slide.classList.add('is-active');
        }
      });
      progressBar.style.width = ((current + 1) / slides.length) * 100 + '%';
    }

    function goTo(index) {
      const nextIndex = Math.max(0, Math.min(slides.length - 1, index));
      if (nextIndex === current) return;
      direction = nextIndex > current ? 1 : -1;
      current = nextIndex;
      update();
    }
    `,
  },
  {
    code: 'BB',
    title: 'BB Demo - 电梯式整页推送',
    label: 'BB',
    subtitle: '更明显的整页上推，像一整张页面被传送带抬上来。',
    css: `
    .slides {
      position: relative;
      width: 100vw;
      height: 100vh;
      overflow: hidden;
      isolation: isolate;
      perspective: 1200px;
    }

    .slide {
      position: absolute;
      inset: 0;
      opacity: 1;
      pointer-events: none;
      transform: translate3d(0, 100%, 0);
      transition: transform 820ms cubic-bezier(0.22, 1, 0.36, 1);
      will-change: transform;
    }

    .slide.is-active {
      pointer-events: auto;
      transform: translate3d(0, 0, 0);
      z-index: 3;
    }

    .slide.is-before {
      transform: translate3d(0, -100%, 0);
      z-index: 2;
    }

    .slide.is-after {
      transform: translate3d(0, 100%, 0);
      z-index: 1;
    }
    `,
    js: `
    function update() {
      slides.forEach((slide, index) => {
        slide.classList.remove('is-active', 'is-before', 'is-after', 'is-hidden');
        if (index < current) {
          slide.classList.add('is-before');
        } else if (index > current) {
          slide.classList.add('is-after');
        }
        if (index === current) {
          slide.classList.add('is-active');
        }
      });
      progressBar.style.width = ((current + 1) / slides.length) * 100 + '%';
    }

    function goTo(index) {
      const nextIndex = Math.max(0, Math.min(slides.length - 1, index));
      if (nextIndex === current) return;
      direction = nextIndex > current ? 1 : -1;
      current = nextIndex;
      update();
    }
    `,
  },
  {
    code: 'CC',
    title: 'CC Demo - 滚筒感卷动',
    label: 'CC',
    subtitle: '向上卷动 + 顶部淡出遮罩，更接近“滚到上面消失、下面再滚上来”。',
    css: `
    .slides {
      position: relative;
      width: 100vw;
      height: 100vh;
      overflow: hidden;
      isolation: isolate;
    }

    .slides::before,
    .slides::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      z-index: 8;
      pointer-events: none;
    }

    .slides::before {
      top: 0;
      height: 18vh;
      background: linear-gradient(180deg, rgba(232, 223, 209, 0.98) 0%, rgba(232, 223, 209, 0.72) 36%, rgba(232, 223, 209, 0) 100%);
    }

    .slides::after {
      bottom: 0;
      height: 16vh;
      background: linear-gradient(0deg, rgba(232, 223, 209, 0.86) 0%, rgba(232, 223, 209, 0.22) 48%, rgba(232, 223, 209, 0) 100%);
    }

    .slide {
      position: absolute;
      inset: 0;
      opacity: 0;
      pointer-events: none;
      transform: translate3d(0, 28vh, 0) scale(0.985);
      transition:
        transform 900ms cubic-bezier(0.2, 0.88, 0.22, 1),
        opacity 620ms ease,
        filter 620ms ease;
      will-change: transform, opacity, filter;
      filter: blur(1px);
    }

    .slide.is-active {
      opacity: 1;
      pointer-events: auto;
      transform: translate3d(0, 0, 0) scale(1);
      filter: blur(0);
      z-index: 4;
    }

    .slide.is-before {
      opacity: 0.18;
      transform: translate3d(0, -36vh, 0) scale(0.985);
      filter: blur(2px);
      z-index: 3;
    }

    .slide.is-after {
      opacity: 0;
      transform: translate3d(0, 34vh, 0) scale(1.015);
      filter: blur(2px);
      z-index: 2;
    }

    .slide__inner {
      scroll-behavior: auto;
    }
    `,
    js: `
    function update() {
      slides.forEach((slide, index) => {
        slide.classList.remove('is-active', 'is-before', 'is-after', 'is-hidden');
        if (index < current) {
          slide.classList.add('is-before');
        } else if (index > current) {
          slide.classList.add('is-after');
        }
        if (index === current) {
          slide.classList.add('is-active');
          const inner = slide.querySelector('.slide__inner');
          if (inner) inner.scrollTop = 0;
        }
      });
      progressBar.style.width = ((current + 1) / slides.length) * 100 + '%';
    }

    function goTo(index) {
      const nextIndex = Math.max(0, Math.min(slides.length - 1, index));
      if (nextIndex === current) return;
      direction = nextIndex > current ? 1 : -1;
      current = nextIndex;
      update();
    }
    `,
  },
];

const sourceHtml = fs.readFileSync(inputPath, 'utf8');
fs.mkdirSync(outputDir, { recursive: true });

const baseCssStart = sourceHtml.indexOf('.slides {');
const baseCssEnd = sourceHtml.indexOf('.slide__inner {\n      height: 100%;', baseCssStart);
const baseJsStart = sourceHtml.indexOf('function update() {');
const baseJsEnd = sourceHtml.indexOf('function next() {', baseJsStart);

if (baseCssStart === -1 || baseCssEnd === -1 || baseJsStart === -1 || baseJsEnd === -1) {
  throw new Error('Unable to locate base animation blocks in source HTML');
}

const baseCssBlock = sourceHtml.slice(baseCssStart, baseCssEnd);
const baseJsBlock = sourceHtml.slice(baseJsStart, baseJsEnd);

for (const variant of variants) {
  const html = buildVariantHtml(sourceHtml, variant);
  const filePath = path.join(outputDir, `${variant.code}-内部分享-动画-demo.html`);
  fs.writeFileSync(filePath, html, 'utf8');
}

const indexHtml = buildIndexHtml(variants);
fs.writeFileSync(path.join(outputDir, 'index.html'), indexHtml, 'utf8');

console.log(`Built animation demos in ${outputDir}`);

function buildVariantHtml(html, variant) {
  const withTitle = html.replace(/<title>[\s\S]*?<\/title>/, `<title>${variant.title}</title>`);
  const withLabel = withTitle.replace(
    /<\/body>/,
    `
  <div class="demo-badge">
    <div class="demo-badge__code">${variant.label}</div>
    <div class="demo-badge__text">${variant.subtitle}</div>
  </div>
</body>`
  );

  if (!withLabel.includes(baseCssBlock) || !withLabel.includes(baseJsBlock)) {
    throw new Error(`Unable to find base blocks in variant source for ${variant.code}`);
  }

  const cssPatched = withLabel.replace(baseCssBlock, `${variant.css.trim()}\n\n    `);
  return cssPatched.replace(baseJsBlock, `${variant.js.trim()}\n\n    `);
}

function buildIndexHtml(variants) {
  const cards = variants.map((variant) => {
    const fileName = `${variant.code}-内部分享-动画-demo.html`;
    return `
      <a class="card" href="./${encodeURI(fileName)}">
        <div class="card__code">${variant.code}</div>
        <div class="card__title">${variant.title}</div>
        <div class="card__desc">${variant.subtitle}</div>
      </a>
    `;
  }).join('');

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>内部分享动画 Demo 选择页</title>
  <style>
    :root {
      --bg-1: #f7f2e8;
      --bg-2: #e8dfd1;
      --text: #1f2937;
      --muted: #6b7280;
      --accent: #c2410c;
      --card: rgba(255,255,255,0.76);
      --border: rgba(31, 41, 55, 0.08);
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      min-height: 100vh;
      padding: 48px;
      font-family: "PingFang SC", "Hiragino Sans GB", "Noto Sans SC", "Microsoft YaHei", sans-serif;
      color: var(--text);
      background:
        radial-gradient(circle at top left, rgba(255,255,255,0.74), transparent 32%),
        radial-gradient(circle at bottom right, rgba(194,65,12,0.12), transparent 28%),
        linear-gradient(135deg, var(--bg-1), var(--bg-2));
    }

    .wrap {
      max-width: 1180px;
      margin: 0 auto;
    }

    h1 {
      margin: 0 0 12px;
      font-size: 42px;
      line-height: 1.15;
    }

    p {
      margin: 0 0 28px;
      font-size: 20px;
      line-height: 1.7;
      color: var(--muted);
      max-width: 880px;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 20px;
    }

    .card {
      display: block;
      padding: 24px;
      border-radius: 24px;
      text-decoration: none;
      color: inherit;
      background: var(--card);
      border: 1px solid var(--border);
      backdrop-filter: blur(18px);
      box-shadow: 0 20px 50px rgba(15, 23, 42, 0.08);
      transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
    }

    .card:hover {
      transform: translateY(-2px);
      box-shadow: 0 28px 68px rgba(15, 23, 42, 0.12);
      border-color: rgba(194, 65, 12, 0.24);
    }

    .card__code {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 60px;
      height: 36px;
      padding: 0 14px;
      border-radius: 999px;
      background: rgba(194, 65, 12, 0.12);
      color: var(--accent);
      font-weight: 700;
      margin-bottom: 18px;
    }

    .card__title {
      font-size: 24px;
      line-height: 1.4;
      font-weight: 700;
      margin-bottom: 10px;
    }

    .card__desc {
      font-size: 16px;
      line-height: 1.75;
      color: var(--muted);
    }

    @media (max-width: 900px) {
      body {
        padding: 24px;
      }

      .grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>内部分享动画 Demo</h1>
    <p>这里是独立对比页，不会影响正式内容。AA 更克制，BB 更像整页上推，CC 最接近你描述的“上面消失、下面滚上来”的滚筒感。</p>
    <div class="grid">${cards}</div>
  </div>
</body>
</html>`;
}
