const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const sourcePath = path.join(projectRoot, 'output', '内部分享：从教育创新到AI创新-v3-presentation.html');
const outputDir = path.join(projectRoot, 'output', 'interaction-demo');
const outputPath = path.join(outputDir, '内部分享：交互实验-demo.html');

fs.mkdirSync(outputDir, { recursive: true });

const baseHtml = fs.readFileSync(sourcePath, 'utf8');

const extraCss = `
    .cursor-lab {
      position: fixed;
      top: 14px;
      left: 14px;
      right: 64px;
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
      padding: 12px 14px;
      border-radius: 18px;
      background: rgba(255, 255, 255, 0.76);
      backdrop-filter: blur(18px);
      box-shadow: 0 10px 32px rgba(15, 23, 42, 0.1);
      z-index: 35;
    }

    .cursor-lab__title {
      font-size: 13px;
      font-weight: 700;
      color: rgba(31, 41, 55, 0.88);
      margin-right: 2px;
    }

    .cursor-chip {
      appearance: none;
      border: 1px solid rgba(31, 41, 55, 0.1);
      background: rgba(255, 255, 255, 0.92);
      color: rgba(31, 41, 55, 0.82);
      border-radius: 999px;
      padding: 7px 12px;
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      transition: transform 160ms ease, border-color 160ms ease, background 160ms ease;
    }

    .cursor-chip:hover {
      transform: translateY(-1px);
      border-color: rgba(194, 65, 12, 0.28);
    }

    .cursor-chip.is-active {
      color: white;
      background: linear-gradient(90deg, #ea580c, #fb923c);
      border-color: transparent;
    }

    .drag-surface {
      position: fixed;
      inset: 0;
      z-index: 5;
      pointer-events: none;
    }

    body[data-cursor-style="1"] .slides { cursor: grab; }
    body[data-cursor-style="1"] .slides.is-dragging { cursor: grabbing; }

    body[data-cursor-style="2"] .slides { cursor: ns-resize; }
    body[data-cursor-style="2"] .slides.is-dragging { cursor: grabbing; }

    body[data-cursor-style="3"] .slides { cursor: move; }
    body[data-cursor-style="3"] .slides.is-dragging { cursor: grabbing; }

    body[data-cursor-style="4"] .slides { cursor: cell; }
    body[data-cursor-style="4"] .slides.is-dragging { cursor: grabbing; }

    body[data-cursor-style="5"] .slides { cursor: zoom-in; }
    body[data-cursor-style="5"] .slides.is-dragging { cursor: zoom-out; }

    body[data-cursor-style="6"] .slides { cursor: crosshair; }
    body[data-cursor-style="6"] .slides.is-dragging { cursor: grabbing; }

    body[data-cursor-style="7"] .slides { cursor: vertical-text; }
    body[data-cursor-style="7"] .slides.is-dragging { cursor: grabbing; }

    body[data-cursor-style="8"] .slides { cursor: alias; }
    body[data-cursor-style="8"] .slides.is-dragging { cursor: grabbing; }

    body[data-cursor-style="9"] .slides { cursor: none; }
    body[data-cursor-style="9"] .cursor-ghost {
      position: fixed;
      width: 28px;
      height: 28px;
      margin-left: -14px;
      margin-top: -14px;
      border-radius: 999px;
      border: 2px solid rgba(194, 65, 12, 0.72);
      box-shadow: 0 0 0 8px rgba(251, 146, 60, 0.12);
      pointer-events: none;
      z-index: 40;
    }

    body[data-cursor-style="10"] .slides { cursor: none; }
    body[data-cursor-style="10"] .cursor-ghost {
      position: fixed;
      width: 22px;
      height: 22px;
      margin-left: -11px;
      margin-top: -11px;
      background: rgba(31, 41, 55, 0.84);
      border-radius: 6px;
      transform: rotate(45deg);
      box-shadow: 0 10px 24px rgba(15, 23, 42, 0.22);
      pointer-events: none;
      z-index: 40;
    }

    .slides.is-dragging .slide.is-active {
      transition-duration: 0ms;
    }

    .slides.drag-preview-up .slide.is-active {
      transform: translate3d(0, -9%, 0);
    }

    .slides.drag-preview-down .slide.is-active {
      transform: translate3d(0, 9%, 0);
    }

    .slides.drag-preview-up .slide.is-after {
      transform: translate3d(0, 91%, 0);
    }

    .slides.drag-preview-down .slide.is-before {
      transform: translate3d(0, -91%, 0);
    }

    .lightbox__viewport {
      position: relative;
      max-width: 94vw;
      max-height: 92vh;
      overflow: hidden;
      touch-action: none;
      border-radius: 22px;
    }

    .lightbox__img {
      transform-origin: center center;
      transition: transform 140ms ease;
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
      cursor: grab;
    }

    .lightbox__img.is-panning {
      cursor: grabbing;
      transition: none;
    }

    .lightbox__hint {
      position: absolute;
      left: 18px;
      bottom: 18px;
      padding: 8px 12px;
      border-radius: 999px;
      font-size: 12px;
      color: rgba(255,255,255,0.92);
      background: rgba(15, 23, 42, 0.42);
      backdrop-filter: blur(10px);
      z-index: 2;
    }

    @media (max-width: 900px) {
      .cursor-lab {
        right: 12px;
        top: 12px;
        padding: 10px;
        gap: 8px;
      }

      .cursor-lab__title {
        width: 100%;
      }
    }
`;

const controlsMarkup = `
  <div class="cursor-lab" id="cursorLab">
    <div class="cursor-lab__title">拖动光标实验</div>
    <button class="cursor-chip is-active" data-cursor-style="1">1 手抓</button>
    <button class="cursor-chip" data-cursor-style="2">2 纵向箭头</button>
    <button class="cursor-chip" data-cursor-style="3">3 Move</button>
    <button class="cursor-chip" data-cursor-style="4">4 Cell</button>
    <button class="cursor-chip" data-cursor-style="5">5 Zoom</button>
    <button class="cursor-chip" data-cursor-style="6">6 Crosshair</button>
    <button class="cursor-chip" data-cursor-style="7">7 Vertical</button>
    <button class="cursor-chip" data-cursor-style="8">8 Alias</button>
    <button class="cursor-chip" data-cursor-style="9">9 光圈</button>
    <button class="cursor-chip" data-cursor-style="10">10 菱形</button>
  </div>
  <div class="drag-surface" id="dragSurface"></div>
  <div class="cursor-ghost" id="cursorGhost" hidden></div>
`;

const lightboxPatch = `
  <div class="lightbox" id="lightbox" aria-hidden="true">
    <button type="button" class="lightbox__close" id="lightboxClose" aria-label="Close">×</button>
    <div class="lightbox__viewport" id="lightboxViewport">
      <img class="lightbox__img" id="lightboxImage" alt="" />
      <div class="lightbox__hint">支持双指缩放、拖拽平移、双击放大</div>
    </div>
  </div>
`;

const extraScript = `
    const cursorLab = document.getElementById('cursorLab');
    const cursorGhost = document.getElementById('cursorGhost');
    const dragSurface = document.getElementById('dragSurface');
    const slidesRoot = document.querySelector('.slides');
    const lightboxViewport = document.getElementById('lightboxViewport');
    const pointerState = new Map();
    let dragStartY = 0;
    let dragDeltaY = 0;
    let gestureState = { scale: 1, x: 0, y: 0, startScale: 1, startX: 0, startY: 0, pinchDistance: 0, pinchScale: 1 };

    document.body.dataset.cursorStyle = '1';

    function updateGhost(x, y) {
      if (document.body.dataset.cursorStyle === '9' || document.body.dataset.cursorStyle === '10') {
        cursorGhost.hidden = false;
        cursorGhost.style.left = x + 'px';
        cursorGhost.style.top = y + 'px';
      } else {
        cursorGhost.hidden = true;
      }
    }

    document.addEventListener('pointermove', (event) => {
      updateGhost(event.clientX, event.clientY);
    });

    cursorLab?.addEventListener('click', (event) => {
      const button = event.target.closest('[data-cursor-style]');
      if (!button) return;
      document.body.dataset.cursorStyle = button.dataset.cursorStyle;
      cursorLab.querySelectorAll('.cursor-chip').forEach((chip) => chip.classList.toggle('is-active', chip === button));
      cursorGhost.hidden = !(button.dataset.cursorStyle === '9' || button.dataset.cursorStyle === '10');
    });

    slidesRoot?.addEventListener('pointerdown', (event) => {
      if (lightbox.classList.contains('is-open')) return;
      if (event.target.closest('.thumb, .fullscreen-fab, .cursor-lab, button, a')) return;
      dragStartY = event.clientY;
      dragDeltaY = 0;
      slidesRoot.classList.add('is-dragging');
    });

    document.addEventListener('pointermove', (event) => {
      if (!slidesRoot?.classList.contains('is-dragging')) return;
      dragDeltaY = event.clientY - dragStartY;
      slidesRoot.classList.toggle('drag-preview-down', dragDeltaY > 18);
      slidesRoot.classList.toggle('drag-preview-up', dragDeltaY < -18);
    });

    document.addEventListener('pointerup', () => {
      if (!slidesRoot?.classList.contains('is-dragging')) return;
      const threshold = 90;
      slidesRoot.classList.remove('is-dragging', 'drag-preview-up', 'drag-preview-down');
      if (dragDeltaY <= -threshold) next();
      if (dragDeltaY >= threshold) prev();
      dragDeltaY = 0;
    });

    function applyLightboxTransform() {
      lightboxImage.style.transform = 'translate(' + gestureState.x + 'px, ' + gestureState.y + 'px) scale(' + gestureState.scale + ')';
    }

    function resetLightboxTransform() {
      gestureState = { scale: 1, x: 0, y: 0, startScale: 1, startX: 0, startY: 0, pinchDistance: 0, pinchScale: 1 };
      lightboxImage.classList.remove('is-panning');
      applyLightboxTransform();
    }

    function getDistance(a, b) {
      return Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
    }

    function openLightbox(src, alt) {
      lightboxImage.src = src;
      lightboxImage.alt = alt || '';
      lightbox.classList.add('is-open');
      lightbox.setAttribute('aria-hidden', 'false');
      resetLightboxTransform();
    }

    function closeLightbox() {
      lightbox.classList.remove('is-open');
      lightbox.setAttribute('aria-hidden', 'true');
      lightboxImage.src = '';
      pointerState.clear();
      resetLightboxTransform();
    }

    lightboxImage.addEventListener('dblclick', () => {
      if (gestureState.scale > 1.2) {
        resetLightboxTransform();
      } else {
        gestureState.scale = 2;
        gestureState.x = 0;
        gestureState.y = 0;
        applyLightboxTransform();
      }
    });

    lightboxViewport?.addEventListener('wheel', (event) => {
      event.preventDefault();
      const delta = event.deltaY < 0 ? 0.14 : -0.14;
      gestureState.scale = Math.min(4, Math.max(1, gestureState.scale + delta));
      if (gestureState.scale === 1) {
        gestureState.x = 0;
        gestureState.y = 0;
      }
      applyLightboxTransform();
    }, { passive: false });

    lightboxViewport?.addEventListener('pointerdown', (event) => {
      if (!lightbox.classList.contains('is-open')) return;
      pointerState.set(event.pointerId, { clientX: event.clientX, clientY: event.clientY });
      lightboxViewport.setPointerCapture?.(event.pointerId);
      if (pointerState.size === 1 && gestureState.scale > 1) {
        gestureState.startX = gestureState.x;
        gestureState.startY = gestureState.y;
        lightboxImage.classList.add('is-panning');
      }
      if (pointerState.size === 2) {
        const [a, b] = [...pointerState.values()];
        gestureState.pinchDistance = getDistance(a, b);
        gestureState.pinchScale = gestureState.scale;
      }
    });

    lightboxViewport?.addEventListener('pointermove', (event) => {
      if (!pointerState.has(event.pointerId)) return;
      const prevPoint = pointerState.get(event.pointerId);
      pointerState.set(event.pointerId, { clientX: event.clientX, clientY: event.clientY });

      if (pointerState.size === 2) {
        const [a, b] = [...pointerState.values()];
        const nextDistance = getDistance(a, b);
        if (gestureState.pinchDistance > 0) {
          gestureState.scale = Math.min(4, Math.max(1, gestureState.pinchScale * (nextDistance / gestureState.pinchDistance)));
          if (gestureState.scale === 1) {
            gestureState.x = 0;
            gestureState.y = 0;
          }
          applyLightboxTransform();
        }
        return;
      }

      if (pointerState.size === 1 && gestureState.scale > 1) {
        gestureState.x = gestureState.startX + (event.clientX - prevPoint.clientX);
        gestureState.y = gestureState.startY + (event.clientY - prevPoint.clientY);
        gestureState.startX = gestureState.x;
        gestureState.startY = gestureState.y;
        applyLightboxTransform();
      }
    });

    function releasePointer(event) {
      pointerState.delete(event.pointerId);
      if (pointerState.size < 2) {
        gestureState.pinchDistance = 0;
      }
      if (pointerState.size === 0) {
        lightboxImage.classList.remove('is-panning');
      }
    }

    lightboxViewport?.addEventListener('pointerup', releasePointer);
    lightboxViewport?.addEventListener('pointercancel', releasePointer);
`;

let html = baseHtml
  .replace('</style>', `${extraCss}\n  </style>`)
  .replace('<div class="progress"><div class="progress__bar" id="progressBar"></div></div>', `${controlsMarkup}\n  <div class="progress"><div class="progress__bar" id="progressBar"></div></div>`)
  .replace(/<div class="lightbox" id="lightbox"[\s\S]*?<\/div>\s*<script>/, `${lightboxPatch}\n  <script>`)
  .replace(/function openLightbox\(src, alt\) \{[\s\S]*?lightbox\.addEventListener\('click', \(event\) => \{\s+if \(event\.target === lightbox\) \{\s+closeLightbox\(\);\s+\}\s+\}\);/, extraScript);

html = html.replace(/<title>[\s\S]*?<\/title>/, '<title>内部分享：交互实验 Demo</title>');

fs.writeFileSync(outputPath, html, 'utf8');
console.log(`Built interaction demo: ${outputPath}`);
