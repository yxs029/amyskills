const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const crypto = require('crypto');

const sourceDoc = process.argv[2];
const outputFile = process.argv[3];

if (!sourceDoc || !outputFile) {
  console.error('Usage: node src/build-from-feishu.js <feishu-doc-url> <output.html>');
  process.exit(1);
}

const outputPath = path.resolve(outputFile);
const outputDir = path.dirname(outputPath);
const buildJsPath = path.join(__dirname, 'build.js');
const projectRoot = path.resolve(__dirname, '..');
const backgroundAssetsDir = path.join(projectRoot, 'assets', 'backgrounds');
const coverBackgroundPath = path.join(projectRoot, 'assets', 'cover-default.png');
const faviconPath = path.join(projectRoot, 'assets', 'favicon.ico');
const MEDIA_CONCURRENCY = Math.max(4, Number(process.env.MEDIA_CONCURRENCY || '6'));
const TOKEN_CACHE_FILE = '.token-map.json';
const FEISHU_IMAGE_MANIFEST_FILE = '.feishu-image-manifest.json';
const MEDIA_RETRY_LIMIT = Math.max(1, Number(process.env.MEDIA_RETRY_LIMIT || '4'));

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function run(command, args, options = {}) {
  return cp.execFileSync(command, args, {
    encoding: 'utf8',
    maxBuffer: 32 * 1024 * 1024,
    ...options,
  });
}

function runAsync(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    cp.execFile(command, args, {
      encoding: 'utf8',
      maxBuffer: 32 * 1024 * 1024,
      ...options,
    }, (error, stdout, stderr) => {
      if (error) {
        error.stdout = stdout;
        error.stderr = stderr;
        reject(error);
        return;
      }
      resolve(stdout);
    });
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function fetchFeishuDoc(doc) {
  const raw = run('lark-cli', [
    'docs',
    '+fetch',
    '--doc',
    doc,
    '--scope',
    'full',
    '--detail',
    'full',
    '--doc-format',
    'xml',
    '--format',
    'json',
  ]);
  const parsed = JSON.parse(raw);
  if (!parsed.ok || !parsed.data) {
    throw new Error(parsed.error?.message || 'Failed to fetch Feishu document');
  }
  if (parsed.data.markdown) {
    return parsed.data;
  }
  if (parsed.data.document?.content) {
    const content = parsed.data.document.content;
    const title = decodeHtmlEntity(content.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1] || 'Feishu Presentation');
    return {
      title,
      feishuContent: content,
      markdown: null,
      document: parsed.data.document,
    };
  }
  return parsed.data;
}

function decodeHtmlEntity(value) {
  return String(value || '')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&');
}

function extensionFromMime(mime) {
  const normalized = String(mime || '').toLowerCase();
  if (normalized.includes('jpeg') || normalized.includes('jpg')) return '.jpg';
  if (normalized.includes('webp')) return '.webp';
  if (normalized.includes('gif')) return '.gif';
  return '.png';
}

function shortHash(value) {
  return crypto.createHash('sha1').update(String(value || '')).digest('hex').slice(0, 16);
}

function parseHtmlAttributes(text) {
  const attrs = {};
  const regex = /([\w:-]+)="([^"]*)"/g;
  let match;
  while ((match = regex.exec(String(text || '')))) {
    attrs[match[1].toLowerCase()] = decodeHtmlEntity(match[2]);
  }
  return attrs;
}

function canonicalRemoteImageUrl(url) {
  try {
    const parsed = new URL(url);
    return `${parsed.origin}${parsed.pathname}`;
  } catch {
    return String(url || '');
  }
}

function getImageDimensions(filePath) {
  try {
    const output = cp.execFileSync('sips', ['-g', 'pixelWidth', '-g', 'pixelHeight', filePath], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    });
    return {
      width: Number(output.match(/pixelWidth:\s*(\d+)/)?.[1] || 0),
      height: Number(output.match(/pixelHeight:\s*(\d+)/)?.[1] || 0),
    };
  } catch {
    return { width: 0, height: 0 };
  }
}

function dimensionsMatch(actual, expected) {
  if (!expected?.width || !expected?.height) return true;
  return actual.width === expected.width && actual.height === expected.height;
}

function loadFeishuImageManifest(resourcesDir) {
  const manifestPath = path.join(resourcesDir, FEISHU_IMAGE_MANIFEST_FILE);
  if (!fs.existsSync(manifestPath)) return {};
  try {
    return JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch {
    return {};
  }
}

function saveFeishuImageManifest(resourcesDir, manifest) {
  fs.mkdirSync(resourcesDir, { recursive: true });
  const manifestPath = path.join(resourcesDir, FEISHU_IMAGE_MANIFEST_FILE);
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2), 'utf8');
}

function buildRemoteImageKey(attrs, href) {
  const stableIdentity =
    attrs.src ||
    attrs.id ||
    attrs.token ||
    attrs['file-token'] ||
    attrs.file_token ||
    canonicalRemoteImageUrl(href) ||
    href;
  return shortHash(stableIdentity);
}

function downloadRemoteImage(url, resourcesDir, fileName, expected = {}, manifestEntry = null) {
  const outputPath = path.join(resourcesDir, fileName);
  fs.mkdirSync(resourcesDir, { recursive: true });

  if (fs.existsSync(outputPath)) {
    const actual = getImageDimensions(outputPath);
    const manifestLooksCurrent =
      !manifestEntry?.urlFingerprint ||
      manifestEntry.urlFingerprint === shortHash(canonicalRemoteImageUrl(url));
    if (dimensionsMatch(actual, expected) && manifestLooksCurrent) {
      return outputPath;
    }
  }

  const tempPath = `${outputPath}.download`;
  cp.execFileSync('curl', ['-L', '--fail', '--silent', '--show-error', '--max-time', '60', '-o', tempPath, url], {
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const actual = getImageDimensions(tempPath);
  if (!dimensionsMatch(actual, expected)) {
    fs.rmSync(tempPath, { force: true });
    throw new Error(`Downloaded image dimensions mismatch for ${fileName}: expected ${expected.width}x${expected.height}, got ${actual.width}x${actual.height}`);
  }
  fs.renameSync(tempPath, outputPath);
  return outputPath;
}

function isArchiveHeadingText(text) {
  const normalized = decodeHtmlEntity(text)
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return /^\s*#*\s*(附录|归档)(?:\s|[:：]|$)/.test(normalized);
}

function stripArchiveHtmlSections(body) {
  const headingPattern = /<h([1-6])\b[^>]*>[\s\S]*?<\/h\1>/gi;
  let match;
  while ((match = headingPattern.exec(body))) {
    if (isArchiveHeadingText(match[0])) {
      return body.slice(0, match.index);
    }
  }
  return body;
}

function stripArchiveMarkdownSections(markdown) {
  const lines = String(markdown || '').split(/\r?\n/);
  const kept = [];
  for (const line of lines) {
    if (/^\s{0,3}#{1,6}\s+/.test(line) && isArchiveHeadingText(line.replace(/^\s{0,3}#{1,6}\s+/, ''))) {
      break;
    }
    kept.push(line);
  }
  return kept.join('\n').trimEnd();
}

async function replaceAsync(source, regex, replacer) {
  const matches = [];
  source.replace(regex, (...args) => {
    matches.push(args);
    return args[0];
  });

  const replacements = await Promise.all(matches.map((match) => replacer(...match)));
  let index = 0;
  return source.replace(regex, () => replacements[index++]);
}

async function feishuContentToSourceHtml(title, content, resourcesDirName = '', resourcesDir = '') {
  let body = String(content || '').replace(/<title\b[^>]*>[\s\S]*?<\/title>/i, '');
  body = stripArchiveHtmlSections(body);
  body = normalizeFeishuStyleAttrs(body);
  const urlCache = new Map();
  const imageManifest = resourcesDir ? loadFeishuImageManifest(resourcesDir) : {};
  const mediaState = resourcesDir ? buildMediaState(resourcesDir) : null;

  body = body.replace(/<img\b([^>]*)\bhref="([^"]+)"([^>]*)>/gi, (_, before, href, after) => {
    const mergedAttrs = `${before} ${after}`.replace(/\s+/g, ' ').trim();
    const attrs = parseHtmlAttributes(mergedAttrs);
    const mime = mergedAttrs.match(/\bmime="([^"]+)"/i)?.[1] || 'image/png';
    const decodedHref = decodeHtmlEntity(href);
    let src = decodedHref;

    if (resourcesDir && resourcesDirName && /^https?:\/\//i.test(decodedHref)) {
      const imageKey = buildRemoteImageKey(attrs, decodedHref);
      if (!urlCache.has(imageKey)) {
        const fileName = `feishu-img-${imageKey}${extensionFromMime(mime)}`;
        const expected = {
          width: Number(attrs.width || 0),
          height: Number(attrs.height || 0),
        };
        downloadRemoteImage(decodedHref, resourcesDir, fileName, expected, imageManifest[imageKey]);
        imageManifest[imageKey] = {
          fileName,
          width: expected.width || null,
          height: expected.height || null,
          urlFingerprint: shortHash(canonicalRemoteImageUrl(decodedHref)),
          updatedAt: new Date().toISOString(),
        };
        urlCache.set(imageKey, path.posix.join(resourcesDirName, fileName));
      }
      src = urlCache.get(imageKey);
    }

    const cleanedAttrs = mergedAttrs
      .replace(/\bhref="[^"]*"/gi, '')
      .replace(/\bsrc="[^"]*"/gi, '')
      .replace(/\bname="[^"]*"/gi, '')
      .trim();
    return `<img src="${escapeHtml(src)}"${cleanedAttrs ? ` ${cleanedAttrs}` : ''}>`;
  });

  body = await replaceAsync(body, /<img\b([^>]*)>/gi, async (full, rawAttrs) => {
    const attrs = parseHtmlAttributes(rawAttrs);
    const srcValue = decodeHtmlEntity(attrs.src || '');
    if (
      !resourcesDir ||
      !resourcesDirName ||
      !srcValue ||
      /^https?:\/\//i.test(srcValue) ||
      srcValue.startsWith('data:') ||
      srcValue.includes('/')
    ) {
      return full;
    }

    const fileName = await downloadMedia(srcValue, resourcesDir, mediaState);
    if (!fileName) return full;

    const cleanedAttrs = rawAttrs
      .replace(/\bsrc="[^"]*"/gi, '')
      .replace(/\bname="[^"]*"/gi, '')
      .trim();
    return `<img src="${escapeHtml(path.posix.join(resourcesDirName, fileName))}"${cleanedAttrs ? ` ${cleanedAttrs}` : ''}>`;
  });
  if (resourcesDir) saveFeishuImageManifest(resourcesDir, imageManifest);
  if (resourcesDir && mediaState) saveTokenCache(resourcesDir, mediaState.tokenCache);
  body = body.replace(/<cite\b[^>]*>([\s\S]*?)<\/cite>/gi, (_, inner) => inner.trim());
  body = body.replace(/<sheet\b[^>]*><\/sheet>/gi, '');
  body = body.replace(/<bitable\b[^>]*><\/bitable>/gi, '');
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <title>${escapeHtml(title)}</title>
  </head>
  <body>${body}</body>
</html>`;
}

function stripWrappedAsterisks(text) {
  return text.replace(/^\*(.*)\*$/s, '$1');
}

function renderBasicInline(text) {
  let working = escapeHtml(text);
  working = working.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
  working = working.replace(/\*([^*]+)\*/g, '<i>$1</i>');
  return working;
}

function parseAttributes(text) {
  const attrs = {};
  const regex = /([a-zA-Z-]+)="([^"]*)"/g;
  let match;
  while ((match = regex.exec(text))) {
    attrs[match[1].toLowerCase()] = match[2];
  }
  return attrs;
}

function mapTextColor(color) {
  const normalized = String(color || '').toLowerCase();
  if (normalized === 'red') return '#FF0000';
  if (normalized === 'gray' || normalized === 'grey') return '#6b7280';
  if (normalized === 'blue') return '#2563eb';
  if (normalized === 'green') return '#16a34a';
  if (/rgb\(\s*216\s*,\s*57\s*,\s*49\s*\)/i.test(normalized)) return '#FF0000';
  return color || '';
}

function mapBackgroundColor(color) {
  const normalized = String(color || '').toLowerCase();
  if (normalized === 'light-yellow' || normalized === 'yellow') return '#fff199';
  if (/rgba?\(\s*255\s*,\s*(246|233)\s*,\s*(122|40)/i.test(normalized)) return '#fff199';
  if (normalized === 'light-red') return '#ffd7d7';
  if (normalized === 'light-blue') return '#dceeff';
  if (normalized === 'light-green') return '#e5f5db';
  return color || '#fff199';
}

function mergeStyleAttribute(attrsText, styles) {
  const existingStyle = attrsText.match(/\bstyle="([^"]*)"/i)?.[1] || '';
  const cleanedAttrs = attrsText.replace(/\s*\bstyle="[^"]*"/i, '').trim();
  const mergedStyle = [...styles, existingStyle].filter(Boolean).join(' ').trim();
  return `${cleanedAttrs}${mergedStyle ? ` style="${escapeHtml(mergedStyle)}"` : ''}`.trim();
}

function normalizeFeishuStyleAttrs(html) {
  return String(html || '').replace(/<span\b([^>]*)>/gi, (full, attrText) => {
    const attrs = parseAttributes(attrText);
    const styles = [];
    if (attrs['text-color'] || attrs.color) {
      styles.push(`color: ${mapTextColor(attrs['text-color'] || attrs.color)};`);
    }
    if (attrs['background-color'] || attrs.bgcolor) {
      styles.push(`background-color: ${mapBackgroundColor(attrs['background-color'] || attrs.bgcolor)};`);
    }
    if (!styles.length) return full;
    const cleanedAttrs = attrText
      .replace(/\s*\btext-color="[^"]*"/gi, '')
      .replace(/\s*\bbackground-color="[^"]*"/gi, '')
      .replace(/\s*\bcolor="[^"]*"/gi, '')
      .replace(/\s*\bbgcolor="[^"]*"/gi, '');
    return `<span ${mergeStyleAttribute(cleanedAttrs, styles)}>`;
  });
}

function renderInline(text) {
  const placeholders = [];
  let working = text;

  function stash(html) {
    const key = `__HTML_${placeholders.length}__`;
    placeholders.push({ key, html });
    return key;
  }

  working = normalizeFeishuInlineTags(working);

  for (let pass = 0; pass < 8 && /<text\b/i.test(working); pass += 1) {
    const next = working.replace(/<text\b([^>]*)>([\s\S]*?)<\/text>/gi, (_, attrText, inner) => {
      const attrs = parseAttributes(attrText);
      const styles = [];
      if (attrs.color) styles.push(`color: ${mapTextColor(attrs.color)};`);
      if (attrs.bgcolor || attrs['background-color']) {
        styles.push(`background-color: ${mapBackgroundColor(attrs.bgcolor || attrs['background-color'])};`);
      }
      const rendered = renderBasicInline(stripWrappedAsterisks(inner));
      const span = styles.length ? `<span style="${styles.join(' ')}">${rendered}</span>` : rendered;
      return stash(attrs.underline === 'true' ? `<u>${span}</u>` : span);
    });
    if (next === working) break;
    working = next;
  }

  working = working.replace(/\*\*([^*]+)\*\*/g, (_, inner) => {
    return stash(`<b>${escapeHtml(inner)}</b>`);
  });

  working = working.replace(/\*([^*]+)\*/g, (_, inner) => {
    return stash(`<i>${escapeHtml(inner)}</i>`);
  });

  working = escapeHtml(working);

  for (const placeholder of placeholders) {
    working = working.replace(placeholder.key, placeholder.html);
  }

  return working;
}

function normalizeFeishuInlineTags(text) {
  let working = String(text || '');

  const decodeTagEntities = (value) => value
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&');

  working = decodeTagEntities(working);
  working = working.replace(/<mention-user\b[^>]*\/>/gi, '');
  working = working.replace(/<\/?(synced-source|source-synced|reference-synced|callout|quote-container)\b[^>]*>/gi, '');
  working = working.replace(/<mention-doc\b[^>]*>([\s\S]*?)<\/mention-doc>/gi, (_, label) => label.trim());
  working = working.replace(/<mention-doc\b[^>]*\/>/gi, '');

  return working;
}

function parseImageTag(line) {
  const token = line.match(/token="([^"]+)"/)?.[1];
  const width = line.match(/width="([^"]+)"/)?.[1];
  const height = line.match(/height="([^"]+)"/)?.[1];
  const align = line.match(/align="([^"]+)"/)?.[1] || 'center';
  return { token, width, height, align };
}

function collectImageTokens(markdown) {
  const tokens = [];
  const regex = /<image\s+token="([^"]+)"/g;
  let match;
  while ((match = regex.exec(markdown))) {
    tokens.push(match[1]);
  }
  return [...new Set(tokens)];
}

function loadTokenCache(resourcesDir) {
  const cachePath = path.join(resourcesDir, TOKEN_CACHE_FILE);
  if (!fs.existsSync(cachePath)) return {};
  try {
    return JSON.parse(fs.readFileSync(cachePath, 'utf8'));
  } catch {
    return {};
  }
}

function saveTokenCache(resourcesDir, tokenCache) {
  const cachePath = path.join(resourcesDir, TOKEN_CACHE_FILE);
  fs.writeFileSync(cachePath, JSON.stringify(tokenCache, null, 2), 'utf8');
}

function computeFileFingerprint(filePath) {
  const buffer = fs.readFileSync(filePath);
  const size = buffer.byteLength;
  const sha1 = crypto.createHash('sha1').update(buffer).digest('hex');
  return { size, sha1, key: `${size}:${sha1}` };
}

function buildMediaState(resourcesDir) {
  const tokenCache = loadTokenCache(resourcesDir);
  const hashIndex = new Map();
  const tokenIndex = new Map();
  const entries = fs.readdirSync(resourcesDir).filter((name) => {
    if (name.startsWith('.')) return false;
    const fullPath = path.join(resourcesDir, name);
    return fs.existsSync(fullPath) && fs.statSync(fullPath).isFile();
  });

  for (const name of entries) {
    const match = name.match(/^([A-Za-z0-9]+)\./);
    if (match) {
      tokenIndex.set(match[1], name);
    }
    const fullPath = path.join(resourcesDir, name);
    const fingerprint = computeFileFingerprint(fullPath);
    hashIndex.set(fingerprint.key, name);
  }

  for (const [token, fileName] of Object.entries(tokenCache)) {
    const fullPath = path.join(resourcesDir, fileName);
    if (fs.existsSync(fullPath)) {
      tokenIndex.set(token, fileName);
    }
  }

  return { tokenCache, tokenIndex, hashIndex };
}

async function downloadMedia(token, resourcesDir, mediaState) {
  const cached = mediaState.tokenIndex.get(token) || mediaState.tokenCache[token];
  if (cached && fs.existsSync(path.join(resourcesDir, cached))) {
    mediaState.tokenCache[token] = cached;
    mediaState.tokenIndex.set(token, cached);
    return cached;
  }

  if (process.env.SKIP_MISSING_MEDIA === '1') {
    return null;
  }

  const targetBase = `./${token}`;
  let parsed = null;

  for (let attempt = 1; attempt <= MEDIA_RETRY_LIMIT; attempt += 1) {
    try {
      const raw = await runAsync('lark-cli', ['docs', '+media-download', '--token', token, '--output', targetBase, '--overwrite'], {
        cwd: resourcesDir,
      });
      parsed = JSON.parse(raw);
    } catch (error) {
      const candidate = String(error.stdout || error.stderr || '').trim();
      const jsonStart = candidate.lastIndexOf('\n{') >= 0 ? candidate.lastIndexOf('\n{') + 1 : candidate.indexOf('{');
      if (jsonStart >= 0) {
        parsed = JSON.parse(candidate.slice(jsonStart));
      } else {
        throw error;
      }
    }

    if (parsed.ok && parsed.data?.saved_path) {
      break;
    }

    const message = String(parsed.error?.message || '');
    const isRateLimited = message.includes('frequency limit') || message.includes('99991400');
    if (!isRateLimited || attempt === MEDIA_RETRY_LIMIT) {
      throw new Error(parsed.error?.message || `Failed to download media for token ${token}`);
    }

    await sleep(400 * attempt);
  }

  const savedName = path.basename(parsed.data.saved_path);
  const savedPath = path.join(resourcesDir, savedName);
  const fingerprint = computeFileFingerprint(savedPath);
  const duplicate = mediaState.hashIndex.get(fingerprint.key);

  if (duplicate && duplicate !== savedName && fs.existsSync(path.join(resourcesDir, duplicate))) {
    fs.unlinkSync(savedPath);
    mediaState.tokenCache[token] = duplicate;
    mediaState.tokenIndex.set(token, duplicate);
    return duplicate;
  }

  mediaState.hashIndex.set(fingerprint.key, savedName);
  mediaState.tokenCache[token] = savedName;
  mediaState.tokenIndex.set(token, savedName);
  return savedName;
}

async function mapWithConcurrency(items, concurrency, worker) {
  const results = new Array(items.length);
  let cursor = 0;

  async function runWorker() {
    while (true) {
      const current = cursor;
      cursor += 1;
      if (current >= items.length) return;
      results[current] = await worker(items[current], current);
    }
  }

  const workerCount = Math.min(concurrency, items.length || 1);
  await Promise.all(Array.from({ length: workerCount }, () => runWorker()));
  return results;
}

async function buildImageMap(markdown, resourcesDir) {
  const tokenMap = new Map();
  const tokens = collectImageTokens(markdown);
  const mediaState = buildMediaState(resourcesDir);

  const results = await mapWithConcurrency(tokens, MEDIA_CONCURRENCY, async (token) => {
    const filename = await downloadMedia(token, resourcesDir, mediaState);
    return { token, filename };
  });

  for (const item of results) {
    if (item && item.filename) {
      tokenMap.set(item.token, item.filename);
    }
  }

  saveTokenCache(resourcesDir, mediaState.tokenCache);
  return tokenMap;
}

function renderImageLine(line, tokenMap, resourcesDirName) {
  const { token, width, height } = parseImageTag(line);
  const filename = tokenMap.get(token);
  if (!filename) return '';
  return `<img src="${escapeHtml(path.posix.join(resourcesDirName, filename))}"${height ? ` height="${escapeHtml(height)}"` : ''}${width ? ` width="${escapeHtml(width)}"` : ''}/>`;
}

function consumeGrid(lines, startIndex, tokenMap, resourcesDirName) {
  const collected = [];
  let index = startIndex;

  while (index < lines.length) {
    const line = lines[index].trim();
    collected.push(line);
    if (line === '</grid>') {
      break;
    }
    index += 1;
  }

  const html = collected
    .filter((line) => line.startsWith('<image '))
    .map((line) => renderImageLine(line, tokenMap, resourcesDirName))
    .join('\n');

  return { html, nextIndex: index };
}

function parseListSection(lines, startIndex) {
  const items = [];
  let index = startIndex;

  function getListLevel(indent) {
    const value = String(indent || '');
    const tabCount = (value.match(/\t/g) || []).length;
    const spaceCount = (value.match(/ /g) || []).length;

    if (tabCount > 0) {
      return Math.max(0, tabCount - 1);
    }

    if (spaceCount <= 2) {
      return 0;
    }

    return Math.floor((spaceCount - 2) / 2);
  }

  while (index < lines.length) {
    const line = lines[index];
    if (!line.trim()) {
      index += 1;
      continue;
    }
    const match = line.match(/^(\s*)(\d+\.\s+|-\s+)(.+)$/);
    if (!match) break;
    items.push({
      level: getListLevel(match[1]),
      type: match[2].trim().startsWith('-') ? 'ul' : 'ol',
      text: match[3].trim(),
    });
    index += 1;
  }

  return { items, nextIndex: index - 1 };
}

function renderListItems(items, startIndex = 0, level = items[startIndex]?.level ?? 0) {
  if (!items[startIndex]) {
    return { html: '', nextIndex: startIndex };
  }

  const listType = items[startIndex].type;
  let html = `<${listType}>`;
  let index = startIndex;

  while (index < items.length) {
    const item = items[index];
    if (item.level < level || item.type !== listType && item.level === level) {
      break;
    }
    if (item.level > level) {
      const nested = renderListItems(items, index, item.level);
      html += nested.html;
      index = nested.nextIndex;
      continue;
    }

    html += `<li><div>${renderInline(item.text)}</div>`;
    index += 1;

    if (index < items.length && items[index].level > level) {
      const nested = renderListItems(items, index, items[index].level);
      html += nested.html;
      index = nested.nextIndex;
    }

    html += `</li>`;
  }

  html += `</${listType}>`;
  return { html, nextIndex: index };
}

function renderHeading(text) {
  const level = (text.match(/^#+/) || [''])[0].length || 1;
  const plain = text.replace(/^#+\s*/, '').trim();
  const rendered = renderInline(plain);
  const safeLabel = escapeHtml(renderInline(plain).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());

  if (/^Part\s*[IVX0-9]/i.test(plain)) {
    return `<div data-nav-level="${level}" data-nav-label="${safeLabel}"><span style="font-size: 24px;"><span style="background-color: #fff199;"><b>${rendered}</b></span></span></div>`;
  }

  return `<div data-nav-level="${level}" data-nav-label="${safeLabel}"><b>${rendered}</b></div>`;
}

function renderParagraph(line) {
  const plain = line.trim();
  if (!plain) return '';
  const rendered = renderInline(plain);
  if (!rendered.trim()) return '';

  if (/^Level[1-5]\./i.test(plain)) {
    return `<div><span style="color: #FF0000;"><b>${rendered}</b></span></div>`;
  }

  return `<div>${rendered}</div>`;
}

function renderMarkdownLines(lines, tokenMap, resourcesDirName) {
  const html = [];
  let inQuoteContainer = false;

  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const trimmed = line.trim();

    if (!trimmed) continue;
    if (/^<\/?(synced-source|source-synced|reference-synced|quote-container)\b/i.test(trimmed)) {
      continue;
    }
    if (/^<mention-user\b[^>]*\/>$/i.test(trimmed)) {
      continue;
    }
    if (trimmed === '<quote-container>') {
      if (!inQuoteContainer) {
        html.push('<div class="quote-note">');
        inQuoteContainer = true;
      }
      continue;
    }
    if (trimmed === '</quote-container>') {
      if (inQuoteContainer) {
        html.push('</div>');
        inQuoteContainer = false;
      }
      continue;
    }
    if (trimmed === '---') {
      html.push('<hr/>');
      continue;
    }
    if (trimmed.startsWith('<grid')) {
      const grid = consumeGrid(lines, index, tokenMap, resourcesDirName);
      if (grid.html) html.push(grid.html);
      index = grid.nextIndex;
      continue;
    }
    if (trimmed.startsWith('<image ')) {
      html.push(renderImageLine(trimmed, tokenMap, resourcesDirName));
      continue;
    }
    if (/^(\s*)(\d+\.\s+|-\s+)/.test(line)) {
      const section = parseListSection(lines, index);
      const rendered = renderListItems(section.items);
      if (rendered.html) html.push(rendered.html);
      index = section.nextIndex;
      continue;
    }
    if (/^#{1,6}\s+/.test(trimmed)) {
      html.push(renderHeading(trimmed));
      continue;
    }

    html.push(renderParagraph(line));
  }

  if (inQuoteContainer) {
    html.push('</div>');
  }

  return html.join('\n');
}

function markdownToHtml(title, markdown, tokenMap, resourcesDirName) {
  const lines = markdown.replace(/\r\n/g, '\n').split('\n');
  const html = renderMarkdownLines(lines, tokenMap, resourcesDirName);

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <title>${escapeHtml(title)}</title>
  </head>
  <body>${html}</body>
</html>`;
}

function splitMarkdownIntoSections(markdown) {
  const lines = markdown.replace(/\r\n/g, '\n').split('\n');
  const sections = [];
  let current = [];

  function flush() {
    const content = current.join('\n').trim();
    if (content) sections.push(content);
    current = [];
  }

  for (const line of lines) {
    if (line.trim() === '---') {
      flush();
      continue;
    }
    current.push(line);
  }

  flush();
  return sections;
}

function stripDirectiveShells(html) {
  return html
    .replace(/<(div|p)>\s*<\/\1>/gi, '')
    .replace(/<(div|p)>\s*(?:<br\s*\/?>\s*)<\/\1>/gi, '')
    .trim();
}

function extractSlideDirectives(html) {
  let bg = null;
  let centered = false;
  let cleaned = html;

  cleaned = cleaned.replace(/(?:&lt;|<)\s*bg\s*(?:[:：]|\s)?\s*(20|1\d|[1-9])\s*(?:&gt;|>)/gi, (_, number) => {
    bg = Number(number);
    return '';
  });

  cleaned = cleaned.replace(/(?:&lt;|<)\s*居中\s*(?:&gt;|>)/gi, () => {
    centered = true;
    return '';
  });

  cleaned = stripDirectiveShells(cleaned);

  return { html: cleaned, bg, centered };
}

function findBackgroundAsset(number) {
  const padded = String(number).padStart(2, '0');
  const candidates = ['png', 'jpg', 'jpeg', 'webp'].map((ext) => path.join(backgroundAssetsDir, `bg-${padded}.${ext}`));
  return candidates.find((candidate) => fs.existsSync(candidate)) || null;
}

function bundleBackgroundAsset(number, deckResourcesDir, outputDir) {
  const assetPath = findBackgroundAsset(number);
  if (!assetPath) return null;
  fs.mkdirSync(deckResourcesDir, { recursive: true });
  const outputName = `bg-${String(number).padStart(2, '0')}${path.extname(assetPath).toLowerCase()}`;
  const bundledPath = path.join(deckResourcesDir, outputName);
  if (!fs.existsSync(bundledPath)) {
    fs.copyFileSync(assetPath, bundledPath);
  }
  return path.relative(outputDir, bundledPath).split(path.sep).join('/');
}

function detectFastSlideKind(html) {
  const imageCount = (html.match(/<img\b/gi) || []).length;
  const listCount = (html.match(/<(ol|ul)\b/gi) || []).length;
  const text = html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  if (imageCount > 1) return 'gallery';
  if (listCount) return 'list';
  if (imageCount === 1 && text.length < 80) return 'visual';
  if (imageCount >= 1 && text.length > 0) return 'mixed';
  return 'body';
}

function buildFastDeck(title, markdown, tokenMap, resourcesDirName, outputPath) {
  const outputDir = path.dirname(outputPath);
  const outputBase = path.basename(outputPath, path.extname(outputPath));
  const deckResourcesDir = path.join(outputDir, `${outputBase}.resources`);
  const coverBackgroundFile = path.basename(coverBackgroundPath);
  const bundledCoverBackgroundPath = path.join(deckResourcesDir, coverBackgroundFile);
  const faviconFile = path.basename(faviconPath);
  const bundledFaviconPath = path.join(deckResourcesDir, faviconFile);

  if (fs.existsSync(coverBackgroundPath)) {
    fs.mkdirSync(deckResourcesDir, { recursive: true });
    fs.copyFileSync(coverBackgroundPath, bundledCoverBackgroundPath);
  }
  if (fs.existsSync(faviconPath)) {
    fs.mkdirSync(deckResourcesDir, { recursive: true });
    fs.copyFileSync(faviconPath, bundledFaviconPath);
  }

  const coverBackgroundRelative = fs.existsSync(bundledCoverBackgroundPath)
    ? path.relative(outputDir, bundledCoverBackgroundPath).split(path.sep).join('/')
    : path.relative(outputDir, coverBackgroundPath).split(path.sep).join('/');
  const faviconRelative = fs.existsSync(bundledFaviconPath)
    ? path.relative(outputDir, bundledFaviconPath).split(path.sep).join('/')
    : path.relative(outputDir, faviconPath).split(path.sep).join('/');

  const slideSections = splitMarkdownIntoSections(markdown)
    .map((section) => renderMarkdownLines(section.split('\n'), tokenMap, resourcesDirName))
    .map((sectionHtml) => extractSlideDirectives(sectionHtml))
    .filter((section) => {
      if (!section.html) return false;
      if (/<img\b/i.test(section.html)) return true;
      return section.html.replace(/<[^>]+>/g, '').replace(/\s+/g, '').trim();
    });

  const slidesMarkup = slideSections.map((slide, index) => {
    const backgroundUrl = slide.bg ? bundleBackgroundAsset(slide.bg, deckResourcesDir, outputDir) : null;
    const classes = [
      'slide',
      `slide--${detectFastSlideKind(slide.html)}`,
      backgroundUrl ? 'slide--bg' : '',
      slide.centered ? 'slide--center-quote' : '',
    ].filter(Boolean).join(' ');
    const style = backgroundUrl ? ` style="--slide-bg-image: url('${backgroundUrl.replace(/'/g, '%27')}')"` : '';
    return `
      <section class="${classes}" data-slide-index="${index + 1}"${style}>
        <div class="slide__inner">
          <div class="slide__stack">
            <div class="slide__body">
              ${slide.html}
            </div>
            <div class="slide__thumbs" hidden></div>
          </div>
        </div>
      </section>
    `;
  }).join('\n');

  const totalSlides = slideSections.length + 1;
  const html = `<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>${escapeHtml(title)}</title>
    <link rel="icon" href="${faviconRelative}" type="image/x-icon"/>
    <style>
      :root {
        --bg-1: #f0e7db;
        --bg-2: #cdb9a3;
        --text: #111827;
        --muted: rgba(17, 24, 39, 0.7);
        --accent: #d97706;
      }
      * { box-sizing: border-box; }
      html, body {
        margin: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        font-family: "PingFang SC", "Microsoft YaHei", sans-serif;
        background:
          radial-gradient(circle at 12% 14%, rgba(255, 255, 255, 0.92), transparent 19%),
          radial-gradient(circle at 86% 82%, rgba(142, 100, 63, 0.12), transparent 24%),
          linear-gradient(138deg, var(--bg-1) 0%, #e1d3c1 50%, var(--bg-2) 100%);
        color: var(--text);
      }
      body::before {
        content: "";
        position: fixed;
        inset: 0;
        pointer-events: none;
        background-image:
          radial-gradient(rgba(108, 82, 58, 0.08) 0.7px, transparent 0.9px),
          linear-gradient(115deg, transparent 0 46%, rgba(126, 98, 74, 0.045) 46% 47%, transparent 47% 100%);
        background-size: 22px 22px, 34px 34px;
        opacity: 0.12;
        z-index: 0;
      }
      .deck {
        position: relative;
        z-index: 1;
        width: 100vw;
        height: 100vh;
        overflow: hidden;
      }
      .slide {
        position: absolute;
        inset: 0;
        opacity: 0;
        pointer-events: none;
        transform: translate3d(100%, 0, 0);
        transition: transform 320ms cubic-bezier(0.4, 0, 0.2, 1), opacity 180ms ease;
      }
      .slide.is-active {
        opacity: 1;
        pointer-events: auto;
        transform: translate3d(0, 0, 0);
        z-index: 3;
      }
      .slide.is-before {
        opacity: 0.85;
        transform: translate3d(-100%, 0, 0);
        z-index: 2;
      }
      .slide.is-after {
        opacity: 0.85;
        transform: translate3d(100%, 0, 0);
        z-index: 1;
      }
      .slide__inner {
        height: 100%;
        overflow: auto;
        padding: 72px 84px 56px 148px;
        display: flex;
        flex-direction: column;
        justify-content: center;
      }
      .slide__stack {
        width: 100%;
      }
      .slide__body {
        width: 100%;
      }
      .slide__body > :first-child { margin-top: 0; }
      .slide__body > :last-child { margin-bottom: 0; }
      .slide__body div,
      .slide__body p,
      .slide__body li {
        font-size: 26px;
        line-height: 1.68;
      }
      .slide__body > div,
      .slide__body > p,
      .slide__body > ol,
      .slide__body > ul {
        margin: 12px 0;
      }
      .slide__body [data-nav-level] {
        max-width: min(92vw, 1180px);
        letter-spacing: 0;
      }
      .slide__body [data-nav-level] b,
      .slide__body [data-nav-level] strong,
      .slide__body [data-nav-level] span {
        font-size: inherit !important;
        line-height: inherit !important;
        font-weight: inherit !important;
        color: inherit !important;
        background: transparent !important;
        filter: none !important;
        text-shadow: inherit;
      }
      .slide__body [data-nav-level="1"],
      .slide__body [data-nav-level="2"] {
        display: inline-block;
        width: fit-content;
        padding: 8px 15px;
        border-radius: 6px;
        background: #111827;
        color: #fff !important;
        font-weight: 900 !important;
        box-shadow: 0 16px 34px rgba(17, 24, 39, 0.14);
      }
      .slide__body [data-nav-level="1"] {
        font-size: clamp(42px, 4.3vw, 64px);
        line-height: 1.12;
      }
      .slide__body [data-nav-level="2"] {
        font-size: clamp(34px, 3.4vw, 50px);
        line-height: 1.18;
        background: rgba(17, 24, 39, 0.92);
      }
      .slide__body [data-nav-level="3"],
      .slide__body [data-nav-level="4"] {
        padding-left: 18px;
        border-left: 5px solid #d97706;
        color: #111827 !important;
        font-weight: 850 !important;
      }
      .slide__body [data-nav-level="3"] {
        font-size: clamp(32px, 3vw, 46px);
        line-height: 1.25;
      }
      .slide__body [data-nav-level="4"] {
        border-left-width: 3px;
        border-left-color: rgba(217, 119, 6, 0.46);
        font-size: clamp(26px, 2.4vw, 36px);
        line-height: 1.32;
        color: rgba(17, 24, 39, 0.72) !important;
        font-weight: 760 !important;
      }
      .slide__body img {
        display: inline-block;
        max-width: min(40vw, 620px);
        max-height: 34vh;
        object-fit: contain;
        margin: 14px 10px 0 0;
        border-radius: 14px;
        box-shadow: 0 14px 32px rgba(15, 23, 42, 0.14);
        background: white;
      }
      .slide--visual .slide__inner,
      .slide--center-quote .slide__inner {
        justify-content: center;
      }
      .slide--visual .slide__inner {
        padding: 0;
        overflow: hidden;
      }
      .slide--visual .slide__stack,
      .slide--visual .slide__body {
        width: 100%;
        height: 100%;
      }
      .slide--visual .slide__body {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-end;
        position: relative;
        overflow: hidden;
        padding: 0;
        text-align: center;
      }
      .slide--visual .slide__body img {
        display: block;
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        max-width: none;
        max-height: none;
        object-fit: cover;
        margin: 0;
        border-radius: 0;
        box-shadow: none;
        background: transparent;
      }
      .slide--visual .slide__body > :not(img) {
        position: relative;
        z-index: 2;
        align-self: flex-start;
        max-width: min(72vw, 960px);
        margin: 4px 0 4px clamp(28px, 6vw, 96px);
        padding: 10px 16px;
        border-radius: 10px;
        color: rgba(255, 255, 255, 0.96);
        background: rgba(15, 23, 42, 0.48);
        text-align: left;
        text-shadow: 0 6px 18px rgba(0, 0, 0, 0.34);
        backdrop-filter: blur(8px);
      }
      .slide--visual .slide__body > :not(img):empty {
        display: none;
      }
      .slide--visual .slide__body > :not(img):last-child {
        margin-bottom: clamp(28px, 6vh, 72px);
      }
      .slide--visual.is-portrait-image .slide__body img {
        height: 100vh;
        max-height: 100vh;
      }
      .slide--gallery .slide__inner,
      .slide--mixed .slide__inner {
        justify-content: center;
      }
      .slide--gallery .slide__body img,
      .slide--mixed.has-image-gallery .slide__body img {
        display: none !important;
      }
      .slide__thumbs {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(132px, 132px));
        gap: 12px;
        width: 100%;
        justify-content: start;
        margin: 20px 0 0;
        padding-top: 16px;
        border-top: 1px solid rgba(31, 41, 55, 0.08);
      }
      .slide__thumbs[hidden] {
        display: none !important;
      }
      .thumb {
        width: 132px;
        height: 82px;
        border: 0;
        border-radius: 10px;
        padding: 0;
        overflow: hidden;
        background: #fff;
        box-shadow: 0 8px 22px rgba(15, 23, 42, 0.14);
        cursor: pointer;
      }
      .thumb img {
        display: block !important;
        width: 100%;
        height: 100%;
        object-fit: cover;
        margin: 0;
        border-radius: 0;
        box-shadow: none;
        background: transparent;
      }
      .slide--gallery .slide__body,
      .slide--mixed.has-image-gallery .slide__body {
        max-width: min(84vw, 1240px);
      }
      .slide--gallery .slide__body div,
      .slide--gallery .slide__body p,
      .slide--mixed.has-image-gallery .slide__body div,
      .slide--mixed.has-image-gallery .slide__body p {
        font-size: 25px;
        line-height: 1.58;
      }
      .slide--bg .slide__inner {
        background:
          linear-gradient(rgba(0, 0, 0, 0.64), rgba(0, 0, 0, 0.64)),
          var(--slide-bg-image) center center / cover no-repeat;
      }
      .slide--bg .slide__body,
      .slide--bg .slide__body div,
      .slide--bg .slide__body p,
      .slide--bg .slide__body li,
      .slide--bg .slide__body span,
      .slide--bg .slide__body b,
      .slide--bg .slide__body strong {
        color: rgba(255, 255, 255, 0.97) !important;
        text-shadow: 0 10px 30px rgba(0, 0, 0, 0.34);
      }
      .slide--center-quote .slide__inner {
        align-items: center;
        padding: 64px 96px;
      }
      .slide--center-quote .slide__body {
        max-width: min(78vw, 1180px);
        text-align: center;
      }
      .slide--center-quote .slide__body > * {
        text-align: center !important;
        margin-left: auto;
        margin-right: auto;
      }
      .slide--center-quote .slide__body div,
      .slide--center-quote .slide__body p,
      .slide--center-quote .slide__body li,
      .slide--center-quote .slide__body span,
      .slide--center-quote .slide__body b,
      .slide--center-quote .slide__body strong {
        font-size: clamp(44px, 5.2vw, 78px) !important;
        line-height: 1.18 !important;
        font-weight: 820 !important;
      }
      .slide--cover .slide__inner {
        padding: 0;
        background:
          linear-gradient(rgba(0, 0, 0, 0.58), rgba(0, 0, 0, 0.58)),
          url("${coverBackgroundRelative}") center center / cover no-repeat;
        align-items: center;
      }
      .slide--cover .slide__body {
        max-width: min(88vw, 1320px);
        padding: 0 36px;
        color: rgba(255, 255, 255, 0.98);
        font-size: clamp(29px, 3.2vw, 48px);
        line-height: 1.18;
        font-weight: 800;
        text-align: center;
        text-shadow: 0 10px 32px rgba(0, 0, 0, 0.32);
      }
      .slide__body ol,
      .slide__body ul {
        padding-left: 1.3em;
      }
      .progress {
        position: fixed;
        left: 0;
        bottom: 0;
        height: 5px;
        width: 100%;
        background: rgba(255, 255, 255, 0.28);
        z-index: 20;
      }
      .progress__bar {
        height: 100%;
        width: 0;
        background: linear-gradient(90deg, #f59e0b, #fbbf24);
        transition: width 200ms ease;
      }
      .counter {
        position: fixed;
        right: 22px;
        bottom: 16px;
        z-index: 20;
        font-size: 14px;
        color: rgba(17, 24, 39, 0.72);
      }
      .slide--bg ~ .counter { color: rgba(255,255,255,0.82); }
      .lightbox {
        position: fixed;
        inset: 0;
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 50;
        background: rgba(15, 23, 42, 0.92);
      }
      .lightbox.is-open {
        display: flex;
      }
      .lightbox__img {
        max-width: 96vw;
        max-height: 94vh;
        object-fit: contain;
        border-radius: 14px;
        background: #fff;
      }
      .lightbox__counter {
        position: fixed;
        right: 24px;
        bottom: 20px;
        color: rgba(255, 255, 255, 0.82);
        font-size: 14px;
      }
      @media (max-width: 900px) {
        .slide__inner { padding: 58px 24px 42px; }
        .slide__body div, .slide__body p, .slide__body li { font-size: 20px; }
        .slide__body img { max-width: 100%; max-height: 28vh; }
        .slide--visual .slide__inner { padding: 0; }
        .slide__thumbs { grid-template-columns: repeat(auto-fit, minmax(100px, 100px)); }
        .thumb { width: 100px; height: 64px; }
      }
    </style>
  </head>
  <body>
    <div class="deck">
      <section class="slide slide--cover is-active" data-slide-index="0">
        <div class="slide__inner">
          <div class="slide__body">${escapeHtml(title)}</div>
        </div>
      </section>
      ${slidesMarkup}
    </div>
    <div class="progress"><div class="progress__bar"></div></div>
    <div class="counter">1 / ${totalSlides}</div>
    <div class="lightbox" id="lightbox" aria-hidden="true">
      <img class="lightbox__img" id="lightboxImage" alt="" />
      <div class="lightbox__counter" id="lightboxCounter"></div>
    </div>
    <script>
      const slides = Array.from(document.querySelectorAll('.slide'));
      const progressBar = document.querySelector('.progress__bar');
      const counter = document.querySelector('.counter');
      const lightbox = document.getElementById('lightbox');
      const lightboxImage = document.getElementById('lightboxImage');
      const lightboxCounter = document.getElementById('lightboxCounter');
      let current = 0;
      let lightboxGallery = [];
      let lightboxIndex = 0;
      function renderLightbox() {
        if (!lightboxGallery.length) return;
        const item = lightboxGallery[lightboxIndex];
        lightboxImage.src = item.src;
        lightboxImage.alt = item.alt || '';
        lightboxCounter.textContent = (lightboxIndex + 1) + ' / ' + lightboxGallery.length;
      }
      function openLightbox(gallery, startIndex) {
        if (!gallery.length) return;
        lightboxGallery = gallery.slice();
        lightboxIndex = Math.max(0, Math.min(lightboxGallery.length - 1, startIndex || 0));
        lightbox.classList.add('is-open');
        lightbox.setAttribute('aria-hidden', 'false');
        renderLightbox();
      }
      function closeLightbox() {
        lightbox.classList.remove('is-open');
        lightbox.setAttribute('aria-hidden', 'true');
        lightboxImage.removeAttribute('src');
        lightboxGallery = [];
      }
      function stepLightbox(delta) {
        if (!lightboxGallery.length) return;
        lightboxIndex = (lightboxIndex + delta + lightboxGallery.length) % lightboxGallery.length;
        renderLightbox();
      }
      function setupImageBehavior() {
        for (const slide of slides) {
          const body = slide.querySelector('.slide__body');
          const thumbs = slide.querySelector('.slide__thumbs');
          if (!body || !thumbs) continue;
          const images = Array.from(body.querySelectorAll('img'));
          if (!images.length) {
            thumbs.hidden = true;
            continue;
          }
          const text = (body.textContent || '').replace(/\\s+/g, ' ').trim();
          const gallery = [];
          const seenSources = new Set();
          for (const image of images) {
            const src = image.currentSrc || image.src;
            if (!src || seenSources.has(src)) continue;
            seenSources.add(src);
            gallery.push({ src, alt: image.alt || '' });
          }
          if (images.length === 1 && slide.classList.contains('slide--visual') && text.length <= 80) {
            thumbs.hidden = true;
            images[0].addEventListener('click', () => openLightbox(gallery, 0));
            images[0].style.cursor = 'zoom-in';
            const width = Number(images[0].getAttribute('width') || images[0].naturalWidth || 0);
            const height = Number(images[0].getAttribute('height') || images[0].naturalHeight || 0);
            if (width && height && width / height < 0.72) slide.classList.add('is-portrait-image');
            continue;
          }
          slide.classList.add('has-image-gallery');
          thumbs.innerHTML = '';
          gallery.forEach((image, imageIndex) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'thumb';
            button.innerHTML = '<img src="' + image.src + '" alt="' + (image.alt || '') + '">';
            button.addEventListener('click', () => openLightbox(gallery, imageIndex));
            thumbs.appendChild(button);
          });
          thumbs.hidden = gallery.length === 0;
        }
      }
      function render() {
        slides.forEach((slide, index) => {
          slide.classList.remove('is-active', 'is-before', 'is-after');
          if (index === current) slide.classList.add('is-active');
          else if (index < current) slide.classList.add('is-before');
          else slide.classList.add('is-after');
        });
        progressBar.style.width = ((current + 1) / slides.length) * 100 + '%';
        counter.textContent = (current + 1) + ' / ' + slides.length;
      }
      function go(next) {
        current = Math.max(0, Math.min(slides.length - 1, next));
        render();
      }
      async function toggleFullscreen() {
        if (document.fullscreenElement) {
          await document.exitFullscreen?.();
          return;
        }
        await document.documentElement.requestFullscreen?.();
      }
      window.addEventListener('keydown', async (event) => {
        const key = event.key;
        const lowerKey = key.toLowerCase();
        if (lowerKey === 'f') {
          event.preventDefault();
          await toggleFullscreen();
          return;
        }
        if (lightbox.classList.contains('is-open')) {
          if (key === 'Escape' || lowerKey === 'e') {
            event.preventDefault();
            closeLightbox();
          } else if (key === 'ArrowRight' || key === 'ArrowDown' || key === 'PageDown' || key === ' ') {
            event.preventDefault();
            stepLightbox(1);
          } else if (key === 'ArrowLeft' || key === 'ArrowUp' || key === 'PageUp') {
            event.preventDefault();
            stepLightbox(-1);
          }
          return;
        }
        if (['ArrowRight', 'ArrowDown', 'PageDown', ' '].includes(key)) {
          event.preventDefault();
          go(current + 1);
        }
        if (['ArrowLeft', 'ArrowUp', 'PageUp'].includes(key)) {
          event.preventDefault();
          go(current - 1);
        }
        if (key === 'Home') go(0);
        if (key === 'End') go(slides.length - 1);
      });
      lightbox.addEventListener('click', (event) => {
        if (event.target === lightbox) closeLightbox();
      });
      setupImageBehavior();
      render();
    </script>
  </body>
</html>`;

  fs.writeFileSync(outputPath, html, 'utf8');
  return slideSections.length;
}

function runDeckQa(deckPath) {
  if (process.env.SKIP_DECK_QA === '1') {
    console.log('Deck QA skipped by SKIP_DECK_QA=1');
    return;
  }
  const qaScript = path.join(__dirname, 'qa-deck.js');
  const args = [qaScript, deckPath];
  if (process.env.DECK_QA_NO_BROWSER === '1') {
    args.push('--no-browser');
  }
  run(process.execPath, args, {
    cwd: outputDir,
    stdio: 'inherit',
  });
}

async function main() {
  const fetched = fetchFeishuDoc(sourceDoc);
  const title = fetched.title || 'Feishu Presentation';
  const safeTitle = title.replace(/[\\\\/:*?"<>|]/g, ' ').trim();
  const outputBase = path.basename(outputPath, path.extname(outputPath));
  const resourcesDirName = `${outputBase}.resources`;
  const resourcesDir = path.join(outputDir, resourcesDirName);
  const sourceHtmlPath = path.join(outputDir, `${outputBase}.source.html`);

  fs.mkdirSync(outputDir, { recursive: true });
  fs.mkdirSync(resourcesDir, { recursive: true });

  if (fetched.feishuContent && !fetched.markdown) {
    const sourceHtml = await feishuContentToSourceHtml(safeTitle, fetched.feishuContent, resourcesDirName, resourcesDir);
    fs.writeFileSync(sourceHtmlPath, sourceHtml, 'utf8');
    run(process.execPath, [buildJsPath, sourceHtmlPath, outputPath], {
      cwd: outputDir,
      stdio: 'inherit',
    });
    return;
  }

  fetched.markdown = stripArchiveMarkdownSections(fetched.markdown);
  const tokenMap = await buildImageMap(fetched.markdown, resourcesDir);
  const sourceHtml = markdownToHtml(safeTitle, fetched.markdown, tokenMap, resourcesDirName);
  fs.writeFileSync(sourceHtmlPath, sourceHtml, 'utf8');

  const shouldUseFastPath =
    process.env.FEISHU_FAST_PATH === '1' && (
      fetched.markdown.length > 60000 ||
      collectImageTokens(fetched.markdown).length > 160 ||
      (fetched.markdown.match(/^---$/gm) || []).length > 180
    );

  if (shouldUseFastPath) {
    const slideCount = buildFastDeck(safeTitle, fetched.markdown, tokenMap, resourcesDirName, outputPath);
    console.log(`Built ${slideCount + 1} slides with fast path: ${outputPath}`);
    runDeckQa(outputPath);
    return;
  }

  run(process.execPath, [buildJsPath, sourceHtmlPath, outputPath], {
    cwd: outputDir,
    stdio: 'inherit',
  });
}

main().catch((error) => {
  console.error(error?.stack || error?.message || String(error));
  process.exit(1);
});
