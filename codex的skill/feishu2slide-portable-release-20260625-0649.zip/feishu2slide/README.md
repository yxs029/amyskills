# 飞书2Slide

飞书2Slide 是当前固定使用的课件生成项目目录。它的职责不是“把一篇文稿导成一个静态 HTML”，而是把飞书文档或导出的 HTML 笔记，转换成一套可反复更新的演示系统，稳定输出：

- 演示用 HTML Slide
- 自检清单
- 逻辑结构图
- 逻辑对齐报告
- 图片资源目录
- 若干交互 / 荧光笔 / 光标 / 字体 / 动效 demo

这个目录现在是唯一正式代码目录。旧目录 `evernote-html-ppt-mvp` 只作为历史备份保留，不再作为主工作目录。

## 1. 目录结构

- `src/build-from-feishu.js`
  从飞书文档 URL 读取内容，转成中间 HTML，再交给主生成器输出最终 Slide，并在生成后执行 Deck QA。

- `src/build.js`
  主生成器。负责分页、排版、图片判断、目录导航、大图预览、逻辑诊断、自检输出和 Deck QA 调用。

- `src/qa-deck.js`
  生成后质量闸门。检查裸标签泄露、多图误判、缩略图可见性、单图全屏、图片页溢出等问题。

- `src/build-*.js`
  若干独立 demo 生成器，包括字体、荧光笔、拖尾指针、动效、图片转场等实验页面。

- `output/`
  所有生成结果输出目录。

- `FEATURE_CHECKLIST.md`
  功能清单与回归检查规则。

- `PAGINATION_RULES.md`
  分页规则说明。

## 2. 当前正式能力

### 输入侧

- 支持飞书文档 URL 直读
- 支持飞书 Markdown 中的标题、列表、图片、引用、自定义 `<text ...>` 强调标记
- 支持导出的单篇 HTML 直接生成
- 支持图片下载并自动落到 `output/*.resources`

### 演示生成侧

- 自动封面页
- 自动分页
- 手工分页优先
- 一二三级标题目录抽取
- 右上角目录导航抽屉
- 正文统一字号
- 左对齐、整体上下重心控制
- 薄底部进度条
- 全屏模式

### 图片与交互侧

- 页面缩略图条
- 点击小图查看大图
- 灰色空白区域点击关闭大图
- 大图左右切图
- 翻页笔 `E` 键打开 / 关闭当前页图片预览
- 长图阅读模式 Demo：高宽比超过 `2.05` 的长截图自动进入窄栏全屏阅读
- 长图阅读模式下，方向键 / PageDown 按屏上下滚动
- 双指 / 触控板缩放
- 单图页识别
- 接近 16:9 的单图全屏展示

### 风格与动效侧

- 黄色荧光笔强调
- 红字 / 粗体保留
- 琥珀色拖尾指针
- 页面纵向滚筒式翻页
- 章节页与普通页分层样式

### 诊断与校对侧

- `.diagnostics.json`
- `.self-check.md`
- `.logic-map.md`
- `.logic-check.md`
- `.logic-check.json`
- `.qa-check.md`
- `.qa-check.json`

## 3. 依赖前提

正式运行这套工具，需要满足以下环境条件：

- Node.js 可用
- `npm install` 已执行
- 本机已安装并可调用 `lark-cli`
- `lark-cli` 已完成登录和权限配置
- 当前账号具备读取飞书文档和下载媒体资源权限

### 外部依赖提醒

这套项目当前仍有几个“环境绑定”点，换机器时需要特别处理：

- 默认封面背景图已放在项目内：
  `assets/cover-default.png`

- 飞书媒体下载依赖 `lark-cli docs +media-download`

- 输出目录默认写到项目本地 `output/`

## 4. 常用命令

### 4.1 从飞书生成

```bash
cd "./feishu2slide"
node src/build-from-feishu.js "https://example.feishu.cn/docx/your-doc-token" "./output/你的课件-presentation.html"
```

### 4.2 从 HTML 生成

```bash
cd "./feishu2slide"
node src/build.js "./input.html" "./output/你的课件-presentation.html"
```

### 4.3 生成 demo

```bash
npm run demo:interaction
npm run demo:trail
npm run demo:highlight
npm run demo:font
npm run demo:animation
npm run demo:lightbox
```

也可以直接打开长图翻页笔阅读 Demo：

```bash
open "http://127.0.0.1:8765/demos/long-image-remote-demo.html"
```

如果没有本地静态服务，先在项目根目录执行：

```bash
python3 -m http.server 8765
```

### 4.4 单独执行 Deck QA

```bash
cd "./feishu2slide"
npm run qa:deck -- "./output/你的课件-presentation.html"
```

生成器默认会自动执行这一步。只有临时调试时才建议跳过：

```bash
SKIP_DECK_QA=1 node src/build-from-feishu.js "https://example.feishu.cn/docx/your-doc-token" "./output/test.html"
```

## 5. 标准工作流

### 多 Part 课程交付规则

当前 `course-series.json` 固化了同一课程的多个 Part。生成或交付任意一个 Part 后，必须同时检查并返回：

- Part 01：`output/CIg9-wiki-presentation.html`
- Part 02：`output/part-02-presentation.html`

不要把第二篇输出到第一篇的 `CIg9-wiki-presentation.html`，也不要复用第一篇的 `.resources` 目录。

### 第一步：确认输入源

- 优先使用飞书文档 URL
- 若飞书不可用，再退回 HTML 文件

### 第二步：读取并结构化

- 读取标题层级
- 读取列表结构
- 读取图片
- 读取强调样式
- 读取手工分页线索

### 第三步：做逻辑对齐

- 检查同类标题顺序
- 检查 Part / Level / 数字层级
- 检查是否有同类逻辑顺序错位

### 第四步：分页与渲染

- 手工分页优先
- 自动分页补足
- 近 16:9 单图页尝试全屏
- 目录只保留真正标题

### 第五步：生成自检文件

- 排版风险
- 逻辑树
- Deck QA 质量报告

### 第六步：质量闸门

交付前必须确认：

- `.qa-check.md` 状态为“通过”
- 没有裸露的 `<text>`、`<mention-user>`、`<source-synced>` 等标签
- 多图页没有被判成 `visual`
- 多图页正文原图隐藏，只显示可点击缩略图
- 单张大图页至少铺满视窗宽度或高度之一
- 逻辑顺序检查

### 第六步：人工巡查

- 首屏是否正确
- 图片是否显示
- 目录是否正常
- 大图预览是否正常
- 特性是否回归完整

## 6. 以后默认修改哪里

以后所有正式修改，都默认改这个目录：

- 代码：项目根目录
- 知识库手册：按团队内部文档位置配置

不要再把旧目录 `evernote-html-ppt-mvp` 当作主项目继续演进。

## 7. 当前已知风险

- 项目名和部分注释历史上来自 Evernote MVP，已经不再准确
- 飞书读取和媒体下载依赖本机 `lark-cli` 登录状态与权限
- 输出目录里包含大量历史样例，容易让新 agent 误判“哪个是当前主文件”
- 目录抽取目前严格依赖飞书真正的标题层级，普通加粗正文不会进目录
- 大图全屏策略当前只对“单图页 + 接近 16:9”稳定启用
- 飞书写回目前仍以“谨慎读取、少写回”为主，不应默认整篇覆盖

## 8. 推荐交接方式

如果未来换到别的 agent，只要先读以下 3 个文件，基本就能接手：

1. 本文件 `README.md`
2. `FEATURE_CHECKLIST.md`
3. 知识库里的 `10. 飞书2Slide：最佳实践指南.md`

如果要深入处理分页，再补读：

4. `PAGINATION_RULES.md`
5. 知识库里的 `11. 飞书2Slide：分页规则说明.md`
