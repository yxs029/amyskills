import json, sys, io, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'scripts'))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
from auto_assess import assess_from_raw

BASE = r'F:/OPRASE-AMY/05-OPRASE系统/03-RAS-软件项目落地框架OPRASE/需求文档评审标准+案例包/.workbuddy'
raw = open(os.path.join(BASE, 'dt_eval_raw.json'), encoding='utf-8').read()
res = assess_from_raw(raw)

g = res['grade']
print('=== 定级结果 ===')
print('主等级 :', g.get('level'))
print('overall 字段:', json.dumps(res['overall'], ensure_ascii=False))
print('grade 键:', list(g.keys()))
print()
print('=== 校验轨迹 ===')
for t in g.get('trace', []):
    print('  ', t)
print()
print('=== 维度明细 ===')
for d, s in res['dim_summary'].items():
    print('  %-8s %s' % (d, json.dumps(s, ensure_ascii=False)))
print()
print('=== 关键观察 ===')
for k in res.get('key_observations', []):
    print('  -', k)
print()
out = os.path.join(BASE, 'dt_result.json')
json.dump(res, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('已保存:', out)