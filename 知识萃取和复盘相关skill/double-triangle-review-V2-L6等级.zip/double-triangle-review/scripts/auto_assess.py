#!/usr/bin/env python3
"""
auto_assess.py — 自动评分核心逻辑

调用流程:
  1. 调用方读 references/eval_prompt.md 的"评分 Prompt(主)"
  2. 注入素材,调 LLM,得到 raw JSON
  3. 把 raw JSON 喂给 parse_assessment_json()
  4. 校验 + 补全维度汇总
  5. 返回结构化 dict

用法:
  from auto_assess import parse_assessment_json, validate_scores, calculate_levels
  result = parse_assessment_json(llm_raw_json_str)
  validate_scores(result)
  report_data = calculate_levels(result)
"""

import json
import re
from pathlib import Path

# ==================== 元数据 ====================
SCRIPT_DIR = Path(__file__).parent
DATA_FILE = SCRIPT_DIR.parent / "references" / "assessment-data.json"

SUB_MODULE_META = {}  # sid -> {name, dim, dimName, order, desc, full_name}
DIM_META = {}  # dim key -> {name, fullName, color, subs}


def load_metadata():
    """
    从 references/assessment-data.json 加载子模块 + 维度元数据。

    加载后强制做一致性校验(2026-10 新增)。历史教训:该文件曾出现
    S1-S4 重复 sid(system / scene 各一套),Python dict 后者覆盖前者,
    导致人三角体系维度 4 个子模块静默丢失。此类问题不会再静默通过。
    """
    global SUB_MODULE_META, DIM_META
    SUB_MODULE_META = {}
    DIM_META = {}

    data = json.loads(DATA_FILE.read_text(encoding="utf-8"))

    errors = []

    # --- sid 重复检查 ---
    raw_ids = [s["sid"] for s in data["sub_modules"]]
    dup = {x for x in raw_ids if raw_ids.count(x) > 1}
    if dup:
        errors.append(
            f"assessment-data.json 存在重复 sid: {sorted(dup)}。"
            f"人/AI 双三角的同名子模块必须带 _人 / _AI 后缀区分。"
        )

    for s in data["sub_modules"]:
        SUB_MODULE_META[s["sid"]] = {
            "name": s["name"],
            "dim": s["dim"],
            "dimName": s["dimName"],
            "order": int(s["order"]),
            "desc": s["desc"],
            "triangle": s.get("triangle", ""),
        }

    for d in data["dimensions"]:
        DIM_META[d["key"]] = {
            "name": d["name"],
            "fullName": d["fullName"],
            "color": d["color"],
            "light": d["light"],
            "subs": d["subs"],
            "max_score": len(d["subs"]) * 20,
            "n_subs": len(d["subs"]),
            "triangle": d.get("triangle", ""),
        }

    # --- 与代码 DIM_SUBS 对齐检查 ---
    for dim_key, code_subs in DIM_SUBS.items():
        json_subs = DIM_META.get(dim_key, {}).get("subs")
        if json_subs is None:
            errors.append(
                f"assessment-data.json 缺少维度 key={dim_key}(代码 DIM_SUBS 里有)。"
                f"请把 JSON 的维度 key 与代码对齐。"
            )
        elif set(json_subs) != set(code_subs):
            errors.append(
                f"维度 {dim_key} 子模块不一致 —— "
                f"JSON 独有 {sorted(set(json_subs) - set(code_subs))}, "
                f"代码独有 {sorted(set(code_subs) - set(json_subs))}"
            )

    # --- 子模块覆盖率检查 ---
    code_all = {s for subs in DIM_SUBS.values() for s in subs}
    missing = code_all - set(SUB_MODULE_META)
    if missing:
        errors.append(
            f"assessment-data.json 缺少子模块定义: {sorted(missing)}。"
            f"S1-S4 这类双三角同名子模块必须写成 S1_人 / S1_AI。"
        )

    # --- 维度名脏数据检查(中英文混杂) ---
    for key, meta in DIM_META.items():
        nm = meta["name"]
        if any(c.isascii() and c.isalpha() for c in nm):
            errors.append(f"维度 {key} 名称含英文,疑似脏数据: {nm!r}")

    if errors:
        raise ValueError(
            "assessment-data.json 一致性校验失败:\n  - " + "\n  - ".join(errors)
        )


# ==================== 解析 ====================
def parse_assessment_json(raw: str) -> dict:
    """
    从 LLM 返回的 raw 字符串提取 JSON。
    兼容以下格式:
      - 纯 JSON
      - ```json ... ``` 包裹
      - 前后有 prose
    """
    # 尝试直接 parse
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # 尝试提取 ```json ... ``` 块
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass

    # 尝试找第一个 { ... } 块(贪心)
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass

    raise ValueError(f"无法从 LLM 输出解析 JSON: {raw[:200]}...")


# ==================== 校验 ====================
REQUIRED_SUBS = [
    "A1", "A2", "A3", "A4",
    "S1", "S2", "S3", "S4",  # 人(体系)三角
    "I1", "I2", "I3", "I4", "I5", "I6",
    "S1", "S2", "S3", "S4",  # AI(场景)三角 — 同名 sid 需特殊处理
    "K1", "K2", "K3", "K4", "K5",
    "D1", "D2", "D3", "D4",
]


def validate_scores(data: dict) -> dict:
    """
    校验 LLM 输出,补全缺失字段。
    注意:S1-S4 在人(体系)和 AI(场景)各出现一次,需要用带前缀的 key 区分:
      - S1_人 / S2_人 / S3_人 / S4_人
      - S1_AI / S2_AI / S3_AI / S4_AI
    """
    sub_scores = data.get("sub_scores", {})

    # 重命名 S1-S4 为带前缀的 key
    fixed_sub_scores = {}
    for sid, val in sub_scores.items():
        if sid == "S1":
            # 哪个 dim 还没填? 看 evidence
            ev = (val.get("evidence", "") if isinstance(val, dict) else "")
            if "散点" in ev or "整理" in ev or "知识管理" in ev:
                fixed_sub_scores["S1_人"] = val
            else:
                fixed_sub_scores["S1_AI"] = val
        elif sid == "S2":
            ev = (val.get("evidence", "") if isinstance(val, dict) else "")
            if "聚焦" in ev or "TopN" in ev or "放弃次要" in ev:
                fixed_sub_scores["S2_人"] = val
            else:
                fixed_sub_scores["S2_AI"] = val
        elif sid == "S3":
            ev = (val.get("evidence", "") if isinstance(val, dict) else "")
            if "MECE" in ev or "分类" in ev or "框架" in ev:
                fixed_sub_scores["S3_人"] = val
            else:
                fixed_sub_scores["S3_AI"] = val
        elif sid == "S4":
            ev = (val.get("evidence", "") if isinstance(val, dict) else "")
            if "因果" in ev or "逻辑链" in ev:
                fixed_sub_scores["S4_人"] = val
            else:
                fixed_sub_scores["S4_AI"] = val
        else:
            fixed_sub_scores[sid] = val

    data["sub_scores"] = fixed_sub_scores

    # 校验所有必需的子模块都存在
    expected_keys = [
        "A1", "A2", "A3", "A4",
        "S1_人", "S2_人", "S3_人", "S4_人",
        "I1", "I2", "I3", "I4", "I5", "I6",
        "S1_AI", "S2_AI", "S3_AI", "S4_AI",
        "K1", "K2", "K3", "K4", "K5",
        "D1", "D2", "D3", "D4",
    ]
    missing = [k for k in expected_keys if k not in fixed_sub_scores]
    if missing:
        raise ValueError(f"评估结果缺少子模块: {missing}")

    # 校验分数范围 0-20
    for sid, val in fixed_sub_scores.items():
        if isinstance(val, dict):
            score = val.get("score", 0)
        else:
            score = val
        if not (0 <= score <= 20):
            raise ValueError(f"{sid} 分数 {score} 超出 0-20 范围")

    return data


# ==================== 维度汇总 ====================
DIM_SUBS = {
    "aesthetic": ["A1", "A2", "A3", "A4"],
    "system_人": ["S1_人", "S2_人", "S3_人", "S4_人"],
    "innovation": ["I1", "I2", "I3", "I4", "I5", "I6"],
    "scene_AI": ["S1_AI", "S2_AI", "S3_AI", "S4_AI"],
    "skill": ["K1", "K2", "K3", "K4", "K5"],
    "data": ["D1", "D2", "D3", "D4"],
}

DIM_DISPLAY_NAMES = {
    "aesthetic": "审美",
    "system_人": "体系",
    "innovation": "创新",
    "scene_AI": "场景",
    "skill": "基本功",
    "data": "数据",
}

DIM_MAX_SCORES = {
    "aesthetic": 80,
    "system_人": 80,
    "innovation": 120,
    "scene_AI": 80,
    "skill": 100,
    "data": 80,
}

# ==================== L1-L6 等级体系(2026-10 迭代) ====================
# 双三角归属:人三角 3 维 + AI 三角 3 维
HUMAN_DIMS = ["aesthetic", "system_人", "innovation"]
AI_DIMS = ["scene_AI", "skill", "data"]

GRADE_RUBRIC = [
    {
        "level": 1, "tag": "L1", "name": "有意识", "min_overall": 20,
        "emoji": "🌱", "color": "#E76F51",
        "criteria": "综合分 ≥ 20%。知道该用 AI、该建体系,但还没有稳定动作。",
        "gate_desc": "无额外门槛(仅综合分 ≥ 20%)",
    },
    {
        "level": 2, "tag": "L2", "name": "能用起来 AI 部分", "min_overall": 40,
        "emoji": "🔵", "color": "#1A73E8",
        "criteria": "综合分 ≥ 40%。在部分环节真用起来了 AI,输出质量开始被 AI 改变。",
        "gate_desc": "无额外门槛(仅综合分 ≥ 40%)",
    },
    {
        "level": 3, "tag": "L3", "name": "能用起来所有", "min_overall": 60,
        "emoji": "🟢", "color": "#2A9D8F",
        "criteria": "综合分 ≥ 60%。6 个维度全部进入及格线以上,AI 在全部环节都有落点。",
        "gate_desc": "无额外门槛(仅综合分 ≥ 60%)",
    },
    {
        "level": 4, "tag": "L4", "name": "能有特长", "min_overall": 75,
        "emoji": "⭐", "color": "#F1C40F",
        "criteria": "综合分 ≥ 75%,且至少 1 个维度 ≥ 85%(出现明确长板)。",
        "gate_desc": "结构门槛:max(维度%) ≥ 85",
    },
    {
        "level": 5, "tag": "L5", "name": "双三角各有标杆", "min_overall": 85,
        "emoji": "💎", "color": "#8E44AD",
        "criteria": (
            "综合分 ≥ 85%,人三角与 AI 三角各至少 1 个维度 > 85%,"
            "且 6 个维度全部 ≥ 75%(无明显短板)。"
        ),
        "gate_desc": "结构门槛:人三角 max > 85 且 AI 三角 max > 85 且 min(全部维度%) ≥ 75",
    },
    {
        "level": 6, "tag": "L6", "name": "有极致突破点", "min_overall": 95,
        "emoji": "👑", "color": "#C0392B",
        "criteria": "综合分 ≥ 95%,且至少 1 个维度 > 95%,6 个维度全部 ≥ 75%。",
        "gate_desc": "结构门槛:max(维度%) > 95 且 min(全部维度%) ≥ 75",
    },
]


def base_level_from_percent(percent: float) -> int:
    """按综合分百分比取「档位上限」(不许跳级)。"""
    lv = 1
    for g in GRADE_RUBRIC:
        if percent >= g["min_overall"]:
            lv = g["level"]
    return lv


def check_grade_gate(level: int, stats: dict) -> tuple:
    """
    结构门槛校验。返回 (passed: bool, detail: str)。
    stats 由 collect_grade_stats() 产出。
    """
    if level <= 3:
        return True, "无额外结构门槛"

    if level == 4:
        ok = stats["global_max"] >= 85
        detail = (
            f"最高维度 {stats['max_dim_name']} {stats['global_max']}%"
            + ("" if ok else f",未达 85%(差 {85 - stats['global_max']} 个点)")
        )
        return ok, detail

    if level == 5:
        h_ok = stats["human_max"] > 85
        a_ok = stats["ai_max"] > 85
        f_ok = stats["global_min"] >= 75
        parts = []
        parts.append(
            f"人三角最高 {stats['human_dim_name']} {stats['human_max']}%"
            + ("" if h_ok else f"(需 >85,差 {86 - stats['human_max']} 个点)")
        )
        parts.append(
            f"AI 三角最高 {stats['ai_dim_name']} {stats['ai_max']}%"
            + ("" if a_ok else f"(需 >85,差 {86 - stats['ai_max']} 个点)")
        )
        parts.append(
            f"最低维度 {stats['min_dim_name']} {stats['global_min']}%"
            + ("" if f_ok else f"(需 ≥75,差 {75 - stats['global_min']} 个点)")
        )
        return (h_ok and a_ok and f_ok), " / ".join(parts)

    if level == 6:
        m_ok = stats["global_max"] > 95
        f_ok = stats["global_min"] >= 75
        detail = (
            f"最高维度 {stats['max_dim_name']} {stats['global_max']}%"
            + ("" if m_ok else f"(需 >95,差 {96 - stats['global_max']} 个点)")
            + f" / 最低维度 {stats['min_dim_name']} {stats['global_min']}%"
            + ("" if f_ok else f"(需 ≥75,差 {75 - stats['global_min']} 个点)")
        )
        return (m_ok and f_ok), detail

    return True, ""


def collect_grade_stats(dim_summary: dict) -> dict:
    """汇总 L1-L6 判定所需的结构统计量。"""
    pcts = {k: v["percent"] for k, v in dim_summary.items()}
    names = {k: v["name"] for k, v in dim_summary.items()}

    max_dim = max(pcts, key=lambda k: pcts[k])
    min_dim = min(pcts, key=lambda k: pcts[k])
    human_dim = max(HUMAN_DIMS, key=lambda k: pcts[k])
    ai_dim = max(AI_DIMS, key=lambda k: pcts[k])

    return {
        "pcts": pcts,
        "max_dim": max_dim, "max_dim_name": names[max_dim],
        "min_dim": min_dim, "min_dim_name": names[min_dim],
        "global_max": pcts[max_dim],
        "global_min": pcts[min_dim],
        "human_dim": human_dim, "human_dim_name": names[human_dim],
        "human_max": pcts[human_dim],
        "ai_dim": ai_dim, "ai_dim_name": names[ai_dim],
        "ai_max": pcts[ai_dim],
    }


def calculate_grade(data: dict) -> dict:
    """
    L1-L6 定级(综合分 + 短板双条件)。

    流程:
      1. 档位上限 = 综合分落档(20/40/60/75/85/95),不许跳级
      2. 从上限往下逐级做结构门槛校验,直到某一级通过
      3. 记录完整校验轨迹(grade_trace),便于报告解释「为什么没到 L5」

    副作用:写入 data["grade"],并把 data["overall"]["level"] 更新为 "L5 双三角各有标杆"。
    """
    dim_summary = data["dim_summary"]
    overall_percent = data["overall"]["percent"]
    stats = collect_grade_stats(dim_summary)

    base = base_level_from_percent(overall_percent)

    trace = []
    final = 1
    for lv in range(base, 0, -1):
        passed, detail = check_grade_gate(lv, stats)
        g = next(x for x in GRADE_RUBRIC if x["level"] == lv)
        trace.append({
            "level": lv,
            "tag": g["tag"],
            "name": g["name"],
            "gate_desc": g["gate_desc"],
            "passed": passed,
            "detail": detail,
        })
        if passed:
            final = lv
            break

    g = next(x for x in GRADE_RUBRIC if x["level"] == final)
    nxt = next((x for x in GRADE_RUBRIC if x["level"] == final + 1), None)
    gap_to_next = None
    if nxt:
        gap_to_next = {
            "tag": nxt["tag"],
            "name": nxt["name"],
            "criteria": nxt["criteria"],
            "need_overall": max(0, nxt["min_overall"] - overall_percent),
        }

    data["grade"] = {
        "level": final,
        "tag": g["tag"],
        "name": g["name"],
        "emoji": g["emoji"],
        "color": g["color"],
        "criteria": g["criteria"],
        "gate_desc": g["gate_desc"],
        "base_level": base,
        "base_tag": next(x for x in GRADE_RUBRIC if x["level"] == base)["tag"],
        "downgraded": final < base,
        "overall_percent": overall_percent,
        "min_overall": g["min_overall"],
        "next": gap_to_next,
        "trace": trace,
        "stats": stats,
    }

    # 同步 overall.level,保持下游报告代码兼容
    data["overall"]["level"] = f"{g['tag']} {g['name']}"

    return data


def calculate_levels(data: dict) -> dict:
    """
    计算每个维度的总分、百分比、段位。
    输入 data 必须是 validate_scores 后的格式。
    """
    sub_scores = data["sub_scores"]

    dim_summary = {}
    for dim_key, sub_keys in DIM_SUBS.items():
        total = 0
        for sid in sub_keys:
            val = sub_scores[sid]
            score = val["score"] if isinstance(val, dict) else val
            total += score

        max_score = DIM_MAX_SCORES[dim_key]
        percent = round(total / max_score * 100)

        if percent < 30:
            level = "初阶"
        elif percent < 60:
            level = "进阶段"
        else:
            level = "高阶"

        # 维度级 L 标签:复用 L1-L6 分数线(20/40/60/75/85/95),
        # 但不做双三角结构校验(那是整体等级的事)
        dim_tag = next(
            (x["tag"] for x in reversed(GRADE_RUBRIC) if percent >= x["min_overall"]),
            "L1",
        )
        dim_grade_name = next(
            x["name"] for x in GRADE_RUBRIC if x["tag"] == dim_tag
        )

        dim_summary[dim_key] = {
            "name": DIM_DISPLAY_NAMES[dim_key],
            "total": total,
            "max": max_score,
            "percent": percent,
            "level": level,
            "grade_tag": dim_tag,
            "grade_name": dim_grade_name,
        }

    # 综合分
    overall_total = sum(d["total"] for d in dim_summary.values())
    overall_max = sum(DIM_MAX_SCORES.values())  # 540
    overall_percent = round(overall_total / overall_max * 100)

    if overall_percent < 30:
        overall_level = "初阶"
    elif overall_percent < 60:
        overall_level = "进阶段"
    else:
        overall_level = "高阶"

    data["dim_summary"] = dim_summary
    data["overall"] = {
        "total": overall_total,
        "max": overall_max,
        "percent": overall_percent,
        "level": overall_level,
    }

    # 找最大瓶颈
    weakest = min(dim_summary.items(), key=lambda x: x[1]["percent"])
    data["bottleneck_dim"] = weakest[0]
    data["bottleneck"] = f"{weakest[1]['name']}({weakest[1]['percent']}%)"

    # 找最强维度
    strongest = max(dim_summary.items(), key=lambda x: x[1]["percent"])
    data["strength_dim"] = strongest[0]
    data["strength"] = f"{strongest[1]['name']}({strongest[1]['percent']}%)"

    return data


# ==================== 主流程 ====================
def assess_from_raw(raw: str) -> dict:
    """
    完整流程:raw LLM 输出 → 结构化、可视化的评估数据。
    返回 dict,可直接喂给 generate_report.py。
    """
    load_metadata()
    data = parse_assessment_json(raw)
    data = validate_scores(data)
    data = calculate_levels(data)
    data = calculate_grade(data)
    return data


def grade_from_assessment(assessment: dict) -> dict:
    """
    对已有 assessment dict(已过 calculate_levels)补算 L1-L6 等级。
    用于历史数据升级,无需重跑 LLM 评分。
    """
    load_metadata()
    if "dim_summary" not in assessment:
        assessment = calculate_levels(assessment)
    return calculate_grade(assessment)


if __name__ == "__main__":
    # 自检:载入 metadata
    load_metadata()
    print(f"Loaded {len(SUB_MODULE_META)} sub-modules")
    print(f"Loaded {len(DIM_META)} dimensions")
    expected_keys = [
        "A1", "A2", "A3", "A4",
        "S1_人", "S2_人", "S3_人", "S4_人",
        "I1", "I2", "I3", "I4", "I5", "I6",
        "S1_AI", "S2_AI", "S3_AI", "S4_AI",
        "K1", "K2", "K3", "K4", "K5",
        "D1", "D2", "D3", "D4",
    ]
    print(f"Required sub keys: {len(expected_keys)}")