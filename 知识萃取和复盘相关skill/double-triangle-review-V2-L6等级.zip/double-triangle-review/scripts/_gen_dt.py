import json, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'scripts'))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
from auto_assess import assess_from_raw
import generate_report as gr

BASE = r'F:/OPRASE-AMY/05-OPRASE系统/03-RAS-软件项目落地框架OPRASE/需求文档评审标准+案例包/.workbuddy'
OUT = r'F:/OPRASE-AMY/05-OPRASE系统/03-RAS-软件项目落地框架OPRASE/需求文档评审标准+案例包'
raw = open(os.path.join(BASE, 'dt_eval_raw.json'), encoding='utf-8').read()
res = assess_from_raw(raw)

r1 = gr.generate_report_1(
    res,
    subject='袁雪松 / 需求文档评审官（C 型咨询 Partner）',
    date='2026-10-13',
    scenario='需求文档结构评审能力（标准 + 提示词 8 轮迭代）与清单体方法论资产化',
)
r2 = gr.generate_report_2(
    res,
    scenario='需求文档结构评审能力（标准 + 提示词迭代）',
    hours='本轮：2 份清单体转换 + 双三角复盘 + skill 资产化，约 6 小时',
    retros='定位错文件（07 填写版 vs 原模板）｜ 机械闸门 0 问题但语义仅 88%/96%｜ 边界表 emoji 误删致表头与内容冲突｜ 中文顿号误改为逗号',
)

p1 = os.path.join(OUT, '双三角复盘报告｜需求文档结构评审能力迭代（L1-L6 定级版）.md')
p2 = os.path.join(OUT, '双三角复盘报告｜需求文档结构评审能力迭代（L1-L6 定级版）-报告2.md')
open(p1, 'w', encoding='utf-8').write(r1)
open(p2, 'w', encoding='utf-8').write(r2)
print('报告1:', p1, len(r1), '字符')
print('报告2:', p2, len(r2), '字符')