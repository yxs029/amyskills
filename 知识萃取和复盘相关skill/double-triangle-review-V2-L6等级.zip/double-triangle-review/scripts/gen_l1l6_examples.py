"""
gen_l1l6_examples.py — 生成现行格式(L1-L6)的示例报告

跑法:
  python scripts/gen_l1l6_examples.py

产出:
  examples/reports/report-1-l1-l6-example.md
  examples/reports/report-2-l1-l6-example.md
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from auto_assess import assess_from_raw          # noqa: E402
from generate_report import generate_report_1, generate_report_2   # noqa: E402

RAW = r'''{"subject":"示例对象","scenario":"双三角 L1-L6 体系示例(综合 87%,判 L5)","evaluated_at":"2026-10-13",
"sub_scores":{
"A1":{"score":19,"evidence":"持续收藏优质内容并分类归档"},
"A2":{"score":18,"evidence":"能快速判断内容质量优劣"},
"A3":{"score":17,"evidence":"有明确主题与筛选标准"},
"A4":{"score":18,"evidence":"能把零散经验提炼成可复用模型"},
"S1_人":{"score":17,"evidence":"建立了统一入口与定期整理机制"},
"S2_人":{"score":16,"evidence":"主动砍掉次要方向聚焦主线"},
"S3_人":{"score":18,"evidence":"模块拆解遵循不重不漏原则"},
"S4_人":{"score":17,"evidence":"习惯做因果链分析而非就事论事"},
"I1":{"score":16,"evidence":"沉淀了多条固定工作流"},
"I2":{"score":17,"evidence":"习惯多方案对比后再决策"},
"I3":{"score":14,"evidence":"商业化变现探索明显不足"},
"I4":{"score":15,"evidence":"有产品化尝试但未成体系"},
"I5":{"score":19,"evidence":"AI 已深度嵌入日常执行环节"},
"I6":{"score":18,"evidence":"自研工具与方法论可对外交付"},
"S1_AI":{"score":18,"evidence":"用 AI 的目的与主轴清晰不跟风"},
"S2_AI":{"score":17,"evidence":"能把当前工作与长期路径关联"},
"S3_AI":{"score":19,"evidence":"效率提升有明确量化数据"},
"S4_AI":{"score":18,"evidence":"知识资产已对外交付且复用清晰"},
"K1":{"score":18,"evidence":"理解底层原理且保持人在回路"},
"K2":{"score":19,"evidence":"积累了成体系的提示词模板库"},
"K3":{"score":18,"evidence":"智能体流程端到端跑通"},
"K4":{"score":17,"evidence":"编程融合有实际项目落地"},
"K5":{"score":18,"evidence":"用方法论指导知识库设计"},
"D1":{"score":17,"evidence":"信源分级筛选严格执行"},
"D2":{"score":18,"evidence":"标签体系与双向链接完整"},
"D3":{"score":18,"evidence":"知识库结构化且两分钟可定位"},
"D4":{"score":17,"evidence":"AI 输出反哺形成正向循环"}}}'''

if __name__ == "__main__":
    data = assess_from_raw(RAW)
    g = data["grade"]
    print(f"综合分 {g['overall_percent']}% → {g['tag']} {g['name']}"
          f"(档位 {g['base_tag']},降级 {g['downgraded']})")

    out_dir = Path(__file__).resolve().parents[1] / "examples" / "reports"

    r1 = generate_report_1(
        data, subject="示例对象", date="2026-10-13",
        scenario="双三角 L1-L6 体系示例(综合 87%,判 L5)",
    )
    banner = (
        "> ✅ **现行格式示例(2026-10 L1-L6 体系)。**\n"
        "> 本报告展示能力等级卡、双三角结构校验、定级轨迹与升级路径的完整形态。\n\n"
    )
    r1 = r1.replace("> **复盘场景**", banner + "> **复盘场景**", 1)
    (out_dir / "report-1-l1-l6-example.md").write_text(r1, encoding="utf-8")

    r2 = generate_report_2(
        data, scenario="双三角 L1-L6 体系示例",
        hours=40, retros="一致性缺陷 3 处,结构门槛卡点 1 处",
    )
    r2 = banner + r2
    (out_dir / "report-2-l1-l6-example.md").write_text(r2, encoding="utf-8")

    print(f"已生成:\n  {out_dir / 'report-1-l1-l6-example.md'}"
          f"\n  {out_dir / 'report-2-l1-l6-example.md'}")