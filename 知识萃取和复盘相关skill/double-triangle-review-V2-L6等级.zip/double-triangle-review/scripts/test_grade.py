"""
test_grade.py — L1-L6 定级逻辑自测

跑法:
  python scripts/test_grade.py

覆盖:
  1. 档位落线(综合分 20/40/60/75/85/95)
  2. L4 结构门槛(需有维度 ≥85%)
  3. L5 结构门槛(双三角各 >85 + 全维 ≥75)
  4. L6 结构门槛(需有维度 >95)
  5. 档位回退(综合分够但结构不达标)
  6. 边界值(恰好 = 85 / = 75 / = 95)
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from auto_assess import (  # noqa: E402
    base_level_from_percent,
    collect_grade_stats,
    calculate_grade,
    check_grade_gate,
    GRADE_RUBRIC,
    HUMAN_DIMS,
    AI_DIMS,
)

DIM_MAX = {"aesthetic": 80, "system_人": 80, "innovation": 120,
           "scene_AI": 80, "skill": 100, "data": 80}

PASS = 0
FAIL = 0


def check(label, got, want):
    global PASS, FAIL
    if got == want:
        PASS += 1
        print(f"  ✅ {label}: {got}")
    else:
        FAIL += 1
        print(f"  ❌ {label}: got={got}, want={want}")


def make_data(percents):
    """按目标百分比造一份 dim_summary(反推总分,仅用于定级测试)"""
    dim_summary = {}
    for key, pct in percents.items():
        total = round(DIM_MAX[key] * pct / 100)
        real_pct = round(total / DIM_MAX[key] * 100)
        dim_summary[key] = {
            "name": key, "total": total, "max": DIM_MAX[key],
            "percent": real_pct, "level": "?", "grade_tag": "?", "grade_name": "?",
        }
    overall_total = sum(d["total"] for d in dim_summary.values())
    overall_max = sum(DIM_MAX.values())
    return {
        "sub_scores": {},
        "dim_summary": dim_summary,
        "overall": {
            "total": overall_total, "max": overall_max,
            "percent": round(overall_total / overall_max * 100), "level": "?",
        },
    }


def grade_of(percents):
    return calculate_grade(make_data(percents))["grade"]["tag"]


# ============ 1. 档位落线 ============
print("\n[1] 档位落线(综合分 → 档位上限,不许跳级)")
check("19% → L1", base_level_from_percent(19), 1)
check("20% → L1", base_level_from_percent(20), 1)
check("39% → L1", base_level_from_percent(39), 1)
check("40% → L2", base_level_from_percent(40), 2)
check("59% → L2", base_level_from_percent(59), 2)
check("60% → L3", base_level_from_percent(60), 3)
check("74% → L3", base_level_from_percent(74), 3)
check("75% → L4", base_level_from_percent(75), 4)
check("84% → L4", base_level_from_percent(84), 4)
check("85% → L5", base_level_from_percent(85), 5)
check("94% → L5", base_level_from_percent(94), 5)
check("95% → L6", base_level_from_percent(95), 6)
check("100% → L6", base_level_from_percent(100), 6)

# ============ 2. 整体定级 ============
print("\n[2] 整体定级")

# 全维度低分 → L1
check("全 15% → L1", grade_of({
    "aesthetic": 15, "system_人": 15, "innovation": 15,
    "scene_AI": 15, "skill": 15, "data": 15}), "L1")

# 全 45% → L2
check("全 45% → L2", grade_of({
    "aesthetic": 45, "system_人": 45, "innovation": 45,
    "scene_AI": 45, "skill": 45, "data": 45}), "L2")

# 全 65% → L3
check("全 65% → L3", grade_of({
    "aesthetic": 65, "system_人": 65, "innovation": 65,
    "scene_AI": 65, "skill": 65, "data": 65}), "L3")

# 全 78% 但无任何维度 ≥85 → 档位 L4,结构不达标 → 降 L3
check("全 78% 无长板 → L3(降级)", grade_of({
    "aesthetic": 78, "system_人": 78, "innovation": 78,
    "scene_AI": 78, "skill": 78, "data": 78}), "L3")

# 有一个维度 88%,其余 75% → L4 通过
check("单维 88% + 其余 75% → L4", grade_of({
    "aesthetic": 88, "system_人": 75, "innovation": 75,
    "scene_AI": 75, "skill": 75, "data": 75}), "L4")

# ============ 3. L5 结构门槛 ============
print("\n[3] L5 结构门槛(双三角各 >85 + 全维 ≥75)")

# 人三角 93 / AI 三角 93 / 全维 ≥75,综合分 89 → L5
check("双三角各 93,全维≥75 → L5", grade_of({
    "aesthetic": 92, "system_人": 86, "innovation": 88,
    "scene_AI": 92, "skill": 88, "data": 86}), "L5")

# 只有人三角 >85,AI 三角最高 84 → 结构不达标
check("仅人三角 93,AI 最高 84 → L4", grade_of({
    "aesthetic": 92, "system_人": 86, "innovation": 88,
    "scene_AI": 84, "skill": 84, "data": 84}), "L4")

# 双三角都 >85 但有维度 70 → 短板卡住
check("双三角 93 但一维 70 → L4", grade_of({
    "aesthetic": 92, "system_人": 86, "innovation": 88,
    "scene_AI": 92, "skill": 88, "data": 70}), "L4")

# 综合分天花板效应:结构达标但综合分仅 80.7% → 档位只到 L4
check("结构达标但综合分 80.7% → 封顶 L4", grade_of({
    "aesthetic": 88, "system_人": 78, "innovation": 78,
    "scene_AI": 88, "skill": 78, "data": 78}), "L4")

# ============ 4. L6 结构门槛 ============
print("\n[4] L6 结构门槛(需有维度 >95)")

# 有维度 98,其余 96,综合分 96 → L6
check("单维 98 + 其余 96 → L6", grade_of({
    "aesthetic": 98, "system_人": 96, "innovation": 96,
    "scene_AI": 96, "skill": 96, "data": 96}), "L6")

# 全部恰好 95,综合分 95 够 L6 线但无 >95 → 降 L5
check("全维恰好 95,无 >95 → L5", grade_of({
    "aesthetic": 95, "system_人": 95, "innovation": 95,
    "scene_AI": 95, "skill": 95, "data": 95}), "L5")

# 综合分 92(够 L5 线)但最低维 74 → 短板卡住,降 L4
check("综合分 92 + 一维 74 → 降 L4", grade_of({
    "aesthetic": 98, "system_人": 96, "innovation": 97,
    "scene_AI": 96, "skill": 90, "data": 74}), "L4")

# 直接单测 L6 门槛:97 分维度 + 74 分短板 → 结构不过
d_short = make_data({"aesthetic": 97, "system_人": 96, "innovation": 96,
                     "scene_AI": 96, "skill": 96, "data": 74})
st_short = collect_grade_stats(d_short["dim_summary"])
ok6, det6 = check_grade_gate(6, st_short)
check("L6 门槛:97 分长板 + 74 分短板 → 不通过", ok6, False)
check("L6 门槛详情含短板提示", "最低维度" in det6, True)

# 直接单测 L6 门槛:98 分长板 + 全维 ≥75 → 通过
d_ok = make_data({"aesthetic": 98, "system_人": 96, "innovation": 96,
                  "scene_AI": 96, "skill": 96, "data": 96})
st_ok = collect_grade_stats(d_ok["dim_summary"])
ok6b, _ = check_grade_gate(6, st_ok)
check("L6 门槛:98 分长板 + 全维≥75 → 通过", ok6b, True)

# ============ 5. 边界值语义确认 ============
print("\n[5] 边界值语义")
d = make_data({"aesthetic": 85, "system_人": 85, "innovation": 85,
               "scene_AI": 85, "skill": 85, "data": 85})
st = collect_grade_stats(d["dim_summary"])
ok5, det5 = check_grade_gate(5, st)
check("恰好 85 不算 >85 → L5 门槛不通过", ok5, False)
print(f"     详情: {det5}")

d2 = make_data({"aesthetic": 86, "system_人": 86, "innovation": 86,
                "scene_AI": 86, "skill": 86, "data": 86})
st2 = collect_grade_stats(d2["dim_summary"])
ok5b, _ = check_grade_gate(5, st2)
check("86 > 85 → L5 门槛通过", ok5b, True)

# 隔离测试「≥75 视为无短板」:双三角各 90,最低维恰好 75
d75 = make_data({"aesthetic": 90, "system_人": 75, "innovation": 75,
                 "scene_AI": 90, "skill": 75, "data": 75})
st75 = collect_grade_stats(d75["dim_summary"])
ok5c, det5c = check_grade_gate(5, st75)
check("双三角 90 + 最低维恰好 75 → L5 通过", ok5c, True)
print(f"     详情: {det5c}")

# 最低维 74 → 同样配置但不通过
d74 = make_data({"aesthetic": 90, "system_人": 74, "innovation": 75,
                 "scene_AI": 90, "skill": 75, "data": 75})
st74 = collect_grade_stats(d74["dim_summary"])
ok5d, _ = check_grade_gate(5, st74)
check("双三角 90 + 最低维 74 → L5 不通过", ok5d, False)

# ============ 6. 降级标记 ============
print("\n[6] 降级标记")
g = calculate_grade(make_data({
    "aesthetic": 78, "system_人": 78, "innovation": 78,
    "scene_AI": 78, "skill": 78, "data": 78}))["grade"]
check("档位 L4 → 实际 L3", g["downgraded"], True)
check("base_tag 记录为 L4", g["base_tag"], "L4")

g2 = calculate_grade(make_data({
    "aesthetic": 92, "system_人": 86, "innovation": 88,
    "scene_AI": 92, "skill": 88, "data": 86}))["grade"]
check("档位 L5 → 实际 L5 无降级", g2["downgraded"], False)
check("综合分够 L5 时 base_tag = L5", g2["base_tag"], "L5")

# ============ 7. 轨迹完整性 ============
print("\n[7] 校验轨迹")
g3 = calculate_grade(make_data({
    "aesthetic": 92, "system_人": 86, "innovation": 88,
    "scene_AI": 84, "skill": 84, "data": 84}))["grade"]
tags = [t["tag"] for t in g3["trace"]]
check("轨迹含 L5/L4", tags, ["L5", "L4"])
check("轨迹记录失败原因", "AI 三角" in g3["trace"][0]["detail"], True)
check("overall.level 已同步为 L 标签", g3 and
      calculate_grade(make_data({"aesthetic": 78, "system_人": 78, "innovation": 78,
                                 "scene_AI": 78, "skill": 78, "data": 78}))["overall"]["level"].startswith("L"),
      True)

# ============ 汇总 ============
print(f"\n{'='*50}")
print(f"通过 {PASS} / 失败 {FAIL}")
print(f"{'='*50}")
if FAIL:
    print("❌ 有测试失败")
    sys.exit(1)
print("✅ 全部通过")
