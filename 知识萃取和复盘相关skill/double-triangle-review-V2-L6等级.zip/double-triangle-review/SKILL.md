---
name: double-triangle-review
display_name: 一堂双三角复盘(量化版 · L1-L6 定级 + 双报告)
agent_created: true
description: >
  用「双三角清单体」量化模型对人或 AI 系统的 6 大能力维度做结构化复盘。
  自动评分模式:基于实际素材/项目表现,LLM 推断 27 子模块分数,无需手答 108 题。
  L1-L6 六级定级:综合分落档 + 短板结构门槛双条件,区分「用起来的广度」与「长板深度」。
  输出两份报告:
    报告 1 = 可视化复盘(等级卡 + SVG 雷达图 + 定级校验轨迹 + 升级路径 + 90 天成长主线)
    报告 2 = 场景迭代建议(直接喂给 AI 跑下一轮)
  适用场景:成长测评、项目复盘、阶段总结、跨项目对比、6 个月成长曲线追踪、
  AI 协作效果评估、给下一轮 AI 写启动 prompt。
  当用户说:复盘、双三角、一堂双三角、能力测评、6 要素测评、段位判定、几级、L1 L2 L3 L4 L5 L6、
  我现在到底几级、能力短板、成长曲线、下一轮怎么改,使用此技能。
---

# 一堂双三角复盘(Double-Triangle Review · Quantitative)

## 这是什么

一个**可量化的能力测评 + 复盘框架**,**含自动评分模式**和**两份报告**输出:

- **6 维度 × 27 子模块 × 满分 540 分**(0-100% 段位)
- **自动评分**:基于素材/项目表现,LLM 推断 27 子模块分数,无需用户答 108 题
- **L1-L6 六级定级**:综合分落档 + 短板结构门槛双条件(不许跳级,短板一票否决)
- **报告 1**(可视化复盘):等级卡 + SVG 雷达图 + 定级校验轨迹 + 升级路径 + 90 天成长主线
- **报告 2**(场景迭代建议):AI 启动 prompt + 人类启动清单 + 期望下轮分数

不是主观打分,而是**用 LLM 观察素材 → 客观分数 → L1-L6 定级 → 自动生成双报告**。

## 与早期版本差异

| 维度 | 早期版本 | 本版本(自动评分 + L1-L6 + 双报告) |
|---|---|---|
| 评分 | 主观 / 答 108 题 | **LLM 看素材自动打分** |
| 整体定级 | 3 段(初阶/进阶/高阶) | **L1-L6 六级 + 结构门槛校验** |
| 维度标注 | 3 段 | **维度级 L 标签**(同一套分数线) |
| 报告 | 1 份 markdown | **2 份**(可视化复盘 + 迭代建议) |
| 雷达图 | 无 | **SVG 内嵌** |
| 90 天主线 | 简版 | **6 要素完整版** |
| 升级路径 | 无 | **「距下一级还差什么」自动反推** |
| 喂 AI 下轮 | 无 | **完整可复制 prompt(携带目标等级)** |

## 何时使用

- 自我成长盘点(每 90 天)
- 项目交付复盘
- 跨项目对比(过去 3 个月做了哪些项目,整体段位涨没涨)
- AI 协作效果评估
- 给下一轮 AI 写启动 prompt
- 团队能力图谱

## 完整流程(自动评分模式)

### Step 1: 收集素材

用户提供**复盘对象 + 素材**:

- 对话记录(粘贴 / 引用)
- 项目日志 / git history
- 已完成的 skill 文件树
- skill 输出物(SKILL.md / pipeline / 代码)
- 用户主观观察("这个项目我做得好/不好")

### Step 2: 调用 LLM 自动评分

读取 `scripts/eval_prompt.md`,把素材注入 prompt,调 LLM(推荐 m3),得到 raw JSON。

```
LLM 输出结构:
{
  "sub_scores": {
    "A1": {"score": 16, "evidence": "看到原始 skill 后立刻分两栏列亮点/毛病"},
    ...
  },
  "key_observations": [...]
}
```

LLM 对每个子模块打 0-20 分,基于 evidence。

### Step 3: 解析 + 校验 + 计算段位

调用 `scripts/auto_assess.py`:

```python
from auto_assess import assess_from_raw
result = assess_from_raw(llm_raw_output)
# result 包含:
#   sub_scores (27 个子模块分数)
#   dim_summary (6 维度汇总 + 段位 + 维度级 L 标签)
#   grade (L1-L6 整体等级 + 校验轨迹 + 双三角结构统计)
#   overall (综合分)
#   bottleneck / strength
```

校验逻辑:
- S1-S4 在两个三角里同名 → 按 evidence 自动加 `_人` / `_AI` 后缀
- 校验分数范围 0-20
- 校验所有 27 个子模块都存在
- **L1-L6 定级**:综合分落档 → 逐级结构门槛校验 → 记录轨迹

历史数据(已有 `dim_summary` 但无 `grade`)可直接补算,无需重跑 LLM:

```python
from auto_assess import grade_from_assessment
result = grade_from_assessment(old_assessment)
```

### Step 4: 生成两份报告

调用 `scripts/generate_report.py`:

```python
from generate_report import generate_report_1, generate_report_2

r1 = generate_report_1(result, subject=..., date=..., scenario=...)
r2 = generate_report_2(result, scenario=..., hours=..., retros=...)
```

**报告 1 结构**:
1. **🏅 能力等级卡**(置顶):主等级 + 判定说明 + L1-L6 阶梯表 + 双三角结构表 + 档位回退横幅
2. 一句话回顾
3. 综合评分卡
4. **🔍 定级校验轨迹**(折叠块,解释为什么是这个等级)
5. **距下一级还差什么**(从轨迹反推升级路径)
6. **6 维度 SVG 雷达图**(内嵌)
7. 维度明细表(含「三角」「L 等级」两列)
8. 6 要素详细章节(每个含子模块明细 + 段位徽章 + **90 天成长主线**)
9. 下次复评时间

**报告 2 结构**:
1. 场景元数据(含能力等级)
2. **本轮主线:冲击 Lx**(下一级判定标准直接进迭代目标)
3. 上一轮 6 要素得分速览(关键观察 + 改进方向)
4. **P0 改进建议**(1-3 条,含 AI prompt + 人类 prompt + 验证标准)
5. P1 改进建议(2-4 条)
6. P2 改进建议(战略性,可推迟)
7. **下一轮 AI 启动 prompt**(完整粘贴块,携带本轮目标等级)
8. **下一轮人类启动清单**(时间轴 + checkbox)
9. 期望下轮 6 要素分数提升表(标注 L5/L6 结构门槛约束)

### Step 5: 输出 markdown

把两份报告写到指定路径(默认 `$MAVIS_SCRATCHPAD/<session-id>/`)。

## 6 维度 × 27 子模块(完整定义)

| 三角 | 维度 | 子模块 | 满分 |
|---|---|---|---|
| 🧑 人 | 审美 | A1 主动模仿 / A2 我能看见 / A3 筛选入围 / A4 提炼模型 | 80 |
| 🧑 人 | 体系 | S1_人 散点管理 / S2_人 TopN聚焦 / S3_人 MECE结构 / S4_人 逻辑链系统 | 80 |
| 🧑 人 | 创新 | I1 流程 / I2 方案 / I3 商业 / I4 产品 / I5 技术应用 / I6 技术自研 | 120 |
| 🤖 AI | 场景 | S1_AI Seek / S2_AI Transform / S3_AI Accelerate / S4_AI Realize | 80 |
| 🤖 AI | 基本功 | K1 认知入门 / K2 提示工程 / K3 智能体RAG / K4 编程融合 / K5 体系化思维 | 100 |
| 🤖 AI | 数据 | D1 质量意识 / D2 整理能力 / D3 资产就绪 / D4 飞轮增值 | 80 |
| **合计** |  | **27 子模块** | **540** |

详见 `references/sub-modules.md` 和 `references/assessment-data.json`。

## 段位判定(L1-L6 · 2026-10 迭代)

**整体能力等级用 L1-L6 六级制**,判定算法 = **综合分落档 + 短板结构校验双条件**:

| 等级 | 分数线 | 能力含义 | 结构门槛 |
|---|---|---|---|
| 🌱 **L1** | 20% | 有意识 | 无(纯分数线) |
| 🔵 **L2** | 40% | 能用起来 AI 部分 | 无(纯分数线) |
| 🟢 **L3** | 60% | 能用起来所有 | 无(纯分数线) |
| ⭐ **L4** | 75% | 能有特长 | `max(维度%) ≥ 85`(有长板) |
| 💎 **L5** | 85% | 双三角各有标杆 | 双三角各 `>85` **且** 全部维度 `≥75` |
| 👑 **L6** | 95% | 有极致突破点 | 有维度 `>95` **且** 全部维度 `≥75` |

判定流程:

```
1. 档位上限 = 综合分落档(不许跳级)
2. 从上限往下逐级校验结构门槛,过了就停
3. 记录校验轨迹 → 报告里解释「为什么是这个等级」
```

**三个易错点**:

- `>` 与 `≥` 严格区分:L5 要双三角 **>85**(恰好 85 不达标);短板线 **≥75**(恰好 75 达标)
- **综合分是天花板**:结构再漂亮,综合分不够也上不去(会显示「⚠️ 档位回退」)
- **短板一票否决**:任一维度 <75%,L5/L6 直接出局

双三角归属:🧑 人三角 = 审美/体系/创新;🤖 AI 三角 = 场景/基本功/数据

完整标准与判定示例见 `references/grade-rubric-l1-l6.md`。
维度明细另附**维度级 L 标签**(同一套分数线,不做双三角校验)。

> 早期的「初阶/进阶段/高阶」三段位保留为维度级粗筛标签,不再用于整体定级。

## 极简模式(5 分钟)

时间不够做完整双报告时,只答 6 个问题:

1. **审美**:最近 30 天收藏 / 标注过 3 篇以上"值得反复研究"的内容吗?
2. **体系**:知识 / 项目有"统一入口 + 定期整理"吗?
3. **创新**:过去 30 天有没有**自创**一个方法 / 模型 / 工具?
4. **场景**:用 AI 解决**真实业务痛点**而不是"测试玩玩"吗?
5. **基本功**:能写出 5 个自己常用的 prompt 模板吗?
6. **数据**:数据有"统一标签 + 双向链接"吗?

每个 1-5 分,5 分钟完成。**只能做粗筛,不能替代完整双报告**。

## 输出位置

- 默认:`$MAVIS_SCRATCHPAD/<root-session-id>/review-<topic>-report-1.md` + `report-2.md`
- 也可指定路径(比如 `C:/.../something-report-1.md`)
- 团队对比:`team-review-YYYYMMDD-report-{1,2}.md`

## 重要纪律

1. **诚实打分**(LLM 也要被 prompt 约束诚实)
2. **每个建议 1 小时内能开始**:否则是空话
3. **必须设下次复评时间**:不写就是空头支票
4. **报告 1 + 报告 2 配套使用**:只看 1 会"知道痛但不知道怎么治",只看 2 会"瞎改",两个一起用
5. **改 `assessment-data.json` 后必须能通过 `load_metadata()` 校验**:该函数会检查 sid 唯一性、维度 key 与代码对齐、子模块覆盖率、维度名脏数据,任一不符直接抛错(见下方「一致性保障」)

## 一致性保障(2026-10 新增)

`assessment-data.json` 曾出现 `S1-S4` 重复 sid(人三角体系与 AI 场景各一套),Python dict 后者覆盖前者,导致人三角 4 个子模块**静默丢失**且无任何报错。

`load_metadata()` 现强制校验以下 5 项,任一失败即抛 `ValueError`:

| 校验项 | 说明 |
|---|---|
| sid 唯一性 | 双三角同名子模块必须带 `_人` / `_AI` 后缀 |
| 维度 key 对齐 | JSON 的 `dimensions[].key` 必须与代码 `DIM_SUBS` 完全一致 |
| 子模块覆盖 | `DIM_SUBS` 里每个子模块都要在 JSON 有定义 |
| 维度名纯净 | 维度名不得中英文混杂(防止「场景 STAR」这类脏数据) |
| 子模块集合一致 | 每个维度的 `subs` 集合与代码逐一相符 |

**修改 JSON 后自检**:

```bash
python scripts/auto_assess.py    # 会加载并校验 metadata,报错即不一致
python scripts/test_grade.py     # 39 项定级断言
```

## 文件结构

```
double-triangle-review/
├── SKILL.md                              本文件
├── references/
│   ├── grade-rubric-l1-l6.md             L1-L6 等级标准(★ 现行定级标准)
│   ├── sub-modules.md                    27 子模块定义
│   ├── assessment-data.json              结构化题库(★ 含一致性校验,sid 必须唯一)
│   ├── percentage-rubric.md              1-5 分↔0-20 分换算(段位章节已废弃)
│   ├── radar-chart.md                    SVG 雷达图模板
│   ├── growth-path.md                    90 天主线模板
│   ├── iteration-guide.md                报告 2 设计指南
│   ├── framework.md                      定性兜底(老,段位已废弃)
│   ├── rubric.md                         1-5 分标准(老)
│   ├── scoring.md                        三段位判定(❌ 已废弃)
│   └── question-bank.md                  108 题题库(老,可选)
├── scripts/
│   ├── auto_assess.py                    解析 + 校验 + 汇总 + L1-L6 定级
│   ├── generate_report.py                两份报告生成(含等级卡/轨迹/升级路径)
│   ├── test_grade.py                     L1-L6 定级自测(39 项断言)
│   ├── test_sample.py                    端到端样例测试
│   ├── eval_prompt.md                    LLM 评分提示词
│   └── gen_l1l6_examples.py              生成现行格式示例报告
└── examples/
    ├── arxiv-pipeline-case.md            案例:arxiv pipeline 复盘
    ├── quantitative-self-review.md       案例:量化自评
    └── reports/
        ├── report-1-l1-l6-example.md     ★ 现行格式报告 1 示例
        ├── report-2-l1-l6-example.md     ★ 现行格式报告 2 示例
        ├── arxiv-skill-report-1.md       历史存档(2026-07 旧三段位)
        └── arxiv-skill-report-2.md       历史存档(2026-07 旧三段位)
```

> ★ = 现行标准,优先参考。标 ❌ 的文件已废弃,仅作历史存档。

## 自定义

- **改等级线/门槛**:编辑 `scripts/auto_assess.py` 的 `GRADE_RUBRIC`,同步更新 `references/grade-rubric-l1-l6.md`
- **改双三角归属**:编辑 `auto_assess.py` 的 `HUMAN_DIMS` / `AI_DIMS`
- 改维度粗筛段位:编辑 `references/percentage-rubric.md` 或 `auto_assess.py` 的 `calculate_levels`
- 改 90 天主线模板:编辑 `generate_report.py` 的 `GROWTH_PATH_TEMPLATES`
- 改 AI 启动 prompt 模板:编辑 `generate_report.py` 的 `generate_report_2`
- 改报告结构:编辑 `generate_report.py` 的 `generate_report_1` / `generate_report_2`
- 改题库:编辑 `references/assessment-data.json`
- **改完定级逻辑必须跑**:`python scripts/test_grade.py`(39 项断言全绿才算通过)